# Third-party notices

The application bundles Three.js (MIT), Barlow Condensed and DM Sans (SIL Open Font License 1.1). Express (MIT) and ws (MIT) run on the server. Vite (MIT) builds the application; Playwright (Apache-2.0) is used only for testing.

License texts for bundled code and fonts are in `licenses/`. The generated single HTML file and server distribution are accompanied by this directory in the release archive. Additional package license notices remain in their npm packages when installed.

The original architectural geometry, humanoid geometry, animation code, canvas textures, interface, diagrams and synthesized sound effects were authored for this project. No Counter-Strike or other commercial game assets are included.

The native desktop build uses Godot 4.6.3 (MIT), including its bundled third-party components. See `licenses/Godot-MIT.txt` and `licenses/Godot-THIRD-PARTY.txt`. Native fonts are distributed under the corresponding SIL OFL notices in `licenses/DM-Sans-Native-OFL.txt` and `licenses/Barlow-Native-OFL.txt`. `@napi-rs/canvas` (MIT) is used only to generate assets during development; it is not shipped as a runtime in the native executable.

`resedit` and `pe-library` (MIT) customize the Windows export template's icon and version metadata before packaging; their JavaScript code is not embedded in the game executable. The engine code section is verified unchanged after resource editing. The official verified template is retained separately.
