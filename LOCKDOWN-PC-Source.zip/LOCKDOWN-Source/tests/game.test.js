import test from 'node:test';
import assert from 'node:assert/strict';
import { GameService } from '../server/game-service.js';
import { GAMES, HUB_SPAWN, RACE_GATES, colorPhase, tileColor, parkourPlatforms } from '../shared/game.js';

function fixture(mode='sandbox') {
  let time=100000;
  const service=new GameService({now:()=>time,random:()=>.2});
  function player(name){const events=[],ws={readyState:1,send:raw=>events.push(JSON.parse(raw))};const p=service.connect(ws);p.events=events;p.name=name;return p;}
  const host=player('Warden'),guest=player('Prisoner');service.handle(host,{type:'create',name:'Warden',mode});const room=service.rooms.get(host.room);service.handle(guest,{type:'join',name:'Prisoner',code:room.code});
  return {service,host,guest,room,player,advance(ms){time+=ms;service.tick();},setTime(ms){time=ms;},get time(){return time;}};
}
test('private rooms assign roles, sanitize names, cap capacity and reject unknown codes',()=>{
  const f=fixture();assert.match(f.room.code,/^[A-F0-9]{6}$/);assert.equal(f.host.role,'warden');assert.equal(f.guest.role,'prisoner');
  const x=f.player('x');f.service.handle(x,{type:'join',code:'000000'});assert.equal(x.room,null);assert.equal(x.events.at(-1).type,'error');
  f.room.maxPlayers=2;f.service.handle(x,{type:'join',code:f.room.code});assert.equal(x.room,null);
  f.room.maxPlayers=3;f.service.handle(x,{type:'join',code:f.room.code,name:'<script>bad\x00</script>'});assert.equal(x.name,'scriptbad/script');
});
test('only wardens issue commands, open gates, or start shared rounds; only host changes roles',()=>{
  const f=fixture('jailbreak');f.service.handle(f.guest,{type:'cells',open:false});assert.equal(f.room.cellsOpen,true);
  f.service.handle(f.guest,{type:'command',command:'freeze'});assert.equal(f.room.command,null);
  f.service.handle(f.guest,{type:'startGame',game:'parkour'});assert.equal(f.room.round,null);
  f.service.handle(f.guest,{type:'practice',game:'parkour'});assert.equal(f.guest.trial,null);
  f.service.handle(f.host,{type:'role',id:f.guest.id,role:'guard'});assert.equal(f.guest.role,'guard');
  f.service.handle(f.guest,{type:'cells',open:false});assert.equal(f.room.cellsOpen,false);
  f.service.handle(f.guest,{type:'command',command:'freeze'});assert.equal(f.room.command.text,'DONUN — HAREKET ETMEYİN');
  f.service.handle(f.guest,{type:'startGame',game:'parkour'});assert.equal(f.host.trial.startedAt,f.guest.trial.startedAt);
});
test('movement rejects impossible teleports and nonfinite input',()=>{
  const f=fixture();f.advance(100);f.service.handle(f.guest,{type:'move',pos:[.5,1.72,17],yaw:.1});assert.equal(f.guest.pos[0],.5);
  f.service.handle(f.guest,{type:'move',pos:[180,1.72,180],yaw:0});assert.equal(f.guest.pos[0],.5);
  f.service.handle(f.guest,{type:'move',pos:[NaN,1.72,1],yaw:0});assert.equal(f.guest.pos[0],.5);
});
test('parkour checkpoints survive practice falls and exit awards points once',()=>{
  const f=fixture();f.service.handle(f.host,{type:'practice',game:'parkour'});f.advance(3000);
  const cp=parkourPlatforms()[4];f.host.pos=[-110+cp.x,cp.y+1.72,cp.z];f.advance(100);assert.equal(f.host.trial.checkpoint,1);
  f.host.pos[1]=-10;f.advance(100);assert.deepEqual(f.host.pos,[-110+cp.x,cp.y+1.72,cp.z]);
  f.host.pos=[-110,6.52,-25];f.advance(100);assert.equal(f.host.score,100);assert.equal(f.host.trial,null);f.advance(100);assert.equal(f.host.score,100);
});
test('red light movement causes reset in practice and elimination in shared round',()=>{
  const f=fixture();f.service.handle(f.host,{type:'practice',game:'redlight'});f.setTime(f.host.trial.startedAt+5700);f.service.tick();f.host.pos[2]-=1;f.advance(100);assert.equal(f.host.trial.attempts,1);assert.deepEqual(f.host.pos,GAMES.redlight.spawn);
  f.service.handle(f.host,{type:'startGame',game:'redlight'});f.setTime(f.host.trial.startedAt+5700);f.service.tick();f.guest.pos[2]-=1;f.advance(100);assert.equal(f.guest.status,'out');assert.equal(f.guest.trial,null);assert.equal(f.room.round.results[0].success,false);
});
test('glass paths are private and broken panels are isolated for independent practice',()=>{
  const f=fixture();f.service.handle(f.host,{type:'practice',game:'glass'});f.service.handle(f.guest,{type:'practice',game:'glass'});f.advance(3000);
  assert.equal('safe' in f.service.snapshot(f.room).players[0].trial,false);
  f.host.pos=[-107.7,1.72,-94];f.advance(100);assert.deepEqual(f.host.trial.broken,['0:1']);assert.deepEqual(f.guest.trial.broken,[]);assert.deepEqual(f.room.broken,[]);
});
test('wrong color drops while target color survives',()=>{
  const f=fixture();f.service.handle(f.host,{type:'startGame',game:'colors'});f.setTime(f.host.trial.startedAt+4600);
  const target=colorPhase(4.6).target;let safe,unsafe;for(let row=0;row<5;row++)for(let col=0;col<5;col++){if(tileColor(col,row)===target)safe=[col,row];else unsafe=[col,row];}
  f.host.pos=[-10+safe[0]*5,1.72,-120+safe[1]*5];f.guest.pos=[-10+unsafe[0]*5,1.72,-120+unsafe[1]*5];f.service.tick();assert.ok(f.host.trial);assert.equal(f.guest.status,'out');
});
test('sweeper detects a ground hit and a jump clears the arm',()=>{
  const f=fixture();f.service.handle(f.host,{type:'startGame',game:'sweeper'});f.setTime(f.host.trial.startedAt);f.host.pos=[100,3.1,-104];f.guest.pos=[100,1.72,-104];f.service.tick();assert.ok(f.host.trial);assert.equal(f.guest.status,'out');
});
test('race requires every checkpoint in order for two full laps',()=>{
  const f=fixture();f.service.handle(f.host,{type:'practice',game:'race'});f.advance(3000);f.host.pos=[-17,1.72,127];f.advance(100);assert.equal(f.host.trial.laps,0);
  for(let lap=0;lap<2;lap++)for(const [x,z] of RACE_GATES){f.host.pos=[x,1.72,z+110];f.advance(500);}
  assert.equal(f.host.trial,null);assert.equal(f.host.score,100);
});
test('timers complete survival games, fail timed races and resolve shared rounds',()=>{
  const f=fixture();f.service.handle(f.host,{type:'startGame',game:'colors'});f.setTime(f.host.trial.startedAt+41000);f.service.tick();assert.equal(f.host.score,100);assert.equal(f.guest.score,100);assert.equal(f.room.round.state,'finished');assert.equal(f.room.round.results.length,2);
  f.service.handle(f.host,{type:'startGame',game:'race'});f.setTime(f.host.trial.startedAt+101000);f.service.tick();assert.equal(f.host.status,'out');assert.equal(f.host.score,100);
});
test('maps reset rounds and positions; disconnected hosts resume or transfer ownership',()=>{
  const f=fixture();f.service.handle(f.host,{type:'practice',game:'parkour'});f.service.handle(f.host,{type:'setMap',map:'ironworks'});assert.equal(f.room.map,'ironworks');assert.equal(f.host.trial,null);assert.deepEqual(f.host.pos,HUB_SPAWN);
  const token=f.host.token;f.service.disconnect(f.host);f.advance(5000);const fresh=f.player('temp');const resumed=f.service.handle(fresh,{type:'resume',token});assert.equal(resumed.id,f.host.id);assert.equal(f.room.host,f.host.id);
  f.service.disconnect(resumed);f.advance(31000);assert.equal(f.room.host,f.guest.id);assert.equal(f.guest.role,'warden');
});
test('malformed voice and unsafe commands cannot change other rooms',()=>{
  const f=fixture();const other=f.player('Other');f.service.handle(other,{type:'create',name:'Other'});f.service.handle(other,{type:'kick',id:f.host.id});assert.equal(f.host.room,f.room.code);
  const before=f.guest.events.length;f.service.handle(f.host,{type:'voice',audio:'x'.repeat(7000)});assert.equal(f.guest.events.length,before);
  f.service.handle(f.host,{type:'voice',audio:'AAAA'});assert.equal(f.guest.events.at(-1).type,'voice');
});
