import {chromium} from 'playwright';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';

const base=process.env.TEST_URL||'http://127.0.0.1:3001';
await fs.mkdir('artifacts',{recursive:true});
const errors=[],checks=[];
const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',headless:true,args:['--no-sandbox','--enable-unsafe-swiftshader','--use-angle=swiftshader','--use-fake-ui-for-media-stream','--use-fake-device-for-media-stream']});
async function page(name){const context=await browser.newContext({viewport:{width:1000,height:700},permissions:['microphone']});await context.addInitScript(({name})=>{localStorage.setItem('lockdown.settings',JSON.stringify({quality:'low',motion:false}));localStorage.setItem('lockdown.profile',JSON.stringify({name,completed:0,best:{}}));window.__audioStarts=0;const original=AudioContext.prototype.createBufferSource;AudioContext.prototype.createBufferSource=function(...args){const node=original.apply(this,args),start=node.start.bind(node);node.start=(...args)=>{window.__audioStarts++;return start(...args);};return node;};},{name});const p=await context.newPage();p.voiceFrames=0;p.on('websocket',ws=>ws.on('framereceived',f=>{try{if(JSON.parse(f.payload).type==='voice')p.voiceFrames++;}catch{}}));p.on('pageerror',e=>errors.push(e.message));p.on('console',m=>{if(m.type()==='error'){errors.push(m.text());console.error('BROWSER',m.text());}});await p.goto(base);await p.waitForFunction(()=>window.lockdown?.state.status==='online',null,{timeout:60000});return p;}
function pass(message){checks.push(message);console.log('PASS',message);}
async function open(p,type){await p.evaluate(()=>document.exitPointerLock());await p.waitForTimeout(140);const exists=await p.locator(`[data-action="${type}"]`).first().isVisible();if(exists)await p.locator(`[data-action="${type}"]`).first().click();else {await p.keyboard.press('Escape');await p.waitForTimeout(100);await p.locator(`[data-action="${type}"]`).first().click();}}
try{
  const a=await page('Ada'),b=await page('Bora');
  await a.getByRole('button',{name:'TESİSE GİR',exact:true}).click();
  await a.waitForFunction(()=>window.lockdown.state.room?.code);
  const code=await a.evaluate(()=>window.lockdown.state.room.code);
  await b.click('[data-action="join"]');await b.fill('#join-code',code);await b.locator('#join-form button[type=submit]').click();
  await b.waitForFunction(()=>window.lockdown.state.room?.players.length===2);await a.waitForFunction(()=>window.lockdown.state.room?.players.length===2);
  assert.equal(await b.evaluate(()=>window.lockdown.state.room.code),code);pass('Two real browser clients join the same private room.');
  await b.click('[data-action="enter"]');await a.click('[data-action="enter"]');await a.waitForFunction(()=>!!document.pointerLockElement);
  await a.bringToFront();const z=await a.evaluate(()=>window.lockdown.state.pos[2]);await a.keyboard.down('KeyW');await a.waitForFunction(z=>window.lockdown.state.pos[2]<z-2,z,{timeout:15000});await a.keyboard.up('KeyW');
  const z2=await a.evaluate(()=>window.lockdown.state.pos[2]);assert.ok(z2<z-2,`movement ${z}->${z2}`);pass('Keyboard movement and pointer lock work.');
  await a.keyboard.press('Space');await a.waitForFunction(()=>window.lockdown.state.pos[1]>1.8,null,{timeout:10000});await a.waitForFunction(()=>window.lockdown.state.pos[1]<1.8,null,{timeout:10000});pass('Jump and ground collision work.');
  await a.keyboard.press('KeyT');await a.fill('#chat-input','Merhaba <script> güvenli sohbet');await a.keyboard.press('Enter');await b.getByText('Merhaba <script> güvenli sohbet',{exact:true}).waitFor();pass('Chat relays between clients and renders markup as text.');
  await a.keyboard.press('KeyG');await a.locator('[data-action="command"][data-command="freeze"]').click();await b.locator('#command-banner strong').getByText('DONUN — HAREKET ETMEYİN',{exact:true}).waitFor();pass('Warden announcements reach the other player.');
  await a.keyboard.press('KeyG');await a.click('[data-action="cells"]');await b.waitForFunction(()=>window.lockdown.state.room.cellsOpen===false);pass('Cell gate state is synchronized.');
  await a.keyboard.press('KeyG');await a.locator('[data-action="role"]').click();await b.waitForFunction(()=>window.lockdown.state.room.players.find(p=>p.id===window.lockdown.state.myId).role==='guard');pass('Host role changes are synchronized.');
  await a.click('[data-action="round"][data-game="redlight"]');
  await a.waitForFunction(()=>window.lockdown.state.room.round?.game==='redlight');await b.waitForFunction(()=>window.lockdown.state.room.round?.game==='redlight');
  assert.equal(await a.evaluate(()=>window.lockdown.state.room.round.startedAt),await b.evaluate(()=>window.lockdown.state.room.round.startedAt));
  assert.ok(Math.abs((await a.evaluate(()=>window.lockdown.state.pos[0]))-100)<1);pass('Shared mini-game starts with identical countdown and teleport.');
  await a.keyboard.press('KeyG');await a.click('[data-action="end-round"]');await b.waitForFunction(()=>window.lockdown.state.room.round===null);pass('Warden can end the round and return all players to the yard.');
  await a.keyboard.press('KeyG');await a.selectOption('#switch-map','ironworks');await a.click('[data-action="switch-map"]');await b.waitForFunction(()=>window.lockdown.state.room.map==='ironworks');pass('Map transitions synchronize between clients.');
  await a.keyboard.press('KeyG');await a.selectOption('#switch-map','northstar');await a.click('[data-action="switch-map"]');await b.waitForFunction(()=>window.lockdown.state.room.map==='northstar');pass('All three maps load without JavaScript errors.');
  await a.keyboard.press('KeyM');await a.click('[data-action="start-game"][data-game="parkour"]');await a.waitForFunction(()=>window.lockdown.state.room.players.find(p=>p.id===window.lockdown.state.myId).trial?.game==='parkour');assert.equal(await b.evaluate(()=>window.lockdown.state.room.players.find(p=>p.id===window.lockdown.state.myId).trial),null);pass('Sandbox practice starts independently.');
  await a.keyboard.press('KeyR');await a.waitForTimeout(300);assert.ok(Math.abs((await a.evaluate(()=>window.lockdown.state.pos[0]))+110)<1);pass('Practice respawn returns to the correct game spawn.');
  await a.evaluate(()=>document.exitPointerLock());await a.waitForTimeout(200);await a.click('[data-action="hub"]');await a.waitForFunction(()=>window.lockdown.state.pos[2]>16);await a.evaluate(()=>document.exitPointerLock());await a.waitForTimeout(200);await a.click('[data-action="settings"]');await a.selectOption('[data-setting="quality"]','medium');assert.equal(await a.evaluate(()=>JSON.parse(localStorage.getItem('lockdown.settings')).quality),'medium');pass('Settings persist and graphics quality can change at runtime.');
  await a.click('[data-action="close"]');await a.evaluate(()=>document.exitPointerLock());await a.waitForTimeout(200);
  await a.locator('.dialog [data-action="voice"]').click();await a.waitForFunction(()=>document.querySelector('#voice-hint').classList.contains('enabled'));pass('Microphone capture and AudioWorklet initialize with browser permission.');
  const audioBefore=await b.evaluate(()=>window.__audioStarts);await a.click('[data-action="enter"]');await a.keyboard.down('KeyV');await a.waitForTimeout(1200);await a.keyboard.up('KeyV');assert.ok(b.voiceFrames>0);await b.waitForFunction(n=>window.__audioStarts>n,audioBefore,{timeout:10000});pass('Push-to-talk audio is relayed and scheduled for playback in the second browser.');
  await a.screenshot({path:'artifacts/browser-tested.png'});
  // Reloading a connected browser exercises room rejoin via invitation instead of fake socket stubs.
  await b.goto(`${base}/?room=${code}`);await b.waitForFunction(()=>window.lockdown?.state.status==='online');assert.equal(await b.inputValue('#join-code'),code);pass('Invitation URL prefills the correct room code.');
  const local=await browser.newPage({viewport:{width:1000,height:700}});local.on('pageerror',e=>errors.push(e.message));await local.addInitScript(()=>localStorage.setItem('lockdown.settings',JSON.stringify({quality:'low',motion:false})));
  // Managed Chromium forbids file:// navigation. Serve exactly the standalone
  // bytes through an intercepted document request, and block every subresource.
  const standalone=await fs.readFile(path.resolve('release/LOCKDOWN.html'),'utf8'),unexpected=[];
  await local.route('**/*',async route=>{if(route.request().isNavigationRequest())await route.fulfill({contentType:'text/html',body:standalone});else {unexpected.push(route.request().url());await route.abort();}});
  await local.goto(`${base}/standalone-check?offline=1`);await local.waitForFunction(()=>window.lockdown?.state.status==='online',null,{timeout:60000});
  await local.getByRole('button',{name:'TESİSE GİR',exact:true}).click();await local.waitForFunction(()=>window.lockdown.state.room?.code);await local.click('[data-action="enter"]');await local.keyboard.press('KeyM');await local.click('[data-action="start-game"][data-game="glass"]');await local.waitForFunction(()=>window.lockdown.state.room.players.find(p=>p.id===window.lockdown.state.myId).trial?.game==='glass');assert.deepEqual(unexpected,[]);pass('The standalone HTML runs its local game rules with zero subresource network requests.');
  assert.deepEqual(errors,[]);pass('No uncaught JavaScript errors in tested browser flows.');
  await fs.writeFile('artifacts/browser-results.json',JSON.stringify({date:new Date().toISOString(),checks,errors,limitations:['Direct file:// navigation is blocked by managed Chromium policy. The identical standalone HTML bytes were tested through an intercepted document response in explicit offline mode, with all subresource requests blocked.']},null,2));
} finally {await browser.close();}
