import WebSocket from 'ws';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';

const base=process.env.TEST_URL||'http://127.0.0.1:3001',url=base.replace(/^http/,'ws')+'/socket';
const clients=[],checks=[];
function connect(){return new Promise((resolve,reject)=>{const ws=new WebSocket(url),messages=[];ws.on('message',raw=>messages.push(JSON.parse(raw)));ws.once('error',reject);ws.once('open',()=>{const client={ws,messages,send:(type,data={})=>ws.send(JSON.stringify({type,...data})),wait:(type,predicate=()=>true,after=0)=>new Promise((res,rej)=>{const interval=setInterval(()=>{const found=messages.slice(after).find(m=>m.type===type&&predicate(m));if(found){clearInterval(interval);clearTimeout(timeout);res(found);}},10);const timeout=setTimeout(()=>{clearInterval(interval);rej(new Error(`Timed out: ${type}`));},5000);})};clients.push(client);resolve(client);});});}
function pass(text){checks.push(text);console.log('PASS',text);}
try{
  const host=await connect();host.send('create',{name:'Host',maxPlayers:16,mode:'jailbreak'});const joined=await host.wait('joined');const code=joined.room.code;
  const guests=await Promise.all(Array.from({length:15},async(_,i)=>{const c=await connect();c.send('join',{code,name:`Guest ${i+1}`});await c.wait('joined');return c;}));
  await host.wait('state',m=>m.room.players.length===16);pass('16 WebSocket clients join and receive the same roster.');
  const extra=await connect();extra.send('join',{code,name:'Seventeenth'});assert.match((await extra.wait('error')).message,/dolu/);pass('A seventeenth client is rejected by the capacity limit.');
  const markers=guests.map(c=>c.messages.length);host.send('command',{command:'line'});await Promise.all(guests.map((c,i)=>c.wait('command',m=>m.text==='SARI ÇİZGİDE SIRAYA GEÇİN',markers[i])));pass('Warden command broadcasts to all 15 other clients.');
  const voiceMarkers=guests.map(c=>c.messages.length);host.send('voice',{audio:Buffer.alloc(3200).toString('base64')});await Promise.all(guests.map((c,i)=>c.wait('voice',m=>m.id===joined.id,voiceMarkers[i])));pass('A 100 ms PCM voice packet relays to the entire room.');
  host.send('startGame',{game:'race'});const states=await Promise.all(clients.slice(0,16).map(c=>c.wait('state',m=>m.room.round?.game==='race')));assert.equal(new Set(states.map(s=>s.room.round.startedAt)).size,1);pass('All 16 clients receive the same round start timestamp.');
  const token=joined.token;host.ws.close();const resumed=await connect();resumed.send('resume',{token});const session=await resumed.wait('joined');assert.equal(session.id,joined.id);assert.equal(session.room.host,joined.id);pass('A disconnected host resumes the same role and round.');
  resumed.send('leave');const remaining=await guests[0].wait('state',m=>m.room.players.length===15);assert.notEqual(remaining.room.host,joined.id);assert.equal(remaining.room.players.find(p=>p.id===remaining.room.host).role,'warden');pass('Host departure transfers ownership without deleting the room.');
  await fs.mkdir('artifacts',{recursive:true});await fs.writeFile('artifacts/network-results.json',JSON.stringify({date:new Date().toISOString(),checks},null,2));
}finally{for(const c of clients)c.ws.close();}
