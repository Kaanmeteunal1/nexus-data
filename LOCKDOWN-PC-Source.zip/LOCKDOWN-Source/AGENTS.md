# Working on LOCKDOWN

The primary requested deliverable is now a native Windows PC game. The Godot 4.6.3 project is in `desktop/`; read `desktop/README.md`. Preserve the existing browser version. The native ENet transport and Node/WebSocket transport are separate implementations. Do not describe an Electron/web wrapper as the native deliverable.

Native rules are in `desktop/scripts/rules.gd`; run the native rule and network scenes after changing them. `npm run desktop:test` also tests native physics; with DISPLAY it runs real UI hit testing and physical key events. Headless Godot cannot capture a mouse, so UI input checks require X11. Windows templates must match Godot 4.6.3 and be verified against the official SHA512 archive. Export via `desktop/export_presets.cfg`; embedded PCKs produce portable executables. Confirm the exported Linux equivalent starts, and state explicitly that this is not an actual Windows runtime test.

Use the existing checkout. Each cloud task already has an isolated environment; do not create a Git worktree unless explicitly requested.

Node 22+ is required (validated here with Node 24). Install with `npm ci --cache /workspace/.cache/npm`. `npm run build` emits both `dist/` for the server and `release/LOCKDOWN.html` for standalone single-player use. Keep both builds working.

Run `npm test` after changing game rules. For browser/network changes start the production server on port 3001 and run `npm run test:browser` and `npm run test:network`. The browser tests use system Chromium; override `CHROMIUM_PATH` when needed. Software rendering in this environment is slower than a hardware-accelerated user browser; do not report its frame rate as user hardware performance.

Shared rules in `server/game-service.js` run in Node and in the standalone browser. Use standard Web Crypto, not Node-only modules, in that file. Never include private glass solutions in public room snapshots. Role/room mutations must remain server-authorized. Keep chat and player-provided strings escaped in HTML.

The interface is Turkish. Source models, architecture, textures and sounds are original and procedural. Keep third-party notices when adding dependencies or shipping an archive.

Do not claim public Internet deployment without an actual accessible deployed address. A running local server, a Dockerfile and an offline HTML artifact are different deliverables.
