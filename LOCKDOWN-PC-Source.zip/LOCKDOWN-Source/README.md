# LOCKDOWN — Blackwater

**Windows PC sürümü eklendi:** [Masaüstü sürümünün kapsamı, kontrolleri ve doğrulaması](desktop/README.md). Godot projesi `desktop/`, Windows çalıştırılabilir dosyası `release/windows/LOCKDOWN.exe` altındadır. Aşağıdaki bölümler korunan web sürümünü anlatır.

Özgün bir üç boyutlu tarayıcı oyunu: özel odalarda gardiyan/mahkûm rol yapma, ortak mini oyun turları ve bağımsız serbest antrenman. Counter-Strike Jailbreak topluluk oyunlarından esinlenir; Valve dosyaları, haritaları veya karakterleri kullanılmaz.

## Hemen oyna

`release/LOCKDOWN.html` dosyasını güncel masaüstü Chrome, Edge veya Firefox ile aç. Bu dosya oyunu, yazı tiplerini, haritaları ve kural motorunu içerir; kurulum veya internet bağlantısı gerektirmez. **Bu dağıtım tek oyunculudur.** Çok oyunculu oturumlar aşağıdaki sunucu sürümündedir.

Klavye ve fare gereklidir. Dokunmatik oyun kontrolü ve oyun kumandası desteği bu sürümde yoktur. WebGL 2 ve donanım hızlandırması gerekir. Görüntü ayarlarından performans, dengeli ve yüksek kalite seçilebilir.

## İçerik

- **Blackwater:** kıyı hapishanesi, hücre bloğu, avlu, gözetleme kuleleri ve liman silueti.
- **Ironworks:** gece endüstriyel tesis, boru hatları, bacalar ve fırınlar.
- **Northstar:** karlı dağ tesisi ve soğuk sabah atmosferi.
- **Firar Rotası:** zıplama parkuru, kontrol noktası ve zaman ölçümü.
- **Son Komut:** kırmızı/yeşil ışık. Kırmızı ışık sırasında hareket etmek elenme sebebidir.
- **Cam Köprü:** her tur yeni, sunucuda gizli tutulan güvenli yol. Kırılan camlar ortak turda tüm oyunculara görünür.
- **Renk Kapanı:** anons edilen renge geç; yanlış paneller düşer.
- **Son Ayakta:** hızlanan döner engelin üzerinden atlayarak 45 saniye dayan.
- **Avlu Yarışı:** engeller ve sıralı kontrol kapıları üzerinden iki tur.
- 16 kişiye kadar kodlu özel odalar; gardiyan/mahkûm rolleri; komut paneli; özel anons; hücre kapıları; oda yöneticisi aktarımı; sohbet; oyuncu susturma; uzaklaştırma; rol dağıtımı; tur sonuçları.
- İsteğe bağlı bas-konuş. Mahkûmların sesi 40 metre içinde, gardiyanların telsizi tüm odada duyulur. Ses kaydedilmez; sunucu bağlı oda üyelerine iletir. Mikrofon kullanımında tarayıcının izin istemesi normaldir.
- Yürüme/koşma/çömelme/zıplama, dayanıklılık, birinci/üçüncü şahıs kamera ve üç karakter ifadesi.
- Yerel tarayıcıda saklanan ayarlar ve kişisel süreler.

Tesisler aynı oyun altyapısını ve hücre planını paylaşır; mimari çevreleri, ışıkları, malzemeleri ve parkur ayrıntıları farklıdır.

## Kontroller

| Tuş | Eylem |
| --- | --- |
| WASD / ok tuşları | Hareket |
| Fare | Bakış |
| Space | Zıpla |
| Sol Shift | Koş |
| Ctrl | Çömel |
| E | Yakındaki oyun terminalini kullan |
| M | Oyun alanları |
| G | Gardiyan paneli |
| Tab | Oyuncu listesi |
| T / Enter | Sohbet |
| V basılı | Sesli sohbet (önce mikrofon düğmesinden etkinleştir) |
| C | Birinci / üçüncü şahıs |
| R | Antrenmanda kontrol noktasına dön; ortak turda turu bırak |
| 1 / 2 / 3 | El salla / selam ver / dans |
| H | Arayüzü gizle/göster |
| Escape | Fareyi bırak / menü |

## Oyun biçimleri

**Serbest Alan:** Oyuncular birbirlerini beklemeden farklı oyunlarda antrenman yapabilir. Hatalar kontrol noktasına veya başlangıca döndürür. Gardiyan panelinden başlatılan ortak tura tüm oda birlikte katılır.

**Jailbreak:** Oyunları ve turları gardiyan başlatır. Mahkûmlar, komutları sohbet/telsiz ve ekran anonsuyla alır. Sosyal komutlar rol yapmaya bırakılır; oyun motoru mini oyun kurallarını ayrıca uygular. Başlangıçta oda sahibi baş gardiyandır. Diğer oyunculara gardiyan rolünü yalnızca oda sahibi verir.

**Ortak tur:** Hata yapan oyuncu elenir; tur devam eder. Herkes tamamladığında veya elendiğinde sonuç tablosu oluşur. Gardiyan turu kesip herkesi avluya döndürebilir. Başarılı tamamlamalar 100 oturum puanı verir.

## Geliştirme ve sunucu dağıtımı

Mevcut çalışma ortamında bağımlılıklar kurulu ve üretim paketi oluşturulmuştur. Aşağıdaki komutlar geliştirici/işletmeci içindir; tek dosyalık sürümü oynayan kişinin bunları çalıştırması gerekmez.

```sh
npm ci
npm run dev          # Node + Vite, port 3000
npm test             # Oyun kural motoru testleri
npm run build        # dist/ + release/LOCKDOWN.html
npm start            # Üretim HTTP/WebSocket sunucusu, port 3000
```

`PORT` ile port değişir. Üretimde tek Node süreci hem statik oyun dosyalarını hem `/socket` WebSocket bağlantısını sunar. `/api/health` sağlık uç noktasıdır. `Dockerfile` tek servisli dağıtım için hazırdır.

Çok oyunculu oyun, aynı sunucuya erişen tarayıcılar arasında çalışır. İnternette paylaşılacak bir sürüm için WebSocket destekli bir barındırmada bu sunucuya yönlenen **HTTPS** adresi gerekir. Ses için HTTPS (veya geliştirici makinesinde localhost) zorunludur. Bu depoya bir alan adı, bulut hesabı veya otomatik yayımlama yetkisi eklenmiş değildir. Yalnızca `dist/` klasörünü statik barındırmaya yüklemek çok oyunculu sunucuyu çalıştırmaz.

Odalar ve oturum puanları bellektedir; sunucu yeniden başlatılırsa temizlenir. Aynı oda tek sunucu sürecinde tutulur. Yatay ölçeklendirme, hesap sistemi, kalıcı envanter, genel eşleştirme ve rekabetçi anti-cheat içermez. Hareket için hız/konum sınırları ve sunucuda oyun sonuç kontrolü vardır; güvenilir arkadaş grupları hedeflenmiştir. 16 kişilik kapasite sınırı vardır; 16 gerçek kullanıcıyla internet ölçeğinde yük testi yapıldığı anlamına gelmez.

## Testler

```sh
PORT=3001 NODE_ENV=production node server/index.js
# Ayrı bir terminalde:
npm run test:browser
```

Tarayıcı testleri gerçek Chromium oturumlarıyla oda oluşturma/katılma, hareket, zıplama, sohbet, gardiyan komutları, kapılar, roller, ortak tur, üç harita geçişi, bağımsız antrenman ve mikrofon aktarımını kontrol eder. `CHROMIUM_PATH` ile Chromium yolu; `TEST_URL` ile test sunucusu değişir. Sonuçlar ve görüntüler `artifacts/` altına yazılır. Oyun kural testleri `tests/game.test.js` içindedir. `npm run test:network`, 16 otomatik WebSocket istemcisiyle kapasite, yayın ve oturum geri yükleme akışlarını doğrular.

Bu çalışma ortamının yönetilen Chromium politikası doğrudan `file://` gezinmesini engeller. Bu nedenle bağımsız HTML dosyasının birebir içeriği, açık çevrimdışı modda ve tüm ek kaynak istekleri engellenerek tarayıcıda test edilir. Doğrudan dosya açma testi bu ortamda yapılamamıştır. Yazılımsal GPU ile elde edilen kare hızları kullanıcı donanımındaki performansı temsil etmez.

## Yapı

- `src/world.js`: mimari, malzemeler, ışıklı işaretler, sahne ve çarpışma yüzeyleri.
- `src/engine.js`: hareket, kamera, render ve oyuncu interpolasyonu.
- `src/character.js`: özgün eklemli karakter modelleri ve animasyonlar.
- `src/main.js`, `src/style.css`: Türkçe arayüz, oda ve oyun akışları.
- `server/game-service.js`: oda yönetimi, yetkiler ve oyun kuralları; aynı motor çevrimdışı sürümde de çalışır.
- `server/index.js`: Express/WebSocket sunucusu.
- `shared/game.js`: haritalar, oyun tanımları, parkur ve tur geometrileri.
- `src/audio.js`, `public/voice-worklet.js`: üretilen oyun sesleri ve 16 kHz bas-konuş ses aktarımı.

## Lisanslar ve başvurulan kaynaklar

Özgün kaynak ve geometriler MIT lisansıyla verilmiştir. Tüm görsel modeller ve dokular bu proje için kodla oluşturulur; oyun yüklenirken dışarıdan asset indirilmez. Üçüncü taraf bileşenler ve yazı tipleri için `THIRD_PARTY_NOTICES.md` ve `licenses/` klasörüne bak.

Teknik değerlendirmede Three.js resmî deposu, `ws` resmî belgeleri ve Ecctrl'nin karakter kontrolü dokümantasyonu incelendi. Ecctrl bu uygulamanın bağımlılığı değildir. Erişilemeyen web arama sonuçları incelenmiş gibi gösterilmemiştir.

- https://github.com/mrdoob/three.js
- https://github.com/websockets/ws
- https://github.com/pmndrs/ecctrl

Bu sürüm oynanabilir bir bağımsız tarayıcı oyunu temelidir. AA ticari oyun kapsamı, üretim yayımlaması veya profesyonel çok cihazlı kalite güvencesi iddiası taşımaz.
