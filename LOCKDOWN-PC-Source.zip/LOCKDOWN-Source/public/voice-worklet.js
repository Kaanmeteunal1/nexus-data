class LockdownVoice extends AudioWorkletProcessor {
  constructor(){super();this.samples=[];this.phase=0;}
  process(inputs,outputs){
    const input=inputs[0]?.[0];if(!input)return true;
    const step=sampleRate/16000;
    while(this.phase<input.length){this.samples.push(Math.max(-32768,Math.min(32767,Math.round(input[Math.floor(this.phase)]*32767))));this.phase+=step;}
    this.phase-=input.length;
    if(this.samples.length>=1600){const data=new Int16Array(this.samples.splice(0,1600));this.port.postMessage(data.buffer,[data.buffer]);}
    return true;
  }
}
registerProcessor('lockdown-voice',LockdownVoice);
