const paths={
  arrow:'<path d="M5 12h14m-6-6 6 6-6 6"/>',
  close:'<path d="m6 6 12 12M6 18 18 6"/>',
  people:'<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2m20 0v-2a4 4 0 0 0-3-3.87M15 3.13a4 4 0 0 1 0 7.75"/><circle cx="9" cy="7" r="4"/>',
  shield:'<path d="m12 3 8 3v6c0 5-8 9-8 9s-8-4-8-9V6z"/><path d="m9 12 2 2 4-4"/>',
  settings:'<path d="M4 7h16M4 17h16"/><circle cx="8" cy="7" r="3"/><circle cx="16" cy="17" r="3"/>',
  route:'<path d="M5 20V8l7-5 7 5v12M5 14h14M9 20v-6m6 6v-6"/>',
  signal:'<rect x="7" y="2" width="10" height="18" rx="4"/><circle cx="12" cy="7" r="2"/><circle cx="12" cy="14" r="2"/><path d="M12 20v3"/>',
  grid:'<path d="M4 4h6v6H4zm10 0h6v6h-6zM4 14h6v6H4zm10 0h6v6h-6z"/>',
  colors:'<path d="m12 2 10 5-10 5L2 7zm-10 10 10 5 10-5M2 17l10 5 10-5"/>',
  rotate:'<path d="M20 7V3l-3 3a8 8 0 1 0 3 10M16 3h4v4"/><path d="M12 7v5l3 2"/>',
  flag:'<path d="M4 22V3c5-4 10 4 16 0v12c-6 4-11-4-16 0"/>',
  mic:'<rect x="9" y="2" width="6" height="12" rx="3"/><path d="M5 10v2a7 7 0 0 0 14 0v-2M12 19v3m-4 0h8"/>',
  volume:'<path d="m11 5-6 4H2v6h3l6 4zm4 3a6 6 0 0 1 0 8m3-11a10 10 0 0 1 0 14"/>',
  copy:'<rect x="8" y="8" width="12" height="13" rx="2"/><path d="M16 8V3H3v13h5"/>',
  lock:'<rect x="4" y="10" width="16" height="12" rx="2"/><path d="M8 10V6a4 4 0 0 1 8 0v4m-4 5v3"/>',
  play:'<path d="m7 3 14 9-14 9z"/>',
  chevron:'<path d="m9 5 7 7-7 7"/>',
  check:'<path d="m4 12 5 5L20 6"/>',
  globe:'<circle cx="12" cy="12" r="9"/><ellipse cx="12" cy="12" rx="4" ry="9"/><path d="M3 12h18"/>',
  exit:'<path d="M9 3H3v18h6m5-16 7 7-7 7m-7-7h14"/>',
  info:'<circle cx="12" cy="12" r="9"/><path d="M12 11v6m0-11v2"/>',
  trophy:'<path d="M7 3h10v5a5 5 0 0 1-10 0zM7 5H3v3a4 4 0 0 0 5 4m9-7h4v3a4 4 0 0 1-5 4M12 13v7m-5 1h10"/>',
  map:'<path d="m3 5 6-3 6 3 6-3v17l-6 3-6-3-6 3zm6-3v17m6-14v17"/>'
};
export const icon=(name,size=20)=>`<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths[name]||paths.grid}</svg>`;
export const logo=()=>'<span class="brand-mark"><i></i><i></i><i></i></span>';
export function schematic(id){const shapes={parkour:'<path d="M22 75h20v-9h22V53h22V40h22V25h24"/><path d="M132 13v26m-7-20 7-6 7 6"/>',redlight:'<path d="M24 83h112M24 64h112M24 45h112"/><rect x="65" y="9" width="30" height="23" rx="11"/><circle cx="75" cy="20" r="4"/><circle cx="86" cy="20" r="4"/>',glass:'<path d="m50 90 15-80m30 80-15-80M42 75h60M46 58h52M50 42h44M55 27h34"/>',colors:'<path d="m80 15 60 30-60 30-60-30zm-40 20 60 30m-20-40 40 20M60 65l60-30M40 55l60-30"/>',sweeper:'<ellipse cx="80" cy="60" rx="59" ry="25"/><path d="m36 44 88 32M80 60V27"/><circle cx="80" cy="25" r="5"/>',race:'<path d="M42 20h76c32 0 32 60 0 60H42c-32 0-32-60 0-60zm3 15h70c15 0 15 30 0 30H45c-15 0-15-30 0-30z"/><path d="M80 20v15m0 30v15"/>'};return `<svg class="schematic" viewBox="0 0 160 100" fill="none" stroke="currentColor" stroke-width="1.6">${shapes[id]}</svg>`;}
