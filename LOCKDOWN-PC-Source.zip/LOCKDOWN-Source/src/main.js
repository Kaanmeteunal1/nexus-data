import '@fontsource/barlow-condensed/latin-600.css';
import '@fontsource/barlow-condensed/latin-700.css';
import '@fontsource/barlow-condensed/latin-ext-600.css';
import '@fontsource/barlow-condensed/latin-ext-700.css';
import '@fontsource/dm-sans/latin-400.css';
import '@fontsource/dm-sans/latin-500.css';
import '@fontsource/dm-sans/latin-600.css';
import '@fontsource/dm-sans/latin-ext-400.css';
import '@fontsource/dm-sans/latin-ext-500.css';
import '@fontsource/dm-sans/latin-ext-600.css';
import './style.css';
import { Engine } from './engine.js';
import { Network,localMode } from './network.js';
import { AudioSystem } from './audio.js';
import { icon,logo,schematic } from './icons.js';
import { MAPS,GAMES,COLOR_PALETTE,COMMANDS,lightPhase,colorPhase,MAX_PLAYERS,RACE_GATES } from '../shared/game.js';

const $=(q)=>document.querySelector(q),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function read(key,fallback){try{return JSON.parse(localStorage.getItem(key))??fallback;}catch{return fallback;}}
function save(key,value){try{localStorage.setItem(key,JSON.stringify(value));}catch{}}
const settings={volume:.65,voiceVolume:.8,sensitivity:1,quality:'high',fov:78,motion:true,...read('lockdown.settings',{})};
const profile={name:'',completed:0,best:{},...read('lockdown.profile',{})};
let engine,network,room=null,myId=null,modal=null,selectedMap='blackwater',selectedMode='sandbox',status='connecting',lastResult=null,uiTick=0,voiceReady=false,chatOpen=false,hideHud=false,ping=0,pending=false;
const audio=new AudioSystem(settings),app=$('#app');
app.innerHTML='<div id="shell"></div><div id="overlay"></div><div id="toasts" aria-live="polite"></div><div id="fatal"></div>';
const roleLabel=role=>role==='warden'?'BAŞ GARDİYAN':role==='guard'?'GARDİYAN':'MAHKÛM';
const me=()=>room?.players.find(p=>p.id===myId);
const host=()=>room?.host===myId;
const warden=()=>['warden','guard'].includes(me()?.role);
const button=(action,text,ic='arrow',cls='primary',extra='')=>`<button class="button ${cls}" data-action="${action}" ${extra}><span>${text}</span>${icon(ic)}</button>`;
const smallLabel=(text)=>`<span class="eyebrow">${text}</span>`;

function home(){
  $('#shell').innerHTML=`<main class="home">
    <header class="home-header"><button data-action="home" class="brand" aria-label="LOCKDOWN ana sayfa">${logo()}<span>LOCKDOWN<small>BLACKWATER</small></span></button>
    <nav aria-label="Ana menü"><button class="nav-link active" data-action="home">OYNA</button><button class="nav-link" data-action="guide">SAHA REHBERİ</button><button class="nav-link" data-action="settings">AYARLAR</button></nav>
    <span class="online-status"><i class="status-dot"></i><span data-status>SUNUCUYA BAĞLANILIYOR</span></span></header>
    <div class="hero">
      <div class="kicker"><span class="tiny-line"></span> ÖZGÜRLÜK BİR TAKIM OYUNU.</div>
      <h1>LOCK<span>DOWN</span><sup>™</sup></h1>
      <div class="hero-subtitle"><span>BLACKWATER</span><i></i><span>PRISON PLAYGROUND</span></div>
      <p class="hero-copy">Kuralları koy. Sınırları zorla.<br>Bu avluda hikâyeyi <strong>siz yazarsınız.</strong></p>
      <div class="hero-actions">${button('quick','TESİSE GİR','arrow','primary large')}${button('setup',localMode?'OTURUM AYARLA':'ÖZEL ODA','people','outline large')}</div>
      ${localMode?'<div class="join-link">Çevrimdışı sürüm <span>Tek oyunculu · Kurulum gerektirmez</span></div>':`<button class="join-link" data-action="join">Bir davetin mi var? <span>Oda koduyla katıl ${icon('chevron',14)}</span></button>`}
      <div class="hero-specs"><div><b>03</b><span>ÖZGÜN TESİS</span></div><i></i><div><b>06</b><span>ARENA OYUNU</span></div><i></i><div><b>16</b><span>OYUNCUYA KADAR</span></div></div>
    </div>
    <div class="world-caption"><span class="cross-tick">+</span><div><span class="eyebrow">CANLI TESİS GÖRÜNTÜSÜ / <span id="map-time">${MAPS[selectedMap].time}</span></span><strong id="map-caption">${MAPS[selectedMap].name}</strong><span id="map-subtitle">${MAPS[selectedMap].subtitle}</span></div><span class="view-coordinates">SECTOR 07<br>CAM_004 ● LIVE</span></div>
    <div class="map-selector"><div class="map-select-label">${smallLabel('TESİS SEÇİMİ')}<span>01 — 03</span></div><div class="map-cards">${Object.values(MAPS).map(s=>mapCard(s)).join('')}</div></div>
    <footer class="home-footer"><span><i class="status-dot"></i> ARKADAŞLARINLA. KENDİ KURALLARINLA.</span><span>${icon('globe',14)} TARAYICIDA OYNA <b>·</b> İNDİRME GEREKTİRMEZ</span><span>PC / KLAVYE + FARE <b>↗</b></span></footer>
    <div class="home-vignette"></div>
  </main>`;
  updateStatus();
}
function mapCard(s,action='map'){return `<button class="map-card ${selectedMap===s.id?'selected':''} ${s.id}" data-action="${action}" data-map="${s.id}" aria-label="${s.name} tesisini seç"><div class="map-art"><div class="map-building one"></div><div class="map-building two"></div><div class="map-building three"></div><div class="map-fence"></div><span class="map-number">${s.number}</span><span class="map-check">${icon('check',13)}</span></div><div class="map-card-caption"><strong>${s.name}</strong><span>${s.tag}</span></div></button>`;}
function updateStatus(){document.querySelectorAll('[data-status]').forEach(el=>el.textContent=localMode?'YEREL ANTRENMAN SÜRÜMÜ':status==='online'?'SİSTEMLER ÇEVRİMİÇİ':status==='offline'?'BAĞLANTI YENİLENİYOR':'SUNUCUYA BAĞLANILIYOR');document.querySelectorAll('.online-status .status-dot').forEach(el=>el.classList.toggle('offline',status!=='online'));const s=$('#connection-alert');if(s)s.hidden=status==='online';}
function hud(){
  $('#shell').innerHTML=`<main class="hud" id="hud">
    <div class="hud-top"><div class="hud-brand">${logo()}<div><strong>LOCKDOWN</strong><span id="hud-location">${MAPS[room.map].name} / AVLU 07</span></div></div><div id="activity" class="activity"><span class="eyebrow">${room.mode==='sandbox'?'SERBEST DOLAŞIM':'JAILBREAK'}</span><strong>AVLU 07</strong><small>Hikâyeyi siz yazın.</small></div>
    <div class="room-info"><button class="room-code" data-action="copy" title="Davet bağlantısını kopyala"><span>ODA KODU</span><strong>${room.code}</strong>${icon('copy',15)}</button><button class="icon-button" data-action="scoreboard" title="Oyuncular">${icon('people')}<span id="player-count">1</span></button><button class="icon-button" data-action="pause" title="Menü">${icon('settings')}</button></div></div>
    <div id="connection-alert" class="connection-alert" hidden>Bağlantı yeniden kuruluyor…</div>
    <div id="command-banner" class="command-banner" hidden></div>
    <div id="countdown" class="countdown" hidden></div>
    <div class="crosshair"><i></i><i></i><i></i><i></i></div><div id="player-labels"></div>
    <div id="interact" class="interact" hidden></div>
    <div class="hud-bottom"><div class="player-card"><div class="player-emblem">${icon('shield',26)}</div><div class="player-details"><span id="player-role">${roleLabel(me()?.role)}</span><strong>${esc(profile.name||'Mahkûm')}</strong><div class="stamina-track"><i id="stamina"></i></div><small>DAYANIKLILIK <span id="stamina-value">100</span></small></div></div>
    <div class="key-hints"><button data-action="games"><kbd>M</kbd> Oyunlar</button><button data-action="warden"><kbd>G</kbd> Komut</button><button data-action="chat"><kbd>T</kbd> Sohbet</button><button data-action="voice" id="voice-hint"><kbd>V</kbd> Bas konuş</button><button data-action="pause"><kbd>ESC</kbd> Menü</button></div>
    <div class="radar-wrap"><div class="radar-top"><span id="radar-label">AVLU 07</span><span>N ↑</span></div><canvas id="radar" width="160" height="112"></canvas><div class="radar-bottom"><span id="net-ping">— MS</span><span id="fps">60 FPS</span></div></div></div>
    <div id="chat" class="chat"><div id="chat-messages" aria-live="polite"></div><form id="chat-form" hidden><span>ODA</span><input id="chat-input" maxlength="180" autocomplete="off" placeholder="Mesajını yaz…" aria-label="Oda mesajı"/><button aria-label="Gönder">${icon('arrow',18)}</button></form></div>
    <div id="voice-indicator" hidden>${icon('mic',16)} YAYINDASIN</div>
  </main>`;updateStatus();
}
function dialogHeader(eyebrow,title,description=''){return `<div class="dialog-header"><div>${smallLabel(eyebrow)}<h2>${title}</h2>${description?`<p>${description}</p>`:''}</div><button class="icon-button close" data-action="close" aria-label="Kapat">${icon('close')}</button></div>`;}
function openModal(type){modal=type;engine?.unlock();if(engine)engine.paused=true;renderModal();}
function closeModal(lock=true){modal=null;$('#overlay').innerHTML='';if(engine)engine.paused=false;if(room&&lock)engine?.lock();}
function gameCards(play=false){return `<div class="game-grid">${Object.values(GAMES).map(g=>`<button class="game-card" style="--card-accent:${g.color}" data-action="${play?'start-game':'game-info'}" data-game="${g.id}"><div class="game-art"><span>${g.number} / ${g.label}</span>${schematic(g.id)}<span class="game-duration">${g.duration}s</span></div><div class="game-content"><span>${g.en}</span><h3>${g.name}</h3><p>${g.description}</p><div class="game-card-foot"><span>${play?'OYNA':'KURALLARI GÖR'}</span>${icon('arrow',18)}</div></div></button>`).join('')}</div>`;}
function renderModal(){
  let body='',cls='';
  if(modal==='setup') {cls='wide';body=`${dialogHeader('ÖZEL OTURUM / 01','KENDİ AVLINI KUR.','Bir oda aç. Kodu paylaş. Kuralları birlikte belirleyin.')}
    <form id="create-form"><div class="setup-grid"><div><label class="field">ÇAĞRI ADIN<input id="player-name" name="name" maxlength="22" placeholder="Örn. GeceVardiyası" value="${esc(profile.name)}" required autocomplete="nickname"/></label><label class="field">ODA KAPASİTESİ<select id="max-players"><option value="8">8 oyuncu</option><option value="12" selected>12 oyuncu</option><option value="16">16 oyuncu</option></select></label><div class="privacy-note">${icon('lock',16)} Özel oda. Yalnızca kodu olanlar katılır.</div></div><div><span class="field-label">OYUN BİÇİMİ</span><div class="mode-options"><button type="button" class="mode-card ${selectedMode==='sandbox'?'selected':''}" data-action="mode" data-mode="sandbox">${icon('globe',23)}<span><b>SERBEST ALAN</b><small>Oyunları dene, keşfet, kendi RP’ni yap.</small></span><i></i></button><button type="button" class="mode-card ${selectedMode==='jailbreak'?'selected':''}" data-action="mode" data-mode="jailbreak">${icon('shield',23)}<span><b>JAILBREAK</b><small>Gardiyan yönetir. Mahkûmlar yarışır.</small></span><i></i></button></div></div></div>
    <div class="field-label spaced">TESİS</div><div class="setup-maps">${Object.values(MAPS).map(s=>mapCard(s)).join('')}</div>
    <div class="dialog-footer"><span>${icon('info',16)} Mikrofon isteğe bağlıdır.</span><button class="button primary" type="submit"><span>ODAYI OLUŞTUR</span>${icon('arrow')}</button></div></form>`;}
  else if(modal==='join'){body=`${dialogHeader('DAVETLİ GİRİŞİ','EKİBİNE KATIL.','Arkadaşının paylaştığı altı haneli oda kodunu gir.')}
    <form id="join-form"><label class="field">ÇAĞRI ADIN<input id="player-name" maxlength="22" value="${esc(profile.name)}" placeholder="Sana ne diyelim?" required autocomplete="nickname"/></label><label class="field">ODA KODU<input id="join-code" class="code-input" maxlength="6" minlength="6" pattern="[A-Za-z0-9]{6}" placeholder="A1B2C3" value="${esc(new URLSearchParams(location.search).get('room')||'')}" required autocomplete="off"/></label><button class="button primary full" type="submit"><span>TESİSE GİRİŞ YAP</span>${icon('arrow')}</button><p class="form-note">Oda sahibi oyunda olduğu sürece katılabilirsin.</p></form>`;}
  else if(modal==='guide'||modal==='games'){cls='wide';const play=modal==='games';body=`${dialogHeader(play?'TESİS AKTİVİTELERİ':'SAHA REHBERİ',play?'SIRADAKİ HAMLE.':'HER AVLUDA BİR OYUN.',play?(room.mode==='jailbreak'?'Gardiyan bir oyunu başlattığında tüm oda aynı tura katılır.':'Bir oyuna gir ve kendi hızında dene. Ortak tur için gardiyan panelini kullan.'):'Altı farklı mücadele. Üç farklı atmosfer. Aynı ekip.')}${gameCards(play)}<div class="guide-controls"><span><kbd>W A S D</kbd> Hareket</span><span><kbd>FARE</kbd> Bakış</span><span><kbd>SPACE</kbd> Zıpla</span><span><kbd>SHIFT</kbd> Koş</span><span><kbd>CTRL</kbd> Çömel</span><span><kbd>C</kbd> Kamera</span><span><kbd>R</kbd> Yeniden doğ</span></div>`;}
  else if(modal?.startsWith('info:')) {const g=GAMES[modal.split(':')[1]];body=`${dialogHeader(`${g.number} / ${g.label}`,g.name,g.description)}<div class="info-art" style="color:${g.color}">${schematic(g.id)}</div><div class="rule-box">${icon('info')}<p>${g.rule}</p></div><div class="info-stats"><span>SÜRE <b>${g.duration} SANİYE</b></span><span>EN İYİ <b>${profile.best[g.id]?profile.best[g.id].toFixed(2)+'s':'—'}</b></span></div>${button(room?'start-game':'quick',room?'OYUNA GİR':'TESİSE GİR','arrow','primary full',`data-game="${g.id}"`)}`;}
  else if(modal==='settings'){body=`${dialogHeader('KİŞİSEL AYARLAR','KENDİ RİTMİN.')}
    <label class="slider-field"><span>Ana ses <b id="volume-value">${Math.round(settings.volume*100)}%</b></span><input type="range" data-setting="volume" min="0" max="1" step=".05" value="${settings.volume}"/></label>
    <label class="slider-field"><span>Sesli sohbet <b id="voiceVolume-value">${Math.round(settings.voiceVolume*100)}%</b></span><input type="range" data-setting="voiceVolume" min="0" max="1" step=".05" value="${settings.voiceVolume}"/></label>
    <label class="slider-field"><span>Fare hassasiyeti <b id="sensitivity-value">${settings.sensitivity.toFixed(1)}</b></span><input type="range" data-setting="sensitivity" min=".2" max="3" step=".1" value="${settings.sensitivity}"/></label>
    <label class="slider-field"><span>Görüş alanı <b id="fov-value">${settings.fov}°</b></span><input type="range" data-setting="fov" min="60" max="100" step="1" value="${settings.fov}"/></label>
    <label class="field">GÖRÜNTÜ KALİTESİ<select data-setting="quality"><option value="high" ${settings.quality==='high'?'selected':''}>Yüksek · gölgeler ve ışık parlaması</option><option value="medium" ${settings.quality==='medium'?'selected':''}>Dengeli · gölgeler</option><option value="low" ${settings.quality==='low'?'selected':''}>Performans · düşük donanım</option></select></label>
    <label class="toggle-field"><span>Hareketli kamera</span><input type="checkbox" data-setting="motion" ${settings.motion?'checked':''}/><i></i></label>
    <div class="settings-footer">${icon('check',16)} Ayarlar bu tarayıcıya otomatik kaydedilir.</div>`;}
  else if(modal==='onboard'){body=`${dialogHeader('GİRİŞ ONAYLANDI / '+room.code,'AVLUYA HOŞ GELDİN.',room.mode==='jailbreak'?'Gardiyan komut verir. Mahkûmlar görevleri tamamlar. Kendi rolünü oyna.':'Özgürce dolaş. Avludaki terminallerden bir oyun seç veya kendi hikâyeni kur.')}
    <div class="welcome-role">${icon('shield',30)}<div><span>BU OTURUMDA</span><strong>${roleLabel(me()?.role)}</strong></div><span class="role-badge">${room.mode==='sandbox'?'SERBEST':'JAILBREAK'}</span></div>
    <div class="controls-list"><div><kbd>W A S D</kbd><span>Hareket et</span></div><div><kbd>FARE</kbd><span>Etrafına bak</span></div><div><kbd>SPACE</kbd><span>Zıpla</span></div><div><kbd>SHIFT</kbd><span>Koş</span></div><div><kbd>E</kbd><span>Terminali kullan</span></div><div><kbd>M</kbd><span>Oyunları aç</span></div><div><kbd>G</kbd><span>Gardiyan paneli</span></div><div><kbd>ESC</kbd><span>Fareyi serbest bırak</span></div></div>
    ${button('enter','HAZIRIM. KAPILARI AÇ.','arrow','primary full')}<button class="text-button full" data-action="copy">${icon('copy',16)} Arkadaşlarını davet et · ${room.code}</button>`;}
  else if(modal==='pause'){body=`${dialogHeader('TESİS / '+MAPS[room.map].name,'BİR NEFES AL.','Oyun dünyasında zaman akmaya devam eder.')}<div class="pause-buttons">${button('enter','OYUNA DÖN','play','primary')}${button('games','OYUN ALANLARI','grid','outline')}${button('scoreboard','OYUNCULAR','people','outline')}${!localMode?button('voice',voiceReady?'MİKROFONU KAPAT':'MİKROFONU ETKİNLEŞTİR','mic','outline'):''}${button('settings','AYARLAR','settings','outline')}${button('hub','AVLUYA DÖN','map','outline')}${button('leave','ODADAN AYRIL','exit','quiet')}</div>`;}
  else if(modal==='warden'){cls='wide';if(!warden())body=`${dialogHeader('YETKİ ALANI','KOMUTA MERKEZİ.','Bu panel gardiyanlara aittir. Oda sahibi sana gardiyan rolü verebilir.')}<div class="rule-box">${icon('shield',36)}<p>Mevcut rolün: ${roleLabel(me()?.role)}.<br>Oda sohbetinden gardiyanla iletişime geçebilirsin.</p></div>`;
    else body=`${dialogHeader('GARDİYAN KONSOLU','KONTROL SENDE.','Komutları anons et, kapıları yönet ve tüm oda için bir tur başlat.')}
      <div class="warden-grid"><section><span class="field-label">HIZLI KOMUTLAR</span><div class="command-grid">${Object.entries(COMMANDS).map(([id,text])=>`<button data-action="command" data-command="${id}">${icon(id==='freeze'?'lock':'shield',16)}${text}</button>`).join('')}</div><form id="command-form"><input id="custom-command" maxlength="100" placeholder="Kendi komutunu yaz…" aria-label="Özel gardiyan komutu"/><button class="icon-button" title="Anons et">${icon('arrow')}</button></form>
      <div class="door-control"><span>${icon('lock')} HÜCRE KAPILARI <b>${room.cellsOpen?'AÇIK':'KİLİTLİ'}</b></span><button class="button outline small" data-action="cells">${room.cellsOpen?'KİLİTLE':'KAPILARI AÇ'}</button></div>
      <span class="field-label spaced">YENİ TUR BAŞLAT</span><div class="round-buttons">${Object.values(GAMES).map(g=>`<button data-action="round" data-game="${g.id}">${icon(g.icon,19)}<span>${g.name}</span>${icon('chevron',15)}</button>`).join('')}</div>${room.round?button('end-round','TURU BİTİR VE AVLUYA DÖN','exit','quiet full'):''}</section>
      <section class="roster-section"><span class="field-label">TESİSTEKİLER / ${room.players.length}</span><div id="warden-roster">${roster(true)}</div>${host()?`<span class="field-label spaced">TESİS DEĞİŞTİR</span><select id="switch-map" aria-label="Yeni tesis">${Object.values(MAPS).map(s=>`<option value="${s.id}" ${room.map===s.id?'selected':''}>${s.name}</option>`).join('')}</select>${button('switch-map','TESİSİ DEĞİŞTİR','map','outline full small')}`:''}</section></div>`;
  }
  else if(modal==='scoreboard'){cls='medium';body=`${dialogHeader('ÖZEL ODA / '+room.code,'AYNI AVLU.','Oyuncu puanları bu oturum boyunca tutulur.')}<div id="score-roster">${roster(false)}</div><div class="dialog-footer"><span>${room.players.length} / ${room.maxPlayers} oyuncu</span>${button('copy','DAVETİ KOPYALA','copy','outline small')}</div>`;}
  else if(modal==='result'&&lastResult){const r=lastResult;body=`<div class="result-heading ${r.success?'win':'loss'}">${icon(r.success?'trophy':'rotate',48)}<span class="eyebrow">${GAMES[r.game].en} / TUR SONUCU</span><h2>${r.success?'İŞTE BU.':'BİR DAHA.'}</h2><p>${esc(r.reason)}</p></div><div class="result-stats"><div><span>SÜRE</span><strong>${r.elapsed.toFixed(2)}<small>s</small></strong></div><div><span>PUAN</span><strong>+${r.score}</strong></div><div><span>TEKRAR</span><strong>${r.attempts}</strong></div></div><div id="result-board">${resultBoard()}</div><div class="pause-buttons">${room.round?.state==='active'?button('enter','DİĞER OYUNCULARI İZLE','people','primary'):room.round&&!warden()?button('enter','GARDİYANIN KOMUTUNU BEKLE','shield','primary'):button('retry','TEKRAR DENE','rotate','primary')}${button('hub','AVLUYA DÖN','arrow','outline')}</div>`;}
  if(!body){$('#overlay').innerHTML='';return;}
  $('#overlay').innerHTML=`<div class="modal-backdrop"><section class="dialog ${cls}" role="dialog" aria-modal="true" aria-label="${esc(modal)}">${body}</section></div>`;
  if(['join','setup'].includes(modal))setTimeout(()=>$('#player-name')?.focus(),50);
}
function roster(admin){return room.players.slice().sort((a,b)=>b.score-a.score).map((p,i)=>`<div class="roster-row"><span class="roster-index">${String(i+1).padStart(2,'0')}</span><span class="roster-avatar ${p.role}">${icon(p.role==='prisoner'?'people':'shield',18)}</span><div class="roster-name"><b>${esc(p.name)} ${p.id===myId?'<em>SEN</em>':''}</b><small>${roleLabel(p.role)}${p.connected?'':' · BAĞLANTI KESİLDİ'}</small></div>${admin&&host()&&p.id!==myId?`<button class="role-switch" data-action="role" data-id="${p.id}" data-role="${p.role==='prisoner'?'guard':'prisoner'}">${p.role==='prisoner'?'GARDİYAN YAP':'MAHKÛM YAP'}</button><button class="icon-button" data-action="kick" data-id="${p.id}" title="Odadan çıkar">${icon('exit',14)}</button>`:`<strong class="roster-score">${p.score}</strong>`}${p.id!==myId?`<button class="icon-button ${audio.muted.has(p.id)?'muted':''}" data-action="mute" data-id="${p.id}" title="Sesi aç/kapat">${icon('volume',16)}</button>`:''}</div>`).join('');}
function resultBoard(){const results=room?.round?.results;if(!results?.length)return '';return `<div class="result-board"><span class="field-label">TUR TABLOSU</span>${results.slice().sort((a,b)=>Number(b.success)-Number(a.success)||a.elapsed-b.elapsed).map(r=>`<div><span>${r.success?'✓':'—'} ${esc(r.name)}</span><b>${r.success?r.elapsed.toFixed(2)+'s':'ELENDİ'}</b></div>`).join('')}</div>`;}
function toast(message){const el=document.createElement('div');el.className='toast';el.innerHTML=`${icon('info',17)}<span>${esc(message)}</span>`;$('#toasts').append(el);if($('#toasts').children.length>4)$('#toasts').firstChild.remove();setTimeout(()=>el.remove(),4800);}
async function connectRoom(type,extra={}){if(pending)return;profile.name=($('#player-name')?.value||profile.name||`Ziyaretçi ${Math.floor(Math.random()*900+100)}`).trim();save('lockdown.profile',profile);pending=true;document.body.classList.add('loading');try{await audio.init();await network.request(type,{name:profile.name,map:selectedMap,mode:selectedMode,...extra});setTimeout(()=>{pending=false;document.body.classList.remove('loading');},5000);}catch(e){pending=false;document.body.classList.remove('loading');toast(e.message);}}
async function copyInvite(){if(localMode){toast('Bu dosya tek oyunculu çalışır. Çok oyunculu odalar sunucu sürümündedir.');return;}const url=new URL(location.href);url.search='';url.searchParams.set('room',room.code);try{await navigator.clipboard.writeText(url.href);toast('Davet bağlantısı kopyalandı. Arkadaşlarınla paylaş.');}catch{toast(`Oda kodun: ${room.code}`);}}
function startGame(id,all=false){if(!GAMES[id])return;if(all&&!warden()){toast('Turu gardiyan başlatabilir.');return;}if(room.mode==='jailbreak'&&!warden()){toast('Bu modda oyunu gardiyan başlatır.');return;}network.send(all||room.mode==='jailbreak'?'startGame':'practice',{game:id});closeModal();}
function chat(){if(!room)return;closeModal(false);engine.unlock();chatOpen=true;const form=$('#chat-form');form.hidden=false;$('#chat-input').focus();}
function closeChat(){chatOpen=false;$('#chat-form').hidden=true;$('#chat-input').blur();engine.lock();}
async function enableVoice(){if(localMode){toast('Sesli sohbet çok oyunculu sunucu sürümündedir.');return;}if(voiceReady){audio.stopVoice();voiceReady=false;$('#voice-hint')?.classList.remove('enabled');toast('Mikrofon kapatıldı.');if(modal==='pause')renderModal();return;}try{await audio.enableVoice(data=>network.send('voice',{audio:data}));voiceReady=true;toast('Mikrofon hazır. Konuşmak için V tuşunu basılı tut.');$('#voice-hint')?.classList.add('enabled');if(modal==='pause')renderModal();}catch(e){toast(e.name==='NotAllowedError'?'Mikrofon izni verilmedi. Yazılı sohbeti kullanabilirsin.':e.message);}}
function voice(active){if(!room)return;if(active&&!voiceReady){enableVoice();return;}audio.voiceActive=active;if($('#voice-indicator'))$('#voice-indicator').hidden=!active;}
function leave(){network.send('leave');network.token=null;audio.stopVoice();voiceReady=false;engine.stop();room=null;myId=null;closeModal(false);home();history.replaceState(null,'',location.pathname);}

document.addEventListener('click',async e=>{
  const b=e.target.closest('[data-action]');if(!b)return;const action=b.dataset.action;audio.play('click');
  if(action==='home'){closeModal(false);return;}
  if(['setup','join','guide','settings','games','warden','scoreboard','pause'].includes(action)){if(localMode&&action==='join'){toast('Bu dosya tek oyunculu çalışır. Davetle katılmak için sunucu sürümü gerekir.');return;}openModal(action);return;}
  if(action==='map'){selectedMap=b.dataset.map;if(!room)engine.loadMap(selectedMap);if(modal==='setup'){profile.name=$('#player-name').value;renderModal();}else{home();}return;}
  if(action==='mode'){profile.name=$('#player-name').value;selectedMode=b.dataset.mode;renderModal();return;}
  if(action==='quick'){selectedMode='sandbox';await connectRoom('create',{maxPlayers:12});return;}
  if(action==='close'){closeModal();return;}
  if(action==='enter'){await audio.init();closeModal();return;}
  if(action==='game-info'){openModal(`info:${b.dataset.game}`);return;}
  if(action==='start-game'){startGame(b.dataset.game);return;}
  if(action==='round'){startGame(b.dataset.game,true);return;}
  if(action==='retry'){if(room.round){network.send('startGame',{game:lastResult.game});closeModal();}else startGame(lastResult.game);return;}
  if(action==='copy'){copyInvite();return;}
  if(action==='chat'){chat();return;}
  if(action==='voice'){enableVoice();return;}
  if(action==='command'){network.send('command',{command:b.dataset.command});closeModal();return;}
  if(action==='cells'){network.send('cells',{open:!room.cellsOpen});closeModal();return;}
  if(action==='role'){network.send('role',{id:b.dataset.id,role:b.dataset.role});setTimeout(renderModal,160);return;}
  if(action==='kick'){network.send('kick',{id:b.dataset.id});setTimeout(renderModal,160);return;}
  if(action==='mute'){if(audio.muted.has(b.dataset.id))audio.muted.delete(b.dataset.id);else audio.muted.add(b.dataset.id);renderModal();return;}
  if(action==='end-round'){network.send('endRound');closeModal();return;}
  if(action==='switch-map'){network.send('setMap',{map:$('#switch-map').value});closeModal();return;}
  if(action==='hub'){network.send('hub');closeModal();return;}
  if(action==='leave'){leave();return;}
});
document.addEventListener('submit',e=>{
  e.preventDefault();const id=e.target.id;
  if(id==='create-form')connectRoom('create',{maxPlayers:Number($('#max-players').value)});
  if(id==='join-form')connectRoom('join',{code:$('#join-code').value});
  if(id==='chat-form'){const input=$('#chat-input');if(input.value.trim())network.send('chat',{text:input.value});input.value='';closeChat();}
  if(id==='command-form'){network.send('command',{text:$('#custom-command').value});closeModal();}
});
document.addEventListener('input',e=>{const key=e.target.dataset.setting;if(!key)return;settings[key]=e.target.type==='checkbox'?e.target.checked:e.target.type==='range'?Number(e.target.value):e.target.value;save('lockdown.settings',settings);audio.setVolume();const label=$(`#${key}-value`);if(label)label.textContent=key.includes('olume')?Math.round(settings[key]*100)+'%':key==='fov'?settings[key]+'°':settings[key].toFixed(1);if(key==='quality')engine.applySettings();});
document.addEventListener('keydown',e=>{if(e.code==='Escape'){if(chatOpen){closeChat();return;}if(modal&&modal!=='onboard')closeModal();}});

function received(msg){
  if(msg.type==='hello')return;
  if(msg.type==='joined'){const wasRoom=!!room;room=msg.room;room.timeOffset=room.serverTime-Date.now();myId=msg.id;pending=false;document.body.classList.remove('loading');engine.start(room,myId);hud();if(!wasRoom)openModal('onboard');else{closeModal(false);openModal('pause');toast('Bağlantı yeniden kuruldu.');}return;}
  if(msg.type==='state'&&room){room=msg.room;room.timeOffset=room.serverTime-Date.now();engine.setRoom(room);return;}
  if(msg.type==='teleport'){engine.teleport(msg.pos,msg.yaw);return;}
  if(msg.type==='notice')toast(msg.message);
  if(msg.type==='error'){toast(msg.message);pending=false;document.body.classList.remove('loading');if(msg.message.includes('Oturum sona erdi')){network.token=null;leave();}return;}
  if(msg.type==='command'){audio.play('command');const el=$('#command-banner');if(el){el.hidden=false;el.innerHTML=`${icon('shield',20)}<div><span>${esc(msg.by)} / GARDİYAN KOMUTU</span><strong>${esc(msg.text)}</strong></div>`;setTimeout(()=>el.hidden=true,9000);}return;}
  if(msg.type==='chat'){const el=document.createElement('p');el.innerHTML=`<b class="${msg.role}">${esc(msg.name)}</b><span>${esc(msg.text)}</span>`;$('#chat-messages')?.append(el);while($('#chat-messages')?.children.length>6)$('#chat-messages').firstChild.remove();return;}
  if(msg.type==='trial'){lastResult=null;audio.play('command');toast(GAMES[msg.game].rule);return;}
  if(msg.type==='checkpoint'){toast(msg.message);audio.play('checkpoint');return;}
  if(msg.type==='glassBreak'){audio.play('glass');return;}
  if(msg.type==='result'){lastResult=msg;audio.play(msg.success?'success':'fail');if(msg.success){profile.completed++;if(!profile.best[msg.game]||msg.elapsed<profile.best[msg.game])profile.best[msg.game]=msg.elapsed;save('lockdown.profile',profile);}openModal('result');return;}
  if(msg.type==='roundEnded'){setTimeout(()=>{if(modal==='result')renderModal();},160);return;}
  if(msg.type==='hub'){lastResult=null;if(modal==='result')openModal('pause');return;}
  if(msg.type==='mapChanged'){engine.loadMap(msg.map);if(room)room.map=msg.map;lastResult=null;if(modal==='result')openModal('pause');toast(`${MAPS[msg.map].name} tesisine geçildi.`);return;}
  if(msg.type==='kicked'){leave();toast('Oda yöneticisi seni odadan çıkardı.');return;}
  if(msg.type==='pong'){ping=Date.now()-msg.sent;return;}
  if(msg.type==='voice'&&room){const p=room.players.find(p=>p.id===msg.id);if(p){const distance=Math.hypot(engine.pos.x-p.pos[0],engine.pos.z-p.pos[2]);audio.receiveVoice(msg.id,msg.audio,distance,msg.radio);}return;}
}
function updateHud(frame){
  if(!room)return;
  const t=performance.now();if(t-uiTick<90)return;uiTick=t;
  $('#stamina').style.width=`${frame.stamina*100}%`;$('#stamina-value').textContent=Math.round(frame.stamina*100);$('#fps').textContent=`${frame.fps} FPS`;$('#net-ping').textContent=`${ping} MS`;$('#player-count').textContent=room.players.length;$('#player-role').textContent=roleLabel(me()?.role);
  const trial=me()?.trial,elapsed=trial?(Date.now()+room.timeOffset-trial.startedAt)/1000:0;
  const activity=$('#activity');
  if(trial){const g=GAMES[trial.game],remaining=Math.max(0,g.duration-elapsed);let cue=g.label;
    if(trial.game==='redlight'){const red=lightPhase(Math.max(0,elapsed)).red;cue=red?'KIRMIZI — DUR':'YEŞİL — İLERLE';activity.style.setProperty('--activity-color',red?'#ef806b':'#b9d7a0');}
    else if(trial.game==='colors'){const phase=colorPhase(Math.max(0,elapsed)),color=COLOR_PALETTE[phase.target];cue=`${color.name} ${phase.dropping?'· ZEMİN DÜŞÜYOR':`· ${phase.remaining.toFixed(1)}s`}`;activity.style.setProperty('--activity-color',color.value);}
    else {cue=trial.game==='race'?`TUR ${Math.min(2,trial.laps+1)}/2 · KAPI ${trial.gate+1}`:g.label;activity.style.setProperty('--activity-color',g.color);}
    activity.innerHTML=`<span class="eyebrow">${cue}</span><strong>${g.name}</strong><small>${Math.floor(remaining/60)}:${String(Math.floor(remaining%60)).padStart(2,'0')} <i>·</i> ${room.round?.state==='active'?'ORTAK TUR':'ANTRENMAN'}</small>`;
    $('#hud-location').textContent=`${MAPS[room.map].name} / ${g.en}`;$('#radar-label').textContent=g.en;
  }else{activity.style.setProperty('--activity-color','#e7b376');activity.innerHTML=`<span class="eyebrow">${room.mode==='sandbox'?'SERBEST DOLAŞIM':'JAILBREAK'}</span><strong>${me()?.status==='out'?'İZLEYİCİ':'AVLU 07'}</strong><small>${room.round?.state==='active'?'Tur devam ediyor.':'Hikâyeyi siz yazın.'}</small>`;$('#hud-location').textContent=`${MAPS[room.map].name} / AVLU 07`;$('#radar-label').textContent='AVLU 07';}
  const cd=$('#countdown');cd.hidden=!(trial&&elapsed<0);if(!cd.hidden)cd.innerHTML=`<span>HAZIR OL</span><strong>${Math.ceil(-elapsed)}</strong>`;
  const el=$('#interact');el.hidden=!frame.terminal||!!modal;if(!el.hidden){const g=GAMES[frame.terminal.game];el.innerHTML=`<kbd>E</kbd><div><span>${g.label}</span><strong>${g.name}</strong></div>${icon('arrow',18)}`;}
  $('#player-labels').innerHTML=engine.projectPlayers().map(p=>`<span class="player-label ${p.role}" style="left:${p.x}px;top:${p.y}px">${esc(p.name)}</span>`).join('');
  radar(frame.pos,trial);
}
function radar(pos,trial){const canvas=$('#radar');if(!canvas)return;const ctx=canvas.getContext('2d'),origin=trial?GAMES[trial.game].origin:[0,0],scale=trial?1.5:1.1;
  ctx.clearRect(0,0,160,112);ctx.save();ctx.translate(80,56);ctx.scale(scale,scale);
  ctx.strokeStyle='#465452';ctx.lineWidth=1/scale;ctx.fillStyle='#293533';
  if(!trial){ctx.fillRect(-33,-38,66,15);ctx.strokeRect(-42,-38,84,76);ctx.strokeRect(-33,-38,66,15);ctx.strokeStyle='#a58455';ctx.beginPath();ctx.moveTo(-22,8);ctx.lineTo(22,8);ctx.stroke();}
  else {ctx.strokeRect(-14,-30,28,60);if(trial.game==='race'){ctx.strokeRect(-23,-23,46,46);ctx.fillRect(-12,-12,24,24);RACE_GATES.forEach((g,i)=>{ctx.fillStyle=i===trial.gate?'#edbb7c':'#6e8179';ctx.fillRect(g[0]-2,g[1]-2,4,4);});}}
  for(const p of room.players){if(p.id===myId)continue;ctx.fillStyle=p.role==='prisoner'?'#d79465':'#8eced2';ctx.beginPath();ctx.arc(p.pos[0]-origin[0],p.pos[2]-origin[1],1.8,0,Math.PI*2);ctx.fill();}
  ctx.translate(pos.x-origin[0],pos.z-origin[1]);ctx.rotate(-engine.yaw);ctx.fillStyle='#f3ead6';ctx.beginPath();ctx.moveTo(0,-4);ctx.lineTo(-2.5,3);ctx.lineTo(2.5,3);ctx.closePath();ctx.fill();ctx.restore();}

home();
try{
  await document.fonts.ready;
  engine=new Engine($('#world'),{
    lock:locked=>{if(!locked&&room&&!modal&&!chatOpen)setTimeout(()=>{if(!engine.locked&&!modal&&!chatOpen)openModal('pause');},70);},
    notice:toast,interact:id=>startGame(id),respawn:()=>network.send('respawn'),menu:openModal,chat,voice,emote:emote=>network.send('emote',{emote}),sound:kind=>audio.play(kind),move:data=>network.send('move',data),frame:updateHud,hud:()=>{hideHud=!hideHud;$('#hud')?.classList.toggle('hidden-hud',hideHud);}
  },settings);
  network=new Network(received,s=>{status=s;updateStatus();});
  setInterval(()=>{if(room)network.send('ping',{sent:Date.now()});},2000);
  if(new URLSearchParams(location.search).has('room'))openModal('join');
  // Read-only diagnostics for support and automated browser validation.
  window.lockdown={get state(){return {room,myId,modal,status,pos:engine.pos.toArray(),fps:engine.fps,drawCalls:engine.renderer.info.render.calls};}};
}catch(error){console.error(error);$('#fatal').innerHTML=`<div class="fatal"><h2>Görüntü motoru başlatılamadı.</h2><p>WebGL 2 destekli güncel bir masaüstü tarayıcı ve donanım hızlandırması gerekiyor.</p><button onclick="location.reload()">Yeniden dene</button></div>`;}
