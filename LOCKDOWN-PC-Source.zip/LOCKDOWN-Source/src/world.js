import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { MAPS, GAMES, COLOR_PALETTE, parkourPlatforms, glassRows, tileColor, colorPhase, sweeperAngle, lightPhase, RACE_GATES } from '../shared/game.js';

const rng=seed=>()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296;};
function concreteTexture(seed=12) {
  const rand=rng(seed),c=document.createElement('canvas');c.width=c.height=512;const ctx=c.getContext('2d');
  const img=ctx.createImageData(512,512);
  for(let i=0;i<img.data.length;i+=4){const v=155+rand()*38;img.data[i]=v;img.data[i+1]=v;img.data[i+2]=v;img.data[i+3]=255;}ctx.putImageData(img,0,0);
  for(let i=0;i<1800;i++){ctx.fillStyle=`rgba(40,45,42,${rand()*.13})`;ctx.fillRect(rand()*512,rand()*512,rand()*13+1,rand()*2+1);}
  ctx.strokeStyle='rgba(30,38,36,.18)';ctx.lineWidth=2;
  for(let y=0;y<512;y+=128){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(512,y);ctx.stroke();}
  for(let y=12;y<512;y+=128)for(let x=18;x<512;x+=128){ctx.fillStyle='rgba(40,45,40,.35)';ctx.beginPath();ctx.arc(x,y,2.3,0,7);ctx.fill();}
  const texture=new THREE.CanvasTexture(c);texture.wrapS=texture.wrapT=THREE.RepeatWrapping;texture.repeat.set(2,2);texture.colorSpace=THREE.SRGBColorSpace;texture.anisotropy=4;return texture;
}
function signTexture(title,subtitle='',color='#dfb37a',width=1024) {
  const c=document.createElement('canvas');c.width=width;c.height=256;const ctx=c.getContext('2d');
  ctx.fillStyle='#192426';ctx.fillRect(0,0,width,256);ctx.fillStyle=color;ctx.fillRect(0,0,10,256);
  ctx.strokeStyle='#4b5855';ctx.lineWidth=2;ctx.strokeRect(22,22,width-44,212);
  ctx.fillStyle=color;ctx.font='600 86px "Barlow Condensed", sans-serif';ctx.fillText(title,48,133,width-96);
  ctx.fillStyle='#c0c7bc';ctx.font='22px "DM Sans", sans-serif';ctx.fillText(subtitle,50,196,width-100);
  const texture=new THREE.CanvasTexture(c);texture.colorSpace=THREE.SRGBColorSpace;return texture;
}

export class World {
  constructor(scene,map='blackwater') {this.scene=scene;this.group=new THREE.Group();scene.add(this.group);this.map=map;this.spec=MAPS[map];this.colliders=[];this.surfaces=[];this.terminals=[];this.gates=[];this.tiles=[];this.glass=[];this.batches=new Map();this.dynamic=[];this.lamps=[];this.textures=[];this.materials=[];this.build();}
  material(color,opts={}) {const m=new THREE.MeshStandardMaterial({color,roughness:.83,metalness:0,...opts});this.materials.push(m);return m;}
  mesh(geo,mat,pos,rot=[0,0,0],dynamic=false) {if(!geo.index)geo.setIndex(Array.from({length:geo.attributes.position.count},(_,i)=>i));const m=new THREE.Mesh(geo,mat);m.position.set(...pos);m.rotation.set(...rot);m.castShadow=true;m.receiveShadow=true;if(dynamic){this.group.add(m);this.dynamic.push(m);}else {m.updateMatrix();const key=mat.uuid;if(!this.batches.has(key))this.batches.set(key,{mat,geos:[]});const clone=geo.clone().applyMatrix4(m.matrix);this.batches.get(key).geos.push(clone);geo.dispose();}return m;}
  box(x,y,z,w,h,d,mat,solid=false,dynamic=false) {const m=this.mesh(new THREE.BoxGeometry(w,h,d),mat,[x,y,z],[0,0,0],dynamic);if(solid)this.colliders.push({x,z,minY:y-h/2,maxY:y+h/2,w,d,enabled:true,mesh:dynamic?m:null});return m;}
  floor(x,z,w,d,y=0,mat=this.ground,thickness=.4) {this.box(x,y-thickness/2,z,w,thickness,d,mat);const surface={x,z,w,d,y,enabled:true};this.surfaces.push(surface);return surface;}
  cyl(x,y,z,r,h,mat,r2=r,rot=[0,0,0]) {return this.mesh(new THREE.CylinderGeometry(r2,r,h,16),mat,[x,y,z],rot);}
  sign(title,subtitle,x,y,z,w=8,h=2,color=this.spec.accent,rot=0) {const texture=signTexture(title,subtitle,color);this.textures.push(texture);const m=new THREE.Mesh(new THREE.PlaneGeometry(w,h),new THREE.MeshBasicMaterial({map:texture,side:THREE.DoubleSide}));m.position.set(x,y,z);m.rotation.y=rot;this.group.add(m);return m;}
  line(x,z,w,d,color=this.yellow,y=.016) {this.box(x,y,z,w,.016,d,color);}
  rail(x,z,length,axis='x',y=0) {const n=Math.ceil(length/2);for(let i=0;i<=n;i++){const o=-length/2+length*i/n;this.cyl(x+(axis==='x'?o:0),y+.65,z+(axis==='z'?o:0),.045,1.3,this.steel);}
    this.box(x,y+1.28,z,axis==='x'?length:.06,.06,axis==='z'?length:.06,this.steel);
    this.box(x,y+.62,z,axis==='x'?length:.035,.035,axis==='z'?length:.035,this.steel);
  }
  lamp(x,z,height=8) {this.cyl(x,height/2,z,.12,height,this.dark);this.box(x,height,z+.8,.12,.12,1.8,this.dark);this.box(x,height-.1,z+1.5,.9,.12,.6,this.glow);this.lamps.push(new THREE.Vector3(x,height,z));}
  crate(x,z,w=1.5,h=1.4,d=1.5) {this.box(x,h/2,z,w,h,d,this.crateMat,true);for(const y of [.18,h-.18]){this.box(x,y,z+.01,w+.06,.08,d+.06,this.steel);}for(const a of [-1,1])this.box(x+a*w*.32,h/2,z+d/2+.018,.06,h,.035,this.steel);}
  build() {
    const s=this.spec,night=this.map==='ironworks',snow=this.map==='northstar';const tex=concreteTexture();this.textures.push(tex);
    this.concrete=this.material(s.concrete,{map:tex,bumpMap:tex,bumpScale:.07});
    const groundTex=tex.clone();groundTex.repeat.set(18,18);this.textures.push(groundTex);
    this.ground=this.material(s.ground,{map:groundTex,bumpMap:groundTex,bumpScale:.018});
    this.dark=this.material('#263739',{metalness:.5,roughness:.62});this.steel=this.material('#586969',{metalness:.72,roughness:.47});
    this.yellow=this.material(s.accent,{roughness:.78});this.white=this.material('#d5d3bf');this.black=this.material('#1e2b2c');
    this.glow=this.material('#f8dcaa',{emissive:'#edb66d',emissiveIntensity:night?3:1.8});
    this.cyan=this.material('#91d7d6',{emissive:'#6acac5',emissiveIntensity:1.3});this.rust=this.material('#815e48',{metalness:.25});
    this.crateMat=this.material('#637069');this.red=this.material('#ae5449');this.grass=this.material(snow?'#d7e0df':'#55665a');
    // Main facility: a playable courtyard and cell block, with cast concrete detail.
    this.floor(0,0,84,76,0,this.ground,1.2);
    this.floor(0,-32,60,18,.04,this.concrete);
    for(let x=-36;x<=36;x+=9){this.line(x,0,.025,70,this.dark);for(let z=-28;z<32;z+=10)this.line(x+4.5,z,9,.025,this.dark);}
    this.box(0,5,-40,66,10,1.2,this.concrete,true);
    for(const side of [-1,1]) {
      this.box(side*33,4.6,-31,1.2,9.2,19,this.concrete,true);
      this.box(side*42,3.3,0,1.4,6.6,76,this.concrete,true);
      this.box(side*42,6.8,0,1.8,.3,76,this.dark);
      for(let z=-35;z<=35;z+=5){this.box(side*41,3.3,z,.8,7,1,this.concrete);this.cyl(side*42,7.4,z,.035,1.2,this.steel);}
      for(let h=0;h<3;h++)this.box(side*42,7+h*.25,0,.025,.025,76,this.steel);
    }
    this.box(0,2.7,38,84,5.4,1.1,this.concrete,true);this.box(0,5.5,38,84,.2,1.6,this.dark);
    for(let x=-39;x<40;x+=5)this.box(x,2.7,37.6,.8,5.8,1.3,this.concrete);
    // Two-level cells, individual dividers, bunks, toilets and working grille doors.
    for(let i=0;i<8;i++){
      const x=-27.3+i*7.8;
      for(const level of [0,1]){
        const y=level*4.4;
        this.box(x-3.8,y+2.1,-33,.28,4.2,12,this.concrete,level===0);
        this.box(x,y+4.22,-32,7.8,.35,14,this.concrete);
        this.box(x,y+2,-39.3,2.2,1.4,.14,this.dark);
        for(let j=-1;j<=1;j++)this.box(x+j*.6,y+2,-39.15,.05,1.4,.06,this.steel);
        for(const by of [.65,2.05]) {this.box(x-2.3,y+by,-35,1.75,.12,3.4,this.steel);this.box(x-2.3,y+by+.15,-35,1.6,.24,3.2,this.crateMat);this.box(x-2.3,y+by+.29,-36,1.35,.16,.65,this.white);}
        this.cyl(x+2.4,y+.35,-37,.35,.65,this.white);this.box(x+2.4,y+.8,-37.3,.7,.8,.35,this.white);
        this.box(x,y+3.9,-25.2,7.8,.7,.9,this.concrete);
        const gate=new THREE.Group();gate.position.set(x,y,-25.2);this.group.add(gate);const bars=[];
        for(let j=-5;j<=5;j++)bars.push(new THREE.CylinderGeometry(.04,.04,3.5,8).translate(j*.65,1.75,0));
        for(const gy of [.15,1.75,3.4])bars.push(new THREE.BoxGeometry(7,.055,.1).translate(0,gy,0));
        const grille=new THREE.Mesh(mergeGeometries(bars),this.steel);grille.castShadow=true;gate.add(grille);bars.forEach(g=>g.dispose());
        if(level===0){const col={x,z:-25.2,w:7.2,d:.22,minY:0,maxY:3.6,enabled:false};this.colliders.push(col);this.gates.push({mesh:gate,base:y,col});}
        this.sign(`${String(i+1+level*8).padStart(2,'0')}`,'',x,y+3.8,-24.68,1,.25,s.accent);
      }
    }
    this.box(0,9.1,-32,67,.65,18,this.dark);
    this.floor(0,-23,66,4,4.4,this.steel,.22);this.rail(0,-21,65,'x',4.4);
    for(const side of [-1,1])for(let i=0;i<20;i++)this.floor(side*35,-6-i*.8,3.3,.85,(i+1)*.22,this.concrete,.22);
    this.floor(-35,-23,4,3,4.4,this.steel);this.floor(35,-23,4,3,4.4,this.steel);
    this.sign('BLACKWATER','DEPARTMENT OF CORRECTIONS · SECTOR 07',0,10.6,-25,22,3,s.accent);
    if(this.map!=='blackwater'){const old=this.group.children.at(-1);old.material.map.dispose();old.material.map=signTexture(s.name,s.subtitle.toUpperCase(),s.accent);}
    this.box(0,10.6,-25.2,23,3.4,.3,this.dark);
    // Courtyard circulation and markings.
    this.line(0,8,45,.18,this.yellow);this.line(-22,15,.12,14,this.yellow);this.line(22,15,.12,14,this.yellow);
    for(let i=0;i<12;i++)this.line(-20+i*3.6,8.5,.4,.7,this.yellow);
    for(const x of [-29,29]){this.box(x,.18,8,4,.36,18,this.concrete,true);this.box(x,.4,8,3.5,.4,17,this.grass);for(let j=0;j<7;j++)this.shrub(x,2+j*2,snow);}
    for(const x of [-16,16])for(const z of [20,29]){this.box(x,.7,z,5.2,.16,1.1,this.crateMat,true);for(const dx of [-2,2])this.box(x+dx,.35,z,.13,.7,.8,this.dark);}
    this.sign('YARD 07','ASSEMBLY POINT / KEEP CLEAR',0,.025,21,9,2.25,s.accent,-Math.PI);const groundSign=this.group.children.at(-1);groundSign.rotation.set(-Math.PI/2,0,0);
    for(const x of [-37,37])for(const z of [-33,30])this.tower(x,z);
    for(const x of [-24,24])for(const z of [-18,27])this.lamp(x,z,9);
    for(let i=0;i<4;i++)this.crate(-36+i%2*2,-18+Math.floor(i/2)*2,1.7,1.7,1.7);
    this.box(33,1.4,19,5,2.8,2.8,this.dark,true);this.sign('POWER / 07','AUTHORIZED PERSONNEL',33,1.6,20.43,4.5,1);
    for(let i=0;i<7;i++)this.box(31.2+i*.58,1.5,20.45,.12,1.8,.05,this.steel);
    // Six in-world terminals select games without requiring a warden in sandbox.
    Object.values(GAMES).forEach((g,i)=>{
      const x=-21+i*8.4,z=-9;
      this.box(x,.1,z,5,.2,4.5,this.dark);
      this.box(x,1,z,1,2,.8,this.dark,true);
      const emissive=this.material(g.color,{emissive:g.color,emissiveIntensity:.7});this.box(x,1.85,z+.45,1.5,.9,.12,emissive);
      this.sign(`${g.number} / ${g.en}`,g.label,x,3,z+.15,6.5,1.6,g.color);
      this.box(x,3,z,6.8,1.85,.2,this.dark);
      this.cyl(x,1.4,z-.2,.05,2.8,this.steel);
      this.terminals.push({game:g.id,pos:new THREE.Vector3(x,1.72,z+1.8)});
    });
    this.environment(night,snow);this.flush();
    this.arenas=[];const hub=this.group;
    for(const [id,method] of [['parkour','buildParkour'],['redlight','buildRedlight'],['glass','buildGlass'],['colors','buildColors'],['sweeper','buildSweeper'],['race','buildRace']]){
      const area=new THREE.Group();hub.add(area);this.group=area;this[method]();this.flush();this.arenas.push({id,group:area,origin:GAMES[id].origin});this.group=hub;
    }
    this.group.traverse(obj=>{if(obj.isMesh&&obj.material?.map)obj.material.map.anisotropy=4;});
  }
  tower(x,z) {
    this.box(x,5.6,z,4,11.2,4,this.concrete,true);this.box(x,11.3,z,6,.45,6,this.dark);
    this.box(x,13,z,5.4,3,5.4,this.dark);this.box(x,12.8,z+2.72,4.7,1.6,.07,this.cyan);
    this.box(x+2.72,12.8,z,.07,1.6,4.7,this.cyan);this.box(x,14.8,z,6.2,.4,6.2,this.concrete);
    this.cyl(x,16.6,z,.045,3.5,this.steel);this.box(x,18.3,z,.1,.1,.1,this.glow);
    this.rail(x,z+3,6,'x',11.4);this.rail(x+3,z,6,'z',11.4);
    this.box(x,8,z+2.04,.35,3,.08,this.yellow);
  }
  shrub(x,z,snow=false) {this.mesh(new THREE.SphereGeometry(.6,10,8),this.grass,[x,.75,z]);this.cyl(x,.45,z,.045,.8,this.rust);}
  environment(night,snow) {
    const rand=rng(54),rock=this.material(snow?'#b8c7ce':'#616c6a');
    for(let i=0;i<15;i++){
      const a=i/15*Math.PI*2,r=245+rand()*55,x=Math.sin(a)*r,z=Math.cos(a)*r;
      const size=120+rand()*70,height=30+rand()*65,geo=new THREE.PlaneGeometry(size,size,42,42);geo.rotateX(-Math.PI/2);
      const vertices=geo.attributes.position;
      for(let j=0;j<vertices.count;j++){
        const vx=vertices.getX(j),vz=vertices.getZ(j),rad=Math.hypot(vx/(size*.48),vz/(size*.48));
        const ridge=1+.22*Math.sin(vx*.09+2*i)*Math.cos(vz*.067)+.1*Math.sin(vx*.23+vz*.17)+.06*Math.cos(vz*.55-vx*.41);
        const h=Math.pow(Math.max(0,1-rad),1.25)*height*ridge-6;
        vertices.setY(j,h);
      }
      geo.computeVertexNormals();this.mesh(geo,rock,[x,0,z]);
    }
    // A rough coastal foundation keeps the prison grounded in the landscape.
    for(let i=0;i<48;i++){
      const a=i/48*Math.PI*2,x=Math.sin(a)*51,z=Math.cos(a)*46;
      const geo=new THREE.IcosahedronGeometry(5+rand()*3,2),v=geo.attributes.position;
      for(let j=0;j<v.count;j++){const scale=1+Math.sin(v.getX(j)*2+v.getZ(j))*.08;v.setXYZ(j,v.getX(j)*scale,v.getY(j)*.65,v.getZ(j)*scale);}
      geo.computeVertexNormals();this.mesh(geo,rock,[x,-3.7,z],[0,rand()*5,0]);
    }
    const water=new THREE.Mesh(new THREE.PlaneGeometry(1200,1200),new THREE.ShaderMaterial({
      uniforms:{time:{value:0},color:{value:new THREE.Color(night?'#122d35':snow?'#467580':'#416e77')}},
      vertexShader:'varying vec2 vUv; varying vec3 vPos; varying float vDepth; void main(){vUv=uv; vPos=position;vec4 mv=modelViewMatrix*vec4(position,1.0);vDepth=-mv.z;gl_Position=projectionMatrix*mv;}',
      fragmentShader:'uniform float time; uniform vec3 color; varying vec2 vUv; varying vec3 vPos; varying float vDepth; void main(){float a=sin(vPos.x*.65+sin(vPos.y*.29)+time*.6)*sin(vPos.y*.71-time*.4);float b=pow(max(0.,sin(vPos.y*1.2+sin(vPos.x*.45)+time)),36.);vec3 c=color+a*.007+b*.008;c=mix(c,vec3(.44,.55,.57),smoothstep(120.,540.,vDepth));gl_FragColor=vec4(c,1.);}'
    }));water.rotation.x=-Math.PI/2;water.position.y=-5.5;this.group.add(water);this.water=water;
    const sky=new THREE.Mesh(new THREE.SphereGeometry(550,32,24),new THREE.ShaderMaterial({side:THREE.BackSide,depthWrite:false,uniforms:{top:{value:new THREE.Color(night?'#091722':snow?'#4e7795':'#496c80')},bottom:{value:new THREE.Color(night?'#34404b':snow?'#c2d5d9':'#d0c7ad')},sunColor:{value:new THREE.Color(night?'#7c8f9b':snow?'#e0eef2':'#ffe4b5')}},vertexShader:'varying vec3 vWorld; void main(){vWorld=position;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',fragmentShader:'uniform vec3 top; uniform vec3 bottom;uniform vec3 sunColor;varying vec3 vWorld;void main(){vec3 d=normalize(vWorld);float h=max(0.,d.y);vec3 c=mix(bottom,top,pow(h,.45));float sun=pow(max(0.,dot(d,normalize(vec3(-.55,.19,.6)))),170.);float haze=pow(max(0.,dot(d,normalize(vec3(-.55,.19,.6)))),8.);c+=sunColor*(sun*.42+haze*.075);float cloud=sin(d.x*19.+sin(d.z*15.))*sin(d.z*23.+d.x*8.);c+=max(0.,cloud)*.018*smoothstep(.8,.15,h);gl_FragColor=vec4(c,1.);}'}));sky.renderOrder=-1;this.group.add(sky);
    if(night){for(const x of [-65,-55,55,65]){this.cyl(x,12,-56,2,24,this.rust,1.6);this.cyl(x,24.2,-56,2.1,.4,this.glow);for(let i=0;i<6;i++)this.cyl(x,3+i*3,-56,2.12,.15,this.steel);}
      for(let i=0;i<4;i++){this.box(-22+i*15,6,-53,12,12,8,this.dark);this.box(-22+i*15,4,-48.95,8,3,.06,this.glow);}
      for(let i=0;i<3;i++){this.cyl(-49,4+i*2,-3,.7,70,this.rust,.7,[Math.PI/2,0,0]);}
    } else if(snow) {
      const pine=this.material('#3e5a58');for(let i=0;i<48;i++){const a=rand()*Math.PI*2,r=65+rand()*40,x=Math.sin(a)*r,z=Math.cos(a)*r;this.cyl(x,2,z,.25,4,this.rust);for(let j=0;j<3;j++){this.mesh(new THREE.ConeGeometry(3-j*.6,5,12),pine,[x,3+j*2,z]);this.mesh(new THREE.ConeGeometry(2.5-j*.5,3.4,12),this.white,[x,4.1+j*2,z]);}}
      this.box(0,9.6,-32,67,.32,18,this.white);
    } else {
      // Offshore cargo cranes anchor the coastal setting.
      for(const x of [-64,61]){this.box(x,17,-67,2,34,2,this.yellow);this.box(x+12,31,-67,34,1,1.3,this.yellow);this.box(x+26,22,-67,.1,18,.1,this.dark);for(let i=0;i<6;i++)this.box(x+3+i*4,30,-67,.2,2,.2,this.steel);}
      for(let i=0;i<5;i++)this.box(-22+i*11,2,-61,9,4,5,i%2?this.rust:this.crateMat);
    }
    const pos=[];for(let i=0;i<130;i++)pos.push((rand()-.5)*100,rand()*20,(rand()-.5)*90);
    const pg=new THREE.BufferGeometry();pg.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));
    this.particles=new THREE.Points(pg,new THREE.PointsMaterial({color:snow?'#eff8ff':'#e5c799',size:snow?.085:.035,transparent:true,opacity:.5,depthWrite:false}));this.group.add(this.particles);
  }
  arenaBase(game,w,d,y=0) {const g=GAMES[game],[x,z]=g.origin;this.floor(x,z,w,d,y,this.ground,1);this.sign(g.en,`${g.number} / ${g.name}`,x,5,z-d/2-.5,15,3,g.color);this.box(x,5,z-d/2-.7,15.6,3.5,.3,this.dark);for(const side of [-1,1]){this.box(x+side*(w/2+.3),1.3,z,.5,2.6,d,this.dark,true);this.lamp(x+side*(w/2-1),z+d/2-2,9);}return [x,z];}
  finishGate(x,z,y=0,color=this.cyan) {for(const side of [-1,1]){this.box(x+side*3,y+2.3,z,.3,4.6,.35,this.dark);this.box(x+side*2.81,y+2.3,z,.07,4.3,.1,color);}this.box(x,y+4.5,z,6.3,.3,.4,this.dark);this.box(x,y+4.35,z,5.7,.06,.12,color);}
  buildParkour() {
    const [ox,oz]=GAMES.parkour.origin;
    for(const [i,p] of parkourPlatforms(this.map).entries()) {this.floor(ox+p.x,oz+p.z,p.w,p.d,p.y,p.checkpoint?this.rust:this.concrete,1);this.line(ox+p.x,oz+p.z-p.d/2+.13,p.w-.3,.14,this.yellow,p.y+.025);this.cyl(ox+p.x,p.y/2-3,oz+p.z,.45,p.y+5,this.dark);this.sign(String(i).padStart(2,'0'),' ',ox+p.x,p.y-.42,oz+p.z+p.d/2+.02,1.5,.6);if(p.checkpoint)this.finishGate(ox+p.x,oz+p.z,p.y,this.yellow);}
    this.finishGate(ox,oz-25,4.8);this.sign('THE RUN','01 / FIRAR ROTASI',ox,6,oz-29,12,3);
    this.rail(ox-5.8,19,6,'z');this.rail(ox+5.8,19,6,'z');
    for(const side of [-1,1])for(let z=18;z>-28;z-=8)this.cyl(ox+side*9,-2,z,.08,5,this.dark);
  }
  buildRedlight() {
    const [x,z]=this.arenaBase('redlight',24,64);
    for(let i=0;i<9;i++){this.line(x,z+24-i*6,23,.08,this.white);this.sign(String(i*6).padStart(2,'0'),' ',x-10,.03,z+24-i*6,1,.5);const s=this.group.children.at(-1);s.rotation.x=-Math.PI/2;}
    this.line(x,z-26,23,.4,this.yellow);this.finishGate(x,z-27);
    this.box(x,6,z-31,4,3,1,this.dark);this.signalLights=[];
    for(const [i,c] of ['#dd4f44','#8cbb7a'].entries()){const mat=this.material(c,{emissive:c,emissiveIntensity:1});const m=this.mesh(new THREE.SphereGeometry(.55,24,20),mat,[x+(i-.5)*1.7,6,z-30.4],[0,0,0],true);this.signalLights.push(m);}
  }
  buildGlass() {
    const [x,z]=GAMES.glass.origin;
    this.floor(x,z+23,14,7,0,this.concrete);this.floor(x,z-28,14,7,0,this.concrete);this.finishGate(x,z-27);
    this.sign('TRUST FALL','03 / CAM KOPRU',x,6,z-32,14,3);
    const mat=this.material('#80acb3',{metalness:.55,roughness:.2,transparent:true,opacity:.62});
    for(const [i,row] of glassRows().entries())for(const [side,dx] of row.x.entries()){
      const m=this.box(x+dx,-.12,z+row.z,row.w,.22,row.d,mat,false,true);const surface={x:x+dx,z:z+row.z,w:row.w,d:row.d,y:0,enabled:true};this.surfaces.push(surface);this.glass.push({mesh:m,surface,key:`${i}:${side}`});
      for(const a of [-1,1])this.box(x+dx+a*row.w/2,-.25,z+row.z,.08,.18,row.d,this.steel);
    }
    for(const dx of [-5,5]){this.box(x+dx,-.6,z-2,.22,.5,51,this.dark);this.rail(x+dx,z-2,51,'z',-.5);}
  }
  buildColors() {
    const [x,z]=GAMES.colors.origin;
    for(let row=0;row<5;row++)for(let col=0;col<5;col++){
      const color=tileColor(col,row),mat=this.material(COLOR_PALETTE[color].value,{metalness:.12,roughness:.65});
      const tx=x-10+col*5,tz=z-10+row*5;const m=this.box(tx,-.25,tz,4.88,.5,4.88,mat,false,true);const surface={x:tx,z:tz,w:4.95,d:4.95,y:0,enabled:true};this.surfaces.push(surface);
      const label=this.sign(['A','B','C','D'][color],'',tx,.015,tz,1.2,.6,'#e8e5d6');label.rotation.x=-Math.PI/2;this.tiles.push({mesh:m,surface,color,label});
    }
    for(const side of [-1,1]){this.box(x+side*13,-1,z,.5,1,27,this.dark);this.box(x,-1,z+side*13,27,1,.5,this.dark);this.lamp(x+side*14,z-14,10);}
    this.sign('COLOR DROP','04 / RENK KAPANI',x,5,z-15,14,3);
  }
  buildSweeper() {
    const [x,z]=GAMES.sweeper.origin;this.cyl(x,-.5,z,12,1,this.concrete);
    this.surfaces.push({x,z,w:24,d:24,y:0,radius:12,enabled:true});
    this.cyl(x,1,z,1.2,2,this.dark);this.cyl(x,2.1,z,1.25,.2,this.glow);
    const arm=new THREE.Group();arm.position.set(x,.55,z);this.group.add(arm);
    const b=new THREE.Mesh(new THREE.CylinderGeometry(.16,.16,23,16),this.yellow);b.rotation.x=Math.PI/2;b.castShadow=true;arm.add(b);
    for(const side of [-1,1]){const end=new THREE.Mesh(new THREE.CylinderGeometry(.36,.36,.6,16),this.rust);end.rotation.x=Math.PI/2;end.position.z=side*11.2;arm.add(end);}
    this.sweeper=arm;this.colliders.push({x,z,w:2,d:2,minY:0,maxY:2.3,enabled:true});
    for(let i=0;i<16;i++){const a=i/16*Math.PI*2;this.cyl(x+Math.sin(a)*11.65,.05,z+Math.cos(a)*11.65,.12,.08,this.yellow);}
    this.sign('SWEEPER','05 / SON AYAKTA',x,6,z-15,13,3);this.lamp(x-13,z+12,10);this.lamp(x+13,z+12,10);
  }
  buildRace() {
    const [x,z]=this.arenaBase('race',46,46);
    this.box(x,1.3,z,24,2.6,24,this.dark,true);this.box(x,2.65,z,24.5,.15,24.5,this.grass);
    for(const [i,g] of RACE_GATES.entries()) {this.finishGate(x+g[0],z+g[1],0,i===0?this.yellow:this.cyan);this.sign(String(i+1),'',x+g[0],4.8,z+g[1],1.5,.7);}
    for(const side of [-1,1])for(const offset of [-6,6]){this.box(x+side*17,.45,z+offset,6,.9,.45,this.rust,true);this.box(x+offset,.45,z+side*17,.45,.9,6,this.rust,true);}
    for(const side of [-1,1]){this.line(x+side*17,z,.09,44,this.yellow);this.line(x,z+side*17,44,.09,this.yellow);}
    this.sign('2 LAPS / FULL SEND','06 / AVLU YARISI',x,3.2,z+12.05,16,2);
  }
  flush() {for(const {mat,geos} of this.batches.values()){const geo=mergeGeometries(geos);const m=new THREE.Mesh(geo,mat);m.castShadow=true;m.receiveShadow=true;this.group.add(m);for(const g of geos)g.dispose();}this.batches.clear();}
  update(time,room,trial,dt,viewer=null) {
    this.water.material.uniforms.time.value=time;this.particles.rotation.y=time*.006;
    for(const arena of this.arenas)arena.group.visible=!!viewer&&Math.hypot(viewer.x-arena.origin[0],viewer.z-arena.origin[1])<72;
    if(this.map==='northstar')this.particles.position.y=-(time*.5)%5;
    for(const g of this.gates){const target=g.base+(room?.cellsOpen===false?0:3.6);g.mesh.position.y=THREE.MathUtils.damp(g.mesh.position.y,target,5,dt);g.col.enabled=room?.cellsOpen===false;}
    const elapsed=trial?Math.max(0,(Date.now()+(room?.timeOffset||0)-trial.startedAt)/1000):0;
    const phase=colorPhase(trial?.game==='colors'?elapsed:0);
    for(const tile of this.tiles){const drop=trial?.game==='colors'&&phase.dropping&&tile.color!==phase.target;tile.mesh.position.y=THREE.MathUtils.damp(tile.mesh.position.y,drop?-6:-.25,12,dt);tile.label.position.y=tile.mesh.position.y+.265;tile.surface.enabled=!drop;}
    for(const glass of this.glass){const broken=(room?.round?.state==='active'?room.broken:trial?.broken||[]).includes(glass.key);glass.mesh.visible=!broken;glass.surface.enabled=!broken;}
    this.sweeper.rotation.y=sweeperAngle(trial?.game==='sweeper'?elapsed:time*.3);
    const red=trial?.game==='redlight'&&lightPhase(elapsed).red;
    this.signalLights[0].material.emissiveIntensity=red?3:.1;this.signalLights[1].material.emissiveIntensity=red?.1:2.5;
  }
  support(x,z,feet,previousFeet) {
    let height=-Infinity;for(const s of this.surfaces){if(!s.enabled)continue;if(Math.abs(x-s.x)>s.w/2+.12||Math.abs(z-s.z)>s.d/2+.12)continue;if(s.radius&&Math.hypot(x-s.x,z-s.z)>s.radius)continue;if(s.y<=Math.max(feet+.3,previousFeet+.08)&&s.y>height)height=s.y;}return height;
  }
  blocked(x,z,feet,height=1.65) {const r=.28;return this.colliders.some(c=>c.enabled&&feet<c.maxY-.08&&feet+height>c.minY+.1&&Math.abs(x-c.x)<c.w/2+r&&Math.abs(z-c.z)<c.d/2+r);}
  dispose() {this.scene.remove(this.group);this.group.traverse(o=>{o.geometry?.dispose();if(o.material){const list=Array.isArray(o.material)?o.material:[o.material];list.forEach(m=>m.dispose());}});this.textures.forEach(t=>t.dispose());}
}
