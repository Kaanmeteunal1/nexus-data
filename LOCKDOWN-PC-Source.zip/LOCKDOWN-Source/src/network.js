import { GameService } from '../server/game-service.js';
export const localMode=location.protocol==='file:'||new URLSearchParams(location.search).get('offline')==='1';
class LocalNetwork {
  constructor(onMessage,onStatus){this.onMessage=onMessage;this.service=new GameService();this.ready=Promise.resolve();this.token=null;this.player=this.service.connect({readyState:1,send:raw=>queueMicrotask(()=>this.onMessage(JSON.parse(raw)))});this.timer=setInterval(()=>this.service.tick(),100);queueMicrotask(()=>onStatus('online'));}
  send(type,data={}){this.player=this.service.handle(this.player,{type,...data});}
  async request(type,data={}){this.send(type,data);}
}
export class Network {
  constructor(onMessage,onStatus){if(localMode)return new LocalNetwork(onMessage,onStatus);this.onMessage=onMessage;this.onStatus=onStatus;this.ws=null;this.token=null;this.retry=0;this.closed=false;this.ready=null;this.connect();}
  connect(){this.onStatus('connecting');this.ready=new Promise(resolve=>{this.resolve=resolve;});this.ws=new WebSocket(`${location.protocol==='https:'?'wss':'ws'}://${location.host}/socket`);
    this.ws.addEventListener('open',()=>{this.retry=0;this.onStatus('online');this.resolve();if(this.token)this.send('resume',{token:this.token});});
    this.ws.addEventListener('message',e=>{let msg;try{msg=JSON.parse(e.data);}catch{return;}if(msg.type==='joined')this.token=msg.token;if(['left','kicked'].includes(msg.type))this.token=null;this.onMessage(msg);});
    this.ws.addEventListener('close',()=>{this.onStatus('offline');if(!this.closed&&this.retry<8)setTimeout(()=>this.connect(),Math.min(5000,500*2**this.retry++));});
    this.ws.addEventListener('error',()=>this.onStatus('offline'));
  }
  send(type,data={}){if(this.ws?.readyState===WebSocket.OPEN)this.ws.send(JSON.stringify({type,...data}));}
  async request(type,data={}){await Promise.race([this.ready,new Promise((_,reject)=>setTimeout(()=>reject(new Error('Sunucuya bağlanılamadı.')),7000))]);this.send(type,data);}
}
