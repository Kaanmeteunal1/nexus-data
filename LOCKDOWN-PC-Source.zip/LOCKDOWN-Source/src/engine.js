import * as THREE from 'three';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import { World } from './world.js';
import { createCharacter, animateCharacter } from './character.js';
import { MAPS, PLAYER_HEIGHT, HUB_SPAWN } from '../shared/game.js';

export class Engine {
  constructor(canvas,callbacks,settings) {
    this.canvas=canvas;this.cb=callbacks;this.settings=settings;this.scene=new THREE.Scene();
    this.renderer=new THREE.WebGLRenderer({canvas,antialias:true,powerPreference:'high-performance'});this.renderer.setPixelRatio(Math.min(devicePixelRatio,settings.quality==='high'?1.7:1.2));this.renderer.shadowMap.enabled=settings.quality!=='low';this.renderer.shadowMap.type=THREE.PCFSoftShadowMap;this.renderer.toneMapping=THREE.ACESFilmicToneMapping;this.renderer.toneMappingExposure=1.15;
    this.camera=new THREE.PerspectiveCamera(settings.fov||78,innerWidth/innerHeight,.08,650);this.camera.rotation.order='YXZ';this.scene.add(this.camera);
    this.composer=new EffectComposer(this.renderer);this.composer.renderTarget1.samples=4;this.composer.renderTarget2.samples=4;this.composer.addPass(new RenderPass(this.scene,this.camera));this.bloom=new UnrealBloomPass(new THREE.Vector2(innerWidth,innerHeight),.22,.6,1.35);this.composer.addPass(this.bloom);this.composer.addPass(new OutputPass());
    this.hemi=new THREE.HemisphereLight('#dbe6e8','#5d655b',2.1);this.scene.add(this.hemi);
    this.sun=new THREE.DirectionalLight('#ffe1b5',3.8);this.sun.position.set(-45,65,38);this.sun.castShadow=true;this.sun.shadow.mapSize.set(2048,2048);this.sun.shadow.camera.left=-65;this.sun.shadow.camera.right=65;this.sun.shadow.camera.top=65;this.sun.shadow.camera.bottom=-65;this.sun.shadow.camera.near=1;this.sun.shadow.camera.far=190;this.sun.shadow.bias=-.0003;this.sun.shadow.normalBias=.025;this.scene.add(this.sun,this.sun.target);
    this.fill=new THREE.DirectionalLight('#8ec1ce',.7);this.fill.position.set(25,18,-30);this.scene.add(this.fill);
    this.keys=new Set();this.pos=new THREE.Vector3(...HUB_SPAWN);this.vel=new THREE.Vector3();this.yaw=0;this.pitch=0;this.grounded=false;this.active=false;this.paused=true;this.thirdPerson=false;this.room=null;this.self=null;this.remote=new Map();this.stamina=1;this.last=performance.now();this.time=0;this.sendTime=0;this.footstep=0;this.jumpQueued=false;this.previousGround=false;this.fps=60;this.frames=0;this.fpsTime=0;
    this.resize();window.addEventListener('resize',()=>this.resize());
    canvas.addEventListener('click',()=>{if(this.active&&!this.paused)this.lock();});
    document.addEventListener('mousemove',e=>{if(this.locked){const sensitivity=this.settings.sensitivity*.0015;this.yaw-=e.movementX*sensitivity;this.pitch=THREE.MathUtils.clamp(this.pitch-e.movementY*sensitivity,-1.42,1.42);}});
    document.addEventListener('pointerlockchange',()=>{this.cb.lock?.(this.locked);if(!this.locked)this.keys.clear();});
    document.addEventListener('keydown',e=>this.key(e,true));document.addEventListener('keyup',e=>this.key(e,false));window.addEventListener('blur',()=>{this.keys.clear();this.cb.voice?.(false);});
    this.loadMap('blackwater');this.renderer.setAnimationLoop(t=>this.frame(t));
  }
  get locked(){return document.pointerLockElement===this.canvas;}
  async lock(){if(!this.active)return;try{await this.canvas.requestPointerLock();}catch{this.cb.notice?.('Oyun alanına tıklayarak fare kontrolünü etkinleştir.');}}
  unlock(){if(this.locked)document.exitPointerLock();}
  key(e,down) {
    if(['INPUT','TEXTAREA','SELECT'].includes(document.activeElement?.tagName))return;
    if(this.active&&['Space','Tab','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.code))e.preventDefault();
    if(down)this.keys.add(e.code);else this.keys.delete(e.code);
    if(e.code==='KeyV'){this.cb.voice?.(down);return;}
    if(!down||e.repeat||!this.active)return;
    if(e.code==='Space'){this.jumpQueued=true;this.jumpBuffer=.14;}
    if(e.code==='KeyC')this.thirdPerson=!this.thirdPerson;
    if(e.code==='KeyE'&&this.nearTerminal)this.cb.interact?.(this.nearTerminal.game);
    if(e.code==='KeyR')this.cb.respawn?.();
    if(e.code==='KeyM')this.cb.menu?.('games');
    if(e.code==='Tab')this.cb.menu?.('scoreboard');
    if(e.code==='KeyG')this.cb.menu?.('warden');
    if(e.code==='KeyT'||e.code==='Enter')this.cb.chat?.();
    if(e.code==='KeyH')this.cb.hud?.();
    if(e.code==='Digit1')this.cb.emote?.('wave');
    if(e.code==='Digit2')this.cb.emote?.('salute');
    if(e.code==='Digit3')this.cb.emote?.('dance');
  }
  loadMap(id){if(this.world?.map===id)return;this.world?.dispose();this.world=new World(this.scene,id);const s=MAPS[id];this.scene.background=new THREE.Color(s.sky);this.scene.fog=new THREE.FogExp2(s.fog,id==='ironworks'?.006:.0037);this.hemi.intensity=id==='ironworks'?1.2:2.1;this.sun.intensity=id==='ironworks'?1.1:3.8;this.sun.color.set(id==='northstar'?'#d6edff':'#ffe1b5');this.renderer.toneMappingExposure=id==='ironworks'?1.35:1.05;}
  resize(){this.renderer.setSize(innerWidth,innerHeight);this.composer.setSize(innerWidth,innerHeight);this.camera.aspect=innerWidth/innerHeight;this.camera.updateProjectionMatrix();}
  applySettings(){this.renderer.setPixelRatio(Math.min(devicePixelRatio,this.settings.quality==='high'?1.7:1.2));this.renderer.shadowMap.enabled=this.settings.quality!=='low';this.resize();}
  teleport(pos,yaw=0){this.pos.set(...pos);this.yaw=yaw;this.pitch=0;this.vel.set(0,0,0);this.grounded=false;this.keys.clear();}
  start(room,id){this.active=true;this.paused=false;this.self=id;this.setRoom(room);this.teleport(HUB_SPAWN);this.refreshAvatar();}
  refreshAvatar(){if(this.avatar){this.scene.remove(this.avatar);this.disposeCharacter(this.avatar);}const p=this.room?.players.find(p=>p.id===this.self);this.avatar=createCharacter(p?.role||'prisoner');this.avatarRole=p?.role;this.scene.add(this.avatar);}
  stop(){this.active=false;this.unlock();this.keys.clear();if(this.avatar){this.scene.remove(this.avatar);this.disposeCharacter(this.avatar);this.avatar=null;}for(const obj of this.remote.values()){this.scene.remove(obj.mesh);this.disposeCharacter(obj.mesh);}this.remote.clear();}
  setRoom(room){this.room=room;this.loadMap(room.map);const me=room.players.find(p=>p.id===this.self);if(this.avatar&&this.avatarRole!==me?.role)this.refreshAvatar();
    for(const p of room.players){if(p.id===this.self)continue;let obj=this.remote.get(p.id);if(obj&&obj.role!==p.role){this.scene.remove(obj.mesh);this.disposeCharacter(obj.mesh);this.remote.delete(p.id);obj=null;}if(!obj){const mesh=createCharacter(p.role,p.name.length);mesh.position.set(p.pos[0],p.pos[1]-PLAYER_HEIGHT,p.pos[2]);this.scene.add(mesh);obj={mesh,role:p.role,player:p,target:new THREE.Vector3()};this.remote.set(p.id,obj);}obj.player=p;obj.target.set(p.pos[0],p.pos[1]-PLAYER_HEIGHT,p.pos[2]);}
    for(const [id,obj] of this.remote)if(!room.players.some(p=>p.id===id)){this.scene.remove(obj.mesh);this.disposeCharacter(obj.mesh);this.remote.delete(id);}
  }
  disposeCharacter(root){const materials=new Set();root.traverse(o=>{o.geometry?.dispose();if(o.material)materials.add(o.material);});materials.forEach(m=>m.dispose());}
  physics(dt) {
    const me=this.room?.players.find(p=>p.id===this.self),trial=me?.trial;
    const countdown=trial&&Date.now()+(this.room?.timeOffset||0)<trial.startedAt;
    const input=this.locked&&!this.paused&&!countdown;
    const forward=input?Number(this.keys.has('KeyW')||this.keys.has('ArrowUp'))-Number(this.keys.has('KeyS')||this.keys.has('ArrowDown')):0;
    const sideways=input?Number(this.keys.has('KeyD')||this.keys.has('ArrowRight'))-Number(this.keys.has('KeyA')||this.keys.has('ArrowLeft')):0;
    this.crouch=input&&(this.keys.has('ControlLeft')||this.keys.has('ControlRight'));
    const running=input&&this.keys.has('ShiftLeft')&&forward>0&&!this.crouch&&this.stamina>.02;
    const moving=forward!==0||sideways!==0;this.stamina=THREE.MathUtils.clamp(this.stamina+(running&&moving?-.16:.22)*dt,0,1);
    const speed=this.crouch?2.5:running?10:6.4;const length=Math.hypot(forward,sideways)||1;
    const vx=(sideways*Math.cos(this.yaw)-forward*Math.sin(this.yaw))/length*speed;
    const vz=(-sideways*Math.sin(this.yaw)-forward*Math.cos(this.yaw))/length*speed;
    this.vel.x=THREE.MathUtils.damp(this.vel.x,vx,this.grounded?15:5,dt);this.vel.z=THREE.MathUtils.damp(this.vel.z,vz,this.grounded?15:5,dt);
    this.coyote=this.grounded?.1:Math.max(0,(this.coyote||0)-dt);this.jumpBuffer=Math.max(0,(this.jumpBuffer||0)-dt);
    if(this.jumpBuffer>0&&input&&this.coyote>0){this.vel.y=8.6;this.grounded=false;this.coyote=0;this.jumpBuffer=0;this.cb.sound?.('jump');}this.jumpQueued=false;
    this.vel.y-=22*dt;const feet=this.pos.y-PLAYER_HEIGHT;
    const nx=this.pos.x+this.vel.x*dt,nz=this.pos.z+this.vel.z*dt;
    if(!this.world.blocked(nx,this.pos.z,feet,this.crouch?1.2:1.7))this.pos.x=nx;else this.vel.x=0;
    if(!this.world.blocked(this.pos.x,nz,feet,this.crouch?1.2:1.7))this.pos.z=nz;else this.vel.z=0;
    let newFeet=feet+this.vel.y*dt;const surface=this.world.support(this.pos.x,this.pos.z,newFeet,feet);
    const wasGrounded=this.grounded;this.grounded=false;
    if(this.vel.y<=0&&newFeet<=surface&&feet>=surface-.3){newFeet=surface;this.vel.y=0;this.grounded=true;if(!wasGrounded&&this.previousGround===false)this.cb.sound?.('land');}
    this.pos.y=newFeet+PLAYER_HEIGHT;this.previousGround=this.grounded;
    if(this.pos.y<-15){this.cb.respawn?.();this.pos.y=-10;this.vel.y=0;}
    if(moving&&this.grounded){this.footstep+=dt*(running?2:1.5);if(this.footstep>.55){this.footstep=0;this.cb.sound?.('step');}}
    this.nearTerminal=null;if(!trial){for(const t of this.world.terminals)if(t.pos.distanceTo(this.pos)<3.5){this.nearTerminal=t;break;}}
    this.cb.frame?.({pos:this.pos,stamina:this.stamina,terminal:this.nearTerminal,moving,running,grounded:this.grounded,fps:this.fps});
    this.sendTime+=dt;if(this.sendTime>=.05){this.sendTime=0;this.cb.move?.({pos:this.pos.toArray(),yaw:this.yaw,crouch:this.crouch,moving});}
    this.avatar.visible=this.thirdPerson;
    this.avatar.position.set(this.pos.x,newFeet,this.pos.z);this.avatar.rotation.y=this.yaw+Math.PI;
    animateCharacter(this.avatar,dt,moving,this.crouch,me?.emoteUntil>Date.now()+(this.room?.timeOffset||0)?me.emote:null,this.time);
    const bob=this.settings.motion&&moving&&this.grounded?Math.sin(this.time*(running?15:10))*.032:0;
    const eye=this.pos.clone();eye.y+=(this.crouch?-.45:0)+bob;
    this.camera.rotation.set(this.pitch,this.yaw,0,'YXZ');
    if(this.thirdPerson){const offset=new THREE.Vector3(0,1.1,4.2).applyAxisAngle(new THREE.Vector3(0,1,0),this.yaw);let fraction=1;for(let f=.1;f<=1;f+=.06){const probe=eye.clone().addScaledVector(offset,f);if(this.world.blocked(probe.x,probe.z,probe.y-.15,.3)){fraction=Math.max(.1,f-.08);break;}}this.camera.position.copy(eye).addScaledVector(offset,fraction);this.camera.lookAt(eye.clone().add(new THREE.Vector3(-Math.sin(this.yaw),.15,-Math.cos(this.yaw)).multiplyScalar(4)));}
    else this.camera.position.copy(eye);
    this.camera.fov=THREE.MathUtils.damp(this.camera.fov,this.settings.fov+(running?4:0),5,dt);this.camera.updateProjectionMatrix();
    this.sun.position.set(this.pos.x-45,65,this.pos.z+38);this.sun.target.position.set(this.pos.x,0,this.pos.z);
  }
  frame(t) {
    const rawDt=(t-this.last)/1000,dt=Math.min(rawDt,.04);this.last=t;this.time+=dt;this.frames++;this.fpsTime+=rawDt;if(this.fpsTime>1){this.fps=Math.round(this.frames/this.fpsTime);this.frames=0;this.fpsTime=0;}
    if(this.active&&this.avatar){let remaining=Math.min(rawDt,.2);while(remaining>0){const step=Math.min(remaining,1/60);this.physics(step);remaining-=step;}}else {
      const a=this.time*.018;
      this.camera.position.set(48+Math.sin(a)*5,29+Math.sin(a*.6),52+Math.cos(a)*4);this.camera.lookAt(-2,4,-10);this.camera.fov=52;this.camera.updateProjectionMatrix();
    }
    for(const obj of this.remote.values()){obj.mesh.position.lerp(obj.target,Math.min(1,dt*14));let d=obj.player.yaw+Math.PI-obj.mesh.rotation.y;d=Math.atan2(Math.sin(d),Math.cos(d));obj.mesh.rotation.y+=d*Math.min(1,dt*12);animateCharacter(obj.mesh,dt,obj.player.moving,obj.player.crouch,obj.player.emoteUntil>Date.now()+(this.room?.timeOffset||0)?obj.player.emote:null,this.time);}
    const trial=this.room?.players.find(p=>p.id===this.self)?.trial;
    const visibleTrial=trial||(this.room?.round?.state==='active'?this.room.round:null);
    this.world.update(this.time,this.room,visibleTrial,dt,this.active?this.pos:null);
    if(this.settings.quality==='high')this.composer.render();else this.renderer.render(this.scene,this.camera);
  }
  projectPlayers(){const labels=[];for(const [id,obj] of this.remote){if(obj.mesh.position.distanceTo(this.pos)>35)continue;const p=obj.mesh.position.clone().add(new THREE.Vector3(0,2.1,0)).project(this.camera);if(p.z<1&&Math.abs(p.x)<1&&Math.abs(p.y)<1)labels.push({id,name:obj.player.name,role:obj.player.role,x:(p.x+1)/2*innerWidth,y:(-p.y+1)/2*innerHeight});}return labels;}
}
