import * as THREE from 'three';

export function createCharacter(role='prisoner',seed=0) {
  const root=new THREE.Group(),body=new THREE.Group();root.add(body);
  const mat=(color,roughness=.85)=>new THREE.MeshStandardMaterial({color,roughness});
  const suit=mat(role==='prisoner'?'#bc7044':'#35494b'),dark=mat('#263335'),seam=mat(role==='prisoner'?'#835336':'#75817a'),skin=mat(['#b98c70','#d5ad8a','#886248'][seed%3]),hair=mat('#302e2b'),white=mat('#ded8c6');
  function mesh(geo,material,x,y,z,parent=body){const m=new THREE.Mesh(geo,material);m.position.set(x,y,z);m.castShadow=true;m.receiveShadow=true;parent.add(m);return m;}
  const torso=mesh(new THREE.CapsuleGeometry(.235,.37,8,16),suit,0,1.13,0);torso.scale.set(1,.97,.68);
  mesh(new THREE.CylinderGeometry(.245,.24,.08,20),dark,0,.87,0).scale.z=.72;
  mesh(new THREE.BoxGeometry(.085,.07,.03),seam,0,.87,.177);
  mesh(new THREE.BoxGeometry(.015,.4,.014),seam,0,1.16,.164);
  for(const side of [-1,1]){mesh(new THREE.BoxGeometry(.105,.1,.022),seam,side*.12,1.29,.16);mesh(new THREE.BoxGeometry(.09,.07,.023),suit,side*.12,1.28,.177);}
  mesh(new THREE.CylinderGeometry(.07,.07,.12,12),skin,0,1.48,0);
  const head=new THREE.Group();head.position.y=1.66;body.add(head);
  mesh(new THREE.SphereGeometry(.155,24,20),skin,0,0,0,head).scale.set(.86,1.1,.91);
  mesh(new THREE.SphereGeometry(.158,24,16,0,Math.PI*2,0,Math.PI*.54),hair,0,.025,-.016,head).scale.set(.9,1,.94);
  mesh(new THREE.CapsuleGeometry(.023,.028,4,8),skin,0,-.005,.142,head).rotation.x=Math.PI/5;
  for(const side of [-1,1]){mesh(new THREE.SphereGeometry(.025,12,8),skin,side*.135,-.01,0,head);mesh(new THREE.SphereGeometry(.013,12,8),dark,side*.055,.028,.123,head);mesh(new THREE.BoxGeometry(.042,.009,.01),hair,side*.055,.052,.12,head);}
  mesh(new THREE.BoxGeometry(.05,.01,.01),seam,0,-.071,.12,head);
  if(role!=='prisoner'){
    mesh(new THREE.CylinderGeometry(.16,.16,.085,24),dark,0,.126,0,head);
    mesh(new THREE.BoxGeometry(.24,.02,.13),dark,0,.09,.13,head);
    mesh(new THREE.BoxGeometry(.04,.04,.012),white,0,.13,.158,head);
    const vest=mesh(new THREE.BoxGeometry(.42,.34,.31),dark,0,1.19,0);for(const side of [-1,1])mesh(new THREE.BoxGeometry(.1,.15,.055),seam,side*.12,1.13,.19);
    mesh(new THREE.BoxGeometry(.1,.045,.012),white,0,1.32,.165);
  }
  const arms=[],legs=[];
  for(const side of [-1,1]) {
    const arm=new THREE.Group();arm.position.set(side*.27,1.38,0);body.add(arm);
    mesh(new THREE.CapsuleGeometry(.075,.22,8,12),suit,side*.02,-.14,0,arm);
    const elbow=new THREE.Group();elbow.position.set(side*.02,-.3,0);arm.add(elbow);
    mesh(new THREE.CapsuleGeometry(.059,.19,8,12),suit,0,-.1,.015,elbow);
    mesh(new THREE.SphereGeometry(.065,16,12),skin,0,-.25,.015,elbow).scale.set(.8,1.3,.7);arms.push({arm,elbow,side});
    const leg=new THREE.Group();leg.position.set(side*.12,.85,0);body.add(leg);
    mesh(new THREE.CapsuleGeometry(.1,.26,8,16),suit,0,-.18,0,leg);
    const knee=new THREE.Group();knee.position.y=-.38;leg.add(knee);
    mesh(new THREE.CapsuleGeometry(.082,.25,8,16),suit,0,-.15,0,knee);
    mesh(new THREE.CapsuleGeometry(.08,.12,6,12),dark,0,-.36,.055,knee).rotation.x=Math.PI/2;
    mesh(new THREE.BoxGeometry(.17,.055,.28),dark,0,-.405,.055,knee);legs.push({leg,knee,side});
  }
  root.userData={body,head,arms,legs,phase:0};return root;
}
export function animateCharacter(root,dt,moving,crouch,emote,time) {
  const {body,head,arms,legs}=root.userData;root.userData.phase+=dt*(moving?10:2);const phase=root.userData.phase;
  body.position.y=THREE.MathUtils.damp(body.position.y,crouch?-.42:moving?Math.abs(Math.sin(phase))*.025:Math.sin(phase)*.008,14,dt);
  body.rotation.x=THREE.MathUtils.damp(body.rotation.x,crouch?.18:0,12,dt);
  for(const {leg,knee,side} of legs){const stride=moving?Math.sin(phase+side*Math.PI/2)*.65:0;leg.rotation.x=THREE.MathUtils.damp(leg.rotation.x,stride+(crouch?-.7:0),14,dt);knee.rotation.x=THREE.MathUtils.damp(knee.rotation.x,Math.max(0,-stride)*.8+(crouch?1.3:0),14,dt);}
  for(const {arm,elbow,side} of arms){let x=moving?-Math.sin(phase+side*Math.PI/2)*.55:0,z=-side*.06;
    if(emote==='wave'&&side===1){x=-2.7;z=Math.sin(time*8)*.25-.4;}
    if(emote==='salute'&&side===1){x=-1.9;z=-.35;}
    if(emote==='dance'){x=Math.sin(time*5+side)*.8;z=side*(.7+Math.sin(time*4)*.2);body.rotation.z=Math.sin(time*4)*.12;}
    else body.rotation.z=THREE.MathUtils.damp(body.rotation.z,0,8,dt);
    arm.rotation.x=THREE.MathUtils.damp(arm.rotation.x,x,15,dt);arm.rotation.z=THREE.MathUtils.damp(arm.rotation.z,z,15,dt);elbow.rotation.x=emote==='salute'?-1.5:-.15;
  }
}
