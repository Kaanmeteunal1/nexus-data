export class AudioSystem {
  constructor(settings){this.settings=settings;this.context=null;this.master=null;this.voiceActive=false;this.muted=new Set();this.nextVoice=new Map();}
  async init(){if(!this.context){this.context=new AudioContext();this.master=this.context.createGain();this.master.gain.value=this.settings.volume;this.master.connect(this.context.destination);}if(this.context.state==='suspended')await this.context.resume();}
  setVolume(){if(this.master)this.master.gain.value=this.settings.volume;}
  play(kind){if(!this.context||this.context.state!=='running')return;const c=this.context,t=c.currentTime;
    if(['step','land'].includes(kind)){const n=c.createBuffer(1,c.sampleRate*.09,c.sampleRate),d=n.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=(Math.random()*2-1)*Math.pow(1-i/d.length,3);const src=c.createBufferSource();src.buffer=n;const filter=c.createBiquadFilter();filter.type='lowpass';filter.frequency.value=kind==='step'?500:280;const gain=c.createGain();gain.gain.value=kind==='step'?.12:.2;src.connect(filter).connect(gain).connect(this.master);src.start();return;}
    const notes={click:[460,.045],jump:[180,.12],checkpoint:[660,.2],success:[660,.5],fail:[140,.3],command:[390,.18],count:[540,.1],glass:[1800,.18]};
    const [frequency,duration]=notes[kind]||notes.click;
    const osc=c.createOscillator(),gain=c.createGain();osc.type=kind==='fail'?'triangle':'sine';osc.frequency.setValueAtTime(frequency,t);osc.frequency.exponentialRampToValueAtTime(kind==='success'?1320:frequency*.7,t+duration);gain.gain.setValueAtTime(.0001,t);gain.gain.exponentialRampToValueAtTime(.09,t+.012);gain.gain.exponentialRampToValueAtTime(.0001,t+duration);osc.connect(gain).connect(this.master);osc.start(t);osc.stop(t+duration+.02);
  }
  async enableVoice(send){
    await this.init();if(this.stream)return;
    if(!navigator.mediaDevices?.getUserMedia)throw new Error('Sesli sohbet için HTTPS bağlantısı gerekiyor.');
    const stream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true},video:false});
    this.stream=stream;await this.context.audioWorklet.addModule('/voice-worklet.js');
    this.source=this.context.createMediaStreamSource(stream);this.worklet=new AudioWorkletNode(this.context,'lockdown-voice');
    this.worklet.port.onmessage=({data})=>{if(!this.voiceActive)return;let str='';for(const b of new Uint8Array(data))str+=String.fromCharCode(b);send(btoa(str));};
    const silent=this.context.createGain();silent.gain.value=0;this.source.connect(this.worklet).connect(silent).connect(this.context.destination);
  }
  receiveVoice(id,audio,distance,radio){if(!this.context||this.muted.has(id)||this.settings.voiceVolume<=0)return;try{
    const bytes=Uint8Array.from(atob(audio),c=>c.charCodeAt(0));if(bytes.byteLength%2)return;const samples=new Int16Array(bytes.buffer),buffer=this.context.createBuffer(1,samples.length,16000),d=buffer.getChannelData(0);for(let i=0;i<samples.length;i++)d[i]=samples[i]/32768;
    const source=this.context.createBufferSource();source.buffer=buffer;const gain=this.context.createGain();gain.gain.value=this.settings.voiceVolume*(radio?1:Math.max(0,1-distance/40));source.connect(gain).connect(this.master);
    const now=this.context.currentTime;let start=Math.max(now+.015,this.nextVoice.get(id)||0);if(start>now+.5)start=now+.015;source.start(start);this.nextVoice.set(id,start+buffer.duration);
  }catch{}}
  stopVoice(){this.voiceActive=false;this.stream?.getTracks().forEach(track=>track.stop());this.source?.disconnect();this.worklet?.disconnect();this.stream=null;this.source=null;this.worklet=null;}
}
