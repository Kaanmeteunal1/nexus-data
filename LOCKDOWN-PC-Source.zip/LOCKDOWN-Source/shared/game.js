export const VERSION = '1.0.0';
export const PLAYER_HEIGHT = 1.72;
export const MAX_PLAYERS = 16;
export const MAPS = {
  blackwater: { id: 'blackwater', name: 'BLACKWATER', subtitle: 'Kıyı Ceza İnfaz Tesisi', number: '01', tag: 'KIYI / GÜN BATIMI', accent: '#e7ae6f', sky: '#738d98', fog: '#a1b0b1', concrete: '#9b9e99', ground: '#727b77', time: '18:42', description: 'Tuzlu hava. Paslı çelik. Özgürlüğe bakan bir avlu.' },
  ironworks: { id: 'ironworks', name: 'IRONWORKS', subtitle: 'Endüstriyel Tecrit Kompleksi', number: '02', tag: 'ENDÜSTRİ / GECE', accent: '#e88052', sky: '#17232e', fog: '#263a45', concrete: '#56616a', ground: '#3e5058', time: '02:16', description: 'Yüksek bacalar, kızıl fırınlar ve hiç susmayan makineler.' },
  northstar: { id: 'northstar', name: 'NORTHSTAR', subtitle: 'Kuzey Yüksek Güvenlik Tesisi', number: '03', tag: 'ALPİN / MAVİ SAAT', accent: '#8ccbd3', sky: '#8aa5b9', fog: '#b5c7d0', concrete: '#a2afb6', ground: '#bac5c7', time: '06:08', description: 'Karla örtülü dağların arasında, sessiz ve soğuk bir sınır.' }
};
export const GAMES = {
  parkour: { id: 'parkour', name: 'FİRAR ROTASI', en: 'THE RUN', number: '01', label: 'PARKUR', duration: 120, origin: [-110, 0], spawn: [-110, 1.72, 19], color: '#ebb16e', description: 'Boşlukları aş, kontrol noktalarını bul ve çıkışa ulaş.', rule: 'Sıçra. Dengeyi koru. Çıkış halkasına ulaş.', icon: 'route' },
  redlight: { id: 'redlight', name: 'SON KOMUT', en: 'RED / GREEN', number: '02', label: 'REFLEKS', duration: 90, origin: [100, 0], spawn: [100, 1.72, 27], color: '#b9ce9a', description: 'Yeşilde ilerle. Kırmızıda tamamen dur. Tek hareket yeter.', rule: 'YEŞİL: ilerle · KIRMIZI: dur · Karşı çizgiyi geç.', icon: 'signal' },
  glass: { id: 'glass', name: 'CAM KÖPRÜ', en: 'TRUST FALL', number: '03', label: 'ŞANS / HAFIZA', duration: 110, origin: [-110, -110], spawn: [-110, 1.72, -87], color: '#8ec7d5', description: 'İki panel. Tek güvenli yol. Önündekine güvenebilir misin?', rule: 'Her sırada bir cam güvenli. Zıplayarak karşıya geç.', icon: 'grid' },
  colors: { id: 'colors', name: 'RENK KAPANI', en: 'COLOR DROP', number: '04', label: 'HAYATTA KAL', duration: 40, origin: [0, -110], spawn: [0, 1.72, -110], color: '#c4a6d7', description: 'Anons edilen rengi bul. Yanlış zemin ayaklarının altından gider.', rule: 'Hedef renge git. Sayaç bitince diğer paneller düşer.', icon: 'colors' },
  sweeper: { id: 'sweeper', name: 'SON AYAKTA', en: 'SWEEPER', number: '05', label: 'ZAMANLAMA', duration: 45, origin: [100, -110], spawn: [106, 1.72, -110], color: '#df9a89', description: 'Dönen kolun üzerinden atla. Hızlandıkça ritmi kaçırma.', rule: 'Dönen koldan zıplayarak kaç. 45 saniye dayan.', icon: 'rotate' },
  race: { id: 'race', name: 'AVLU YARIŞI', en: 'SPEEDLINE', number: '06', label: 'YARIŞ', duration: 100, origin: [0, 110], spawn: [-17, 1.72, 127], color: '#d5c18c', description: 'İki tur. Dört kontrol noktası. Çizgiyi ilk sen geç.', rule: 'Işıklı kapıları sırayla geç. İki tur tamamla.', icon: 'flag' }
};
export const COLOR_PALETTE = [
  { name: 'KEHRİBAR', value: '#d8a750' },
  { name: 'TURKUAZ', value: '#39969b' },
  { name: 'MERCAN', value: '#cb655b' },
  { name: 'LİLA', value: '#8875a7' }
];
export const HUB_SPAWN = [0, PLAYER_HEIGHT, 17];
export const COMMANDS = {
  line: 'SARI ÇİZGİDE SIRAYA GEÇİN',
  freeze: 'DONUN — HAREKET ETMEYİN',
  crouch: 'ÇÖMELİN VE BEKLEYİN',
  follow: 'GARDİYANI TAKİP EDİN',
  free: 'SERBEST ZAMAN',
  cells: 'HÜCRELERE DÖNÜN'
};
export function parkourPlatforms(map = 'blackwater') {
  const offset = map === 'ironworks' ? 0.4 : map === 'northstar' ? -0.4 : 0;
  return [
    {x: 0, z: 19, y: 0, w: 12, d: 7},
    {x: -2, z: 12, y: 0.7, w: 4.2, d: 3.6},
    {x: 2 + offset, z: 7, y: 1.35, w: 3.8, d: 3.8},
    {x: -1.7, z: 2, y: 2, w: 3.8, d: 3.5},
    {x: -4, z: -3, y: 2.6, w: 5.5, d: 4.5, checkpoint: true},
    {x: 1, z: -8, y: 3.2, w: 3.8, d: 3.6},
    {x: 5, z: -13, y: 3.8, w: 3.6, d: 3.8},
    {x: 0, z: -18, y: 4.4, w: 4.3, d: 4},
    {x: 0, z: -25, y: 4.8, w: 12, d: 7, finish: true}
  ];
}
export function glassRows() { return Array.from({length:8}, (_,i)=>({z: 16 - i * 5.1, x: [-2.3,2.3], w: 3.7, d: 4.2})); }
export function tileColor(col,row) { return (col * 3 + row * 2 + Math.floor(row / 2)) % 4; }
export function colorPhase(elapsed) {
  const round = Math.floor(elapsed / 6);
  return { target: (round * 3 + 1) % 4, dropping: elapsed % 6 >= 4.3, remaining: Math.max(0, 4.3 - elapsed % 6) };
}
export function lightPhase(elapsed) {
  const t = elapsed % 8.5;
  return { red: t >= 5, grace: t < 5.45, remaining: t < 5 ? 5-t : 8.5-t };
}
export function sweeperAngle(elapsed) { return elapsed * 0.95 + elapsed * elapsed * 0.009; }
export const RACE_GATES = [[-17,-17], [17,-17], [17,17], [-17,17]];
export function distance2(a,b) { return Math.hypot(a[0]-b[0],a[2]-b[2]); }
export function cleanName(value) { return String(value || 'Mahkûm').replace(/[\u0000-\u001f<>]/g, '').trim().slice(0,22) || 'Mahkûm'; }
export function validPosition(p) { return Array.isArray(p) && p.length === 3 && p.every(Number.isFinite) && Math.abs(p[0])<240 && Math.abs(p[2])<240 && p[1]>-40 && p[1]<60; }
