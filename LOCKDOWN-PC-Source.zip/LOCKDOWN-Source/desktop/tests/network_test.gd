extends Node

var role="host"
var report_path=""
var checks: Array=[]
var failures: Array=[]
var client_pid=-1
var phase=0
var age=0.0
var voice_ok=false
var client_done=false
var finished=false

func verify(condition: bool, message: String):
	if condition:
		checks.append(message)
		print("PASS ",role," / ",message)
	else:
		failures.append(message)
		push_error(message)

func _ready():
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--role="): role=arg.trim_prefix("--role=")
		if arg.begins_with("--report="): report_path=arg.trim_prefix("--report=")
	Session.event_received.connect(_event)
	Session.status_changed.connect(_status)
	Session.voice_received.connect(func(_id,bytes,radio):
		voice_ok=bytes.size()==1280 and radio
		if voice_ok: verify(true,"Native voice packet delivered with guard radio flag"))
	if role=="host":
		var err=Session.host_game("Host","blackwater","sandbox",false,9278)
		verify(err==OK,"Built-in ENet server opens on UDP 9278")
		client_pid=OS.create_process(OS.get_executable_path(),["--headless","--max-fps","60","--path",ProjectSettings.globalize_path("res://"),"res://tests/network.tscn","--","--role=client","--report="+report_path.get_basename()+"-client.json"])
		verify(client_pid>0,"Second native game process launches")
	else: Session.join_game("Client","127.0.0.1:9278")

func _status(status: String, detail: String):
	if status=="joined" and role=="client":
		verify(Session.local_id!=1,"Client receives an independent ENet peer identity")
		get_tree().create_timer(.3).timeout.connect(func():
			Session.send_action("cells",{"open":false})
			get_tree().create_timer(.3).timeout.connect(func():
				verify(Session.state.get("cells_open",false),"Network prisoner action cannot close gates")
				Session.send_movement(Vector3(.5,1.72,17),.2,false)
				get_tree().create_timer(.2).timeout.connect(func(): Session.send_action("chat",{"text":"__READY__"}))))
	if status in ["failed","lost"] and not finished:
		verify(false,detail)
		_finish()

func _event(kind: String, body: Dictionary):
	if kind=="command" and role=="client": verify(body.text=="DONUN — HAREKET ETMEYİN","Guard announcement reaches native client")
	if kind!="chat" or role!="host": return
	match body.text:
		"__READY__":
			verify(Session.state.players.size()==2,"Both native processes share one roster")
			for p in Session.state.players:
				if p.id!=1:
					verify(absf(p.pos.x-.5)<.01,"Client movement reaches authoritative host")
					Session.send_action("role",{"id":p.id,"role":"guard"})
			Session.send_action("command",{"command":"freeze"})
			Session.send_action("cells",{"open":false})
			Session.send_action("start_game",{"game":"race"})
		"__ROUND_OK__":
			verify(Session.state.round.game=="race","Shared round exists on host")
			Session.send_action("end_round")
			Session.send_action("map",{"map":"ironworks"})
		"__IRON_OK__": Session.send_action("map",{"map":"northstar"})
		"__DONE__": client_done=true

func _process(delta: float):
	age+=delta
	if finished: return
	if age>15:
		verify(false,"Native network scenario timed out at phase "+str(phase))
		_finish()
		return
	if role=="host":
		if client_done and voice_ok:
			verify(true,"Client completes maps, roles, round and voice scenario")
			_finish()
		return
	var state=Session.state
	if state.is_empty(): return
	if phase==0 and state.get("round",{}).get("game","")=="race":
		phase=1
		verify(not state.cells_open and Session.self_player().role=="guard","Gate state and role change replicate")
		var starts: Array=[]
		for p in state.players: starts.append(p.trial.started_ms)
		verify(starts.size()==2 and starts[0]==starts[1],"Native peers share one round countdown")
		verify(Session.self_player().pos.distance_to(Vector3(-17,1.72,127))<.01,"Shared game teleport reaches client")
		var bytes=PackedByteArray()
		bytes.resize(1280)
		Session.send_voice(bytes)
		get_tree().create_timer(.7).timeout.connect(func(): Session.send_action("chat",{"text":"__ROUND_OK__"}))
	elif phase==1 and state.map=="ironworks":
		phase=2
		verify(true,"Ironworks map change replicates")
		get_tree().create_timer(.7).timeout.connect(func(): Session.send_action("chat",{"text":"__IRON_OK__"}))
	elif phase==2 and state.map=="northstar":
		phase=3
		verify(state.round.is_empty() and Session.self_player().trial.is_empty(),"Northstar transition clears round and trial")
		_write_report()
		get_tree().create_timer(.7).timeout.connect(func():
			Session.send_action("chat",{"text":"__DONE__"})
			finished=true
			get_tree().create_timer(.5).timeout.connect(func(): get_tree().quit(0 if failures.is_empty() else 1)))

func _write_report():
	if not report_path.is_empty():
		var file=FileAccess.open(report_path,FileAccess.WRITE)
		file.store_string(JSON.stringify({"checks":checks,"failures":failures,"transport":"ENet / UDP","process":role},"  "))

func _finish():
	finished=true
	_write_report()
	print("NATIVE NETWORK ",role," ",checks.size()," passed, ",failures.size()," failed")
	get_tree().quit(0 if failures.is_empty() else 1)

func _exit_tree():
	if client_pid>0 and OS.is_process_running(client_pid): OS.kill(client_pid)
