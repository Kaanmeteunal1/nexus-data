extends Node

var game
var checks: Array=[]
var failures: Array=[]
var report_path=""

func verify(condition: bool, message: String):
	if condition:
		checks.append(message)
		print("PASS UI / ",message)
	else:
		failures.append(message)
		push_error(message)

func _ready():
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--report="): report_path=arg.trim_prefix("--report=")
	game=load("res://main.tscn").instantiate()
	add_child(game)
	_run.call_deferred()

func click(prefix: String):
	await get_tree().process_frame
	var target: Button
	for b in game.ui.root.find_children("*","Button",true,false):
		if b.is_visible_in_tree() and b.text.begins_with(prefix):
			target=b
			break
	if not target:
		verify(false,"Button missing: "+prefix)
		return
	var center=target.get_global_rect().get_center()
	var motion=InputEventMouseMotion.new()
	motion.position=center
	motion.global_position=center
	get_viewport().push_input(motion,true)
	var down=InputEventMouseButton.new()
	down.button_index=MOUSE_BUTTON_LEFT
	down.pressed=true
	down.position=center
	down.global_position=center
	get_viewport().push_input(down,true)
	await get_tree().process_frame
	var up=InputEventMouseButton.new()
	up.button_index=MOUSE_BUTTON_LEFT
	up.pressed=false
	up.position=center
	up.global_position=center
	get_viewport().push_input(up,true)
	await get_tree().process_frame

func key(code: int, pressed: bool):
	var event=InputEventKey.new()
	event.physical_keycode=code
	event.keycode=code
	event.pressed=pressed
	Input.parse_input_event(event)
	await get_tree().process_frame

func tap(code: int):
	await key(code,true)
	await key(code,false)

func _run():
	await click("TESİSE GİR")
	verify(Session.active and game.ui.current_dialog=="welcome","Home button opens a playable solo session")
	await click("HAZIRIM")
	verify(game.ui.current_dialog.is_empty() and Input.mouse_mode==Input.MOUSE_MODE_CAPTURED,"Welcome button captures the mouse for native controls")
	for i in 30: await get_tree().physics_frame
	var start=game.player.global_position
	await key(KEY_W,true)
	for i in 45: await get_tree().physics_frame
	await key(KEY_W,false)
	verify(game.player.global_position.z<start.z-2,"Real key events move the native character")
	await tap(KEY_SPACE)
	for i in 12: await get_tree().physics_frame
	verify(game.player.global_position.y>.5,"Space key performs a native physics jump")
	for i in 60: await get_tree().physics_frame
	await tap(KEY_M)
	verify(game.ui.current_dialog=="games","M opens the arena selector")
	await click("OYNA")
	verify(Session.self_player().trial.get("game","")=="parkour" and absf(game.player.global_position.x+110)<.1,"Arena button starts parkour and teleports the player")
	await tap(KEY_G)
	verify(game.ui.current_dialog=="warden","G opens the warden console")
	await click("DONUN")
	verify(Session.state.command.get("text","")=="DONUN — HAREKET ETMEYİN","Console button issues a visible warden command")
	await tap(KEY_ESCAPE)
	await click("AVLUYA DÖN")
	verify(Session.self_player().trial.is_empty() and game.player.global_position.z>16,"Menu returns the player to the hub")
	await tap(KEY_G)
	await click("IRONWORKS")
	verify(Session.state.map=="ironworks" and game.facility.map_id=="ironworks","Native map switch loads the next facility")
	await tap(KEY_G)
	await click("NORTHSTAR")
	verify(Session.state.map=="northstar" and game.facility.map_id=="northstar","Third facility loads through the actual interface")
	await tap(KEY_ESCAPE)
	await click("OYUNCULAR")
	verify(game.ui.current_dialog=="roster","Roster opens with the session player")
	var report={"checks":checks,"failures":failures,"input":"Godot mouse hit testing and physical key events","renderer":RenderingServer.get_current_rendering_method(),"display":DisplayServer.get_name()}
	if not report_path.is_empty():
		var file=FileAccess.open(report_path,FileAccess.WRITE)
		file.store_string(JSON.stringify(report,"  "))
	print("NATIVE INTERFACE ",checks.size()," passed, ",failures.size()," failed")
	get_tree().quit(0 if failures.is_empty() else 1)
