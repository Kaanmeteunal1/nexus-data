extends Node

const Rules = preload("res://scripts/rules.gd")
var checks: Array = []
var failures: Array = []

func fixture():
	var r=Rules.new()
	r.now_ms=100000
	r.add_player(1,"Gardiyan")
	r.add_player(2,"Mahkûm")
	r.events.clear()
	return r

func verify(condition: bool, message: String):
	if condition:
		checks.append(message)
		print("PASS ",message)
	else:
		failures.append(message)
		push_error(message)

func _ready():
	var r=fixture()
	verify(r.players[1].role=="warden" and r.players[2].role=="prisoner","Initial native player roles")
	r.action(2,"cells",{"open":false})
	r.action(2,"command",{"command":"freeze"})
	r.action(2,"start_game",{"game":"parkour"})
	verify(r.cells_open and r.command.is_empty() and r.round_state.is_empty(),"Prisoner cannot mutate warden state")
	r.action(1,"role",{"id":2,"role":"guard"})
	r.action(2,"cells",{"open":false})
	verify(not r.cells_open and r.players[2].role=="guard","Host grants guard role and guard can control gates")
	r=fixture()
	r.now_ms+=100
	r.apply_movement(2,Vector3(.5,1.72,17),.1,false)
	r.apply_movement(2,Vector3(200,1.72,200),0,false)
	verify(is_equal_approx(r.players[2].pos.x,.5),"Native movement rejects impossible teleports")
	r.action(1,"practice",{"game":"parkour"})
	r.now_ms=r.players[1].trial.started_ms+1000
	r.players[1].pos=Vector3(-114,4.32,-3)
	r.tick(r.now_ms)
	var cp=r.players[1].trial.checkpoint
	r.players[1].pos.y=-10
	r.tick(r.now_ms+100)
	verify(cp==1 and r.players[1].pos.distance_to(Vector3(-114,4.32,-3))<.01,"Parkour checkpoint and fall recovery")
	r.players[1].pos=Vector3(-110,6.52,-25)
	r.tick(r.now_ms+100)
	verify(r.players[1].trial.is_empty() and r.players[1].score==100,"Parkour finish awards points once")
	r=fixture()
	r.action(1,"start_game",{"game":"redlight"})
	var started=r.players[1].trial.started_ms
	verify(started==r.players[2].trial.started_ms,"Common native round has a shared countdown")
	r.tick(started+5700)
	r.players[2].pos.z-=1
	r.tick(started+5800)
	verify(r.players[2].status=="out","Red-light violation eliminates in a shared round")
	r=fixture()
	r.action(1,"practice",{"game":"glass"})
	r.action(2,"practice",{"game":"glass"})
	var safe=r.players[1].trial.safe[0]
	r.players[1].pos=Vector3(-107.7 if safe==0 else -112.3,1.72,-94)
	r.tick(r.players[1].trial.started_ms+100)
	verify(r.players[1].trial.broken.size()==1 and r.players[2].trial.broken.is_empty() and not r.snapshot().players[0].trial.has("safe"),"Glass path secrecy and independent practice panels")
	r=fixture()
	r.action(1,"start_game",{"game":"colors"})
	started=r.players[1].trial.started_ms
	r.players[1].pos=Vector3(5,1.72,-120)
	r.players[2].pos=Vector3(-10,1.72,-120)
	r.tick(started+4600)
	verify(not r.players[1].trial.is_empty() and r.players[2].status=="out","Color drop distinguishes target and wrong tile")
	r.tick(started+41000)
	verify(r.players[1].score==100 and r.round_state.state=="finished","Survival timeout resolves the shared round")
	r=fixture()
	r.action(1,"start_game",{"game":"sweeper"})
	started=r.players[1].trial.started_ms
	r.players[1].pos=Vector3(100,3.1,-104)
	r.players[2].pos=Vector3(100,1.72,-104)
	r.tick(started)
	verify(not r.players[1].trial.is_empty() and r.players[2].status=="out","Jump clears the sweeper while ground contact loses")
	r=fixture()
	r.action(1,"practice",{"game":"race"})
	r.now_ms=r.players[1].trial.started_ms+1000
	for lap in 2:
		for gate in r.data.race_gates:
			r.players[1].pos=Vector3(gate[0],1.72,gate[1]+110)
			r.tick(r.now_ms+500)
	verify(r.players[1].trial.is_empty() and r.players[1].score==100,"Native race requires eight ordered gates across two laps")
	r.action(1,"practice",{"game":"parkour"})
	r.action(1,"map",{"map":"northstar"})
	verify(r.map_id=="northstar" and r.players[1].trial.is_empty() and r.players[1].pos==Vector3(0,1.72,17),"Map transition clears trials and restores hub spawn")
	var report={"checks":checks,"failures":failures,"engine":Engine.get_version_info().string}
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--report="):
			var file=FileAccess.open(arg.trim_prefix("--report="),FileAccess.WRITE)
			file.store_string(JSON.stringify(report,"  "))
	print("NATIVE RULES ",checks.size()," passed, ",failures.size()," failed")
	get_tree().quit(0 if failures.is_empty() else 1)
