extends Node3D

var map_id = "blackwater"
var model: Node3D
var environment: WorldEnvironment
var sun: DirectionalLight3D
var collision_data: Dictionary
var gates: Array = []
var tile_parts: Array = []
var glass_parts: Array = []
var areas: Dictionary = {}
var terminals: Array = []
var beam: Node3D
var signal_lights: Array = []
var water: MeshInstance3D
var water_material: ShaderMaterial
var total_time = 0.0
var concrete_normal: NoiseTexture2D

func _ready():
	load_facility(map_id)

func make_body(position: Vector3, size: Vector3, enabled: bool = true, radius: float = 0.0) -> StaticBody3D:
	var body=StaticBody3D.new()
	body.position=position
	var shape=CollisionShape3D.new()
	if radius>0:
		var cylinder=CylinderShape3D.new()
		cylinder.radius=radius
		cylinder.height=size.y
		shape.shape=cylinder
	else:
		var box=BoxShape3D.new()
		box.size=size
		shape.shape=box
	shape.disabled=not enabled
	body.add_child(shape)
	add_child(body)
	return body

func load_facility(id: String):
	for child in get_children():
		remove_child(child)
		child.queue_free()
	map_id=id
	gates.clear()
	tile_parts.clear()
	glass_parts.clear()
	areas.clear()
	signal_lights.clear()
	model=load("res://assets/facility-"+id+".glb").instantiate()
	add_child(model)
	collision_data=JSON.parse_string(FileAccess.get_file_as_string("res://assets/collision-"+id+".json"))
	for c in collision_data.walls:
		var body=make_body(Vector3(c.x,(c.minY+c.maxY)/2,c.z),Vector3(c.w,c.maxY-c.minY,c.d),c.enabled)
		if not c.enabled:
			var index=gates.size()
			gates.append({"body":body,"mesh":model.find_child("Gate_"+str(index),true,false)})
	for f in collision_data.floors:
		var body=make_body(Vector3(f.x,f.y-.22,f.z),Vector3(f.w,.44,f.d),true,float(f.get("radius",0)))
		if absf(f.x)<=10.01 and f.z>=-120.01 and f.z<=-99.99 and f.w<5:
			var col=int(round((f.x+10)/5))
			var row=int(round((f.z+120)/5))
			var index=row*5+col
			tile_parts.append({"body":body,"mesh":model.find_child("ColorTile_"+str(index),true,false),"label":model.find_child("ColorLabel_"+str(index),true,false),"color":GameData.tile_color(col,row)})
		if f.x<-105 and f.x>-115 and f.z<-90 and f.z>-133 and f.w<4:
			var row=int(round((-94-f.z)/5.1))
			var side=0 if f.x<-110 else 1
			glass_parts.append({"body":body,"mesh":model.find_child("Glass_"+str(row*2+side),true,false),"key":str(row)+":"+str(side)})
	for game in GameData.games:
		areas[game]=model.find_child("Arena_"+game,true,false)
	terminals=collision_data.terminals
	beam=model.find_child("SweeperArm",true,false)
	for i in 2: signal_lights.append(model.find_child("Signal_"+str(i),true,false))
	_add_lighting()
	_add_material_detail(model)
	_add_water()

func _add_material_detail(root: Node):
	var noise=FastNoiseLite.new()
	noise.noise_type=FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	noise.frequency=.14
	noise.fractal_octaves=4
	concrete_normal=NoiseTexture2D.new()
	concrete_normal.width=512
	concrete_normal.height=512
	concrete_normal.seamless=true
	concrete_normal.noise=noise
	concrete_normal.as_normal_map=true
	concrete_normal.bump_strength=.45
	var overrides: Dictionary={}
	for mesh in root.find_children("*","MeshInstance3D",true,false):
		for surface in mesh.mesh.get_surface_count():
			var original=mesh.get_active_material(surface)
			if not original is StandardMaterial3D: continue
			var name_key=original.resource_name
			if name_key in ["concrete","ground"]:
				if not overrides.has(name_key):
					var mat=original.duplicate()
					mat.normal_enabled=true
					mat.normal_texture=concrete_normal
					mat.normal_scale=.5 if name_key=="concrete" else .25
					mat.roughness=.88
					mat.uv1_triplanar=true
					mat.uv1_world_triplanar=true
					mat.uv1_scale=Vector3.ONE*(.22 if name_key=="concrete" else .7)
					overrides[name_key]=mat
				mesh.set_surface_override_material(surface,overrides[name_key])

func _add_lighting():
	var spec=GameData.maps[map_id]
	environment=WorldEnvironment.new()
	var env=Environment.new()
	environment.environment=env
	var sky=Sky.new()
	var sky_mat=ProceduralSkyMaterial.new()
	sky_mat.sky_top_color=Color(spec.sky).darkened(.2)
	sky_mat.sky_horizon_color=Color("c4bca7") if map_id=="blackwater" else Color(spec.fog)
	sky_mat.ground_bottom_color=Color("263d40")
	sky_mat.ground_horizon_color=Color(spec.fog)
	sky_mat.sky_curve=.3
	sky.sky_material=sky_mat
	env.background_mode=Environment.BG_SKY
	env.sky=sky
	env.ambient_light_source=Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_energy=1.0 if map_id!="ironworks" else .55
	env.reflected_light_source=Environment.REFLECTION_SOURCE_SKY
	env.tonemap_mode=Environment.TONE_MAPPER_ACES
	env.tonemap_exposure=1.0
	env.tonemap_white=6.0
	env.fog_enabled=true
	env.fog_light_color=Color(spec.fog)
	env.fog_density=.0028 if map_id!="ironworks" else .006
	env.fog_sky_affect=.2
	if RenderingServer.get_current_rendering_method()=="forward_plus":
		env.ssao_enabled=true
		env.ssao_radius=1.4
		env.ssao_intensity=1.4
		env.ssil_enabled=true
		env.ssil_intensity=.7
		env.glow_enabled=true
		env.glow_intensity=.4
		env.glow_hdr_threshold=1.6
		env.volumetric_fog_enabled=true
		env.volumetric_fog_density=.004 if map_id=="ironworks" else .0008
		env.volumetric_fog_albedo=Color(spec.fog)
	add_child(environment)
	sun=DirectionalLight3D.new()
	sun.rotation_degrees=Vector3(-32,-43,0)
	sun.light_color=Color("ffe2b6") if map_id=="blackwater" else Color("cfecff")
	sun.light_energy=2.2 if map_id!="ironworks" else .65
	sun.light_angular_distance=1.1
	sun.shadow_enabled=true
	sun.directional_shadow_max_distance=180
	sun.directional_shadow_mode=DirectionalLight3D.SHADOW_PARALLEL_4_SPLITS
	add_child(sun)
	if map_id=="ironworks":
		for location in collision_data.lamps:
			var light=OmniLight3D.new()
			light.position=GameData.vector(location)-Vector3(0,.5,0)
			light.light_color=Color("efb777")
			light.light_energy=4.5
			light.omni_range=16
			light.omni_attenuation=1.2
			add_child(light)

func _add_water():
	water=MeshInstance3D.new()
	var plane=PlaneMesh.new()
	plane.size=Vector2(1100,1100)
	water.mesh=plane
	water.position.y=-5.5
	water_material=ShaderMaterial.new()
	var shader=Shader.new()
	shader.code="""shader_type spatial;
render_mode cull_disabled;
uniform vec3 water_color : source_color = vec3(0.06,0.19,0.22);
varying vec3 world_position;
void vertex(){world_position=(MODEL_MATRIX*vec4(VERTEX,1.0)).xyz;}
void fragment(){vec2 p=world_position.xz;float n=sin(p.x*.7+TIME*.6+sin(p.y*.3))*sin(p.y*.8-TIME*.4);ALBEDO=water_color+n*.008;ROUGHNESS=.26;METALLIC=.45;NORMAL_MAP=normalize(vec3(sin(p.x*.7+TIME)*.05,sin(p.y*.8+TIME*.6)*.05,1.0))*.5+.5;}
"""
	water_material.shader=shader
	water.material_override=water_material
	add_child(water)

func update_view(delta: float, position: Vector3, preview: bool):
	total_time+=delta
	for id in areas:
		if areas[id]: areas[id].visible=not preview and position.distance_to(GameData.origin(id))<75
	var trial=Session.self_player().get("trial",{})
	var state=Session.state
	if trial.is_empty() and state.get("round",{}).get("state","")=="active": trial=state.round
	var elapsed=maxf(0,(Session.now()+Session.offset_ms-float(trial.get("started_ms",Session.now())))/1000.0)
	for gate in gates:
		var open=state.get("cells_open",true)
		if gate.mesh: gate.mesh.position.y=lerpf(gate.mesh.position.y,3.6 if open else 0.0,1-exp(-delta*6))
		gate.body.get_child(0).disabled=open
	var color_game=trial.get("game","")=="colors"
	var phase=GameData.color_phase(elapsed)
	for tile in tile_parts:
		var dropped=color_game and phase.dropping and tile.color!=phase.target
		if tile.mesh:
			tile.mesh.position.y=lerpf(tile.mesh.position.y,-6.0 if dropped else -.25,1-exp(-delta*12))
			if tile.label: tile.label.position.y=tile.mesh.position.y+.265
		tile.body.get_child(0).disabled=dropped
	var shattered=state.get("broken",[]) if state.get("round",{}).get("state","")=="active" else trial.get("broken",[])
	for part in glass_parts:
		var lost=shattered.has(part.key)
		if part.mesh: part.mesh.visible=not lost
		part.body.get_child(0).disabled=lost
	if beam: beam.rotation.y=GameData.sweeper_angle(elapsed if trial.get("game","")=="sweeper" else total_time*.25)
	for i in signal_lights.size():
		if signal_lights[i]:
			var red=trial.get("game","")=="redlight" and GameData.light_red(elapsed)
			signal_lights[i].visible=red if i==0 else not red

func nearest_terminal(position: Vector3) -> String:
	for terminal in terminals:
		if position.distance_to(GameData.vector(terminal.pos))<3.8: return terminal.game
	return ""
