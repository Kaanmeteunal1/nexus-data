extends Node

var catalog: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://assets/catalog.json"))
var maps: Dictionary:
	get: return catalog.maps
var games: Dictionary:
	get: return catalog.games
var commands: Dictionary:
	get: return catalog.commands
var colors: Array:
	get: return catalog.colors

func vector(values: Array) -> Vector3:
	return Vector3(float(values[0]), float(values[1]), float(values[2]))

func origin(game: String) -> Vector3:
	var a = games[game].origin
	return Vector3(a[0], 0, a[1])

func color_phase(elapsed: float) -> Dictionary:
	var phase = int(floor(elapsed / 6.0))
	return {"target": (phase * 3 + 1) % 4, "dropping": fmod(elapsed,6.0) >= 4.3, "remaining": maxf(0.0, 4.3 - fmod(elapsed,6.0))}

func tile_color(col: int, row: int) -> int:
	return (col * 3 + row * 2 + int(floor(row / 2.0))) % 4

func light_red(elapsed: float) -> bool:
	return fmod(elapsed,8.5) >= 5.0

func sweeper_angle(elapsed: float) -> float:
	return elapsed * .95 + elapsed * elapsed * .009

func clean_name(value) -> String:
	var text = str(value).strip_edges().left(22).replace("<", "").replace(">", "").replace("\n", " ")
	return text if not text.is_empty() else "Ziyaretçi"
