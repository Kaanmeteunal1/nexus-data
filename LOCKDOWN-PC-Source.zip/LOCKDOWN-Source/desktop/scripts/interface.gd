extends CanvasLayer

signal action_requested(action: String, args: Dictionary)

const ACCENT = Color("e7b376")
const INK = Color("162426")
const MUTED = Color("a4b3a6")
var display_font = preload("res://assets/display.ttf")
var body_font = preload("res://assets/body.ttf")
var root: Control
var home_layer: Control
var hud_layer: Control
var modal_layer: Control
var toast_layer: Control
var current_dialog = ""
var selected_map = "blackwater"
var selected_mode = "sandbox"
var profile_name = "Ziyaretçi"
var latest_result: Dictionary = {}
var player_name_input: LineEdit
var address_input: LineEdit
var map_choice: OptionButton
var mode_choice: OptionButton
var status_label: Label
var activity_label: Label
var cue_label: Label
var timer_label: Label
var role_label: Label
var player_label: Label
var count_label: Label
var stamina_bar: ProgressBar
var interact_label: Label
var countdown_label: Label
var chat_messages: Label
var chat_input: LineEdit
var command_label: Label
var command_timeout = 0.0
var voice_label: Label
var toasts: Array = []
var profile: Dictionary = {}
var hidden_hud = false

func _ready():
	root=Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter=Control.MOUSE_FILTER_IGNORE
	add_child(root)
	var theme=Theme.new()
	theme.default_font=body_font
	theme.default_font_size=16
	root.theme=theme
	home_layer=_layer(root)
	hud_layer=_layer(root)
	modal_layer=_layer(root)
	toast_layer=_layer(root)
	hud_layer.hide()
	show_home()

func _layer(parent: Node) -> Control:
	var control=Control.new()
	control.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	control.mouse_filter=Control.MOUSE_FILTER_IGNORE
	parent.add_child(control)
	return control

func _clear(parent: Node):
	for child in parent.get_children():
		parent.remove_child(child)
		child.queue_free()

func text(parent: Node, value: String, x: float, y: float, size: int = 16, color: Color = Color("e8e9de"), display: bool = false, width: float = 0) -> Label:
	var label=Label.new()
	label.text=value
	label.position=Vector2(x,y)
	label.add_theme_font_override("font",display_font if display else body_font)
	label.add_theme_font_size_override("font_size",size)
	label.add_theme_color_override("font_color",color)
	if hud_layer and (parent==hud_layer or hud_layer.is_ancestor_of(parent)):
		label.add_theme_color_override("font_outline_color",Color("091719bb"))
		label.add_theme_constant_override("outline_size",2)
	label.mouse_filter=Control.MOUSE_FILTER_IGNORE
	if width>0:
		label.size.x=width
		label.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
	parent.add_child(label)
	return label

func style(bg: Color, border: Color = Color.TRANSPARENT, radius: int = 3) -> StyleBoxFlat:
	var box=StyleBoxFlat.new()
	box.bg_color=bg
	box.border_color=border
	box.set_border_width_all(1)
	box.set_corner_radius_all(radius)
	box.content_margin_left=18
	box.content_margin_right=18
	box.content_margin_top=12
	box.content_margin_bottom=12
	return box

func panel(parent: Node, rect: Rect2, color: Color = INK, border: Color = Color("60736655")) -> Panel:
	var p=Panel.new()
	p.position=rect.position
	p.size=rect.size
	p.add_theme_stylebox_override("panel",style(color,border))
	p.mouse_filter=Control.MOUSE_FILTER_IGNORE
	parent.add_child(p)
	return p

func button(parent: Node, value: String, rect: Rect2, action: String, args: Dictionary = {}, primary: bool = false) -> Button:
	var b=Button.new()
	b.text=value
	b.position=rect.position
	b.size=rect.size
	b.add_theme_font_size_override("font_size",14)
	b.add_theme_color_override("font_color",INK if primary else Color("dae1d2"))
	b.add_theme_color_override("font_hover_color",INK if primary else ACCENT)
	b.add_theme_color_override("font_focus_color",INK if primary else ACCENT)
	b.add_theme_stylebox_override("normal",style(ACCENT if primary else Color("172728cc"),ACCENT if primary else Color("788e7155")))
	b.add_theme_stylebox_override("hover",style(Color("f1c795") if primary else Color("263b3a"),ACCENT))
	b.add_theme_stylebox_override("pressed",style(Color("bc8e58") if primary else Color("354a43"),ACCENT))
	b.add_theme_stylebox_override("focus",style(Color.TRANSPARENT,ACCENT))
	b.pressed.connect(func(): action_requested.emit(action,args))
	parent.add_child(b)
	return b

func field(parent: Node, value: String, placeholder: String, rect: Rect2, max_length: int = 22) -> LineEdit:
	var input=LineEdit.new()
	input.text=value
	input.placeholder_text=placeholder
	input.max_length=max_length
	input.position=rect.position
	input.size=rect.size
	input.add_theme_stylebox_override("normal",style(Color("0d1b1d"),Color("667e6755")))
	input.add_theme_stylebox_override("focus",style(Color("0d1b1d"),ACCENT))
	parent.add_child(input)
	return input

func _brand(parent: Node, x: float, y: float, compact: bool = false):
	for i in 3:
		var bar=ColorRect.new()
		bar.position=Vector2(x+i*11,y+i*5)
		bar.size=Vector2(6,35-i*10)
		bar.color=ACCENT
		bar.mouse_filter=Control.MOUSE_FILTER_IGNORE
		parent.add_child(bar)
	text(parent,"LOCKDOWN",x+48,y-5,28,Color("e6e8db"),true)
	if not compact: text(parent,"BLACKWATER  /  PC EDITION",x+49,y+29,8,MUTED)

func show_home():
	_clear(home_layer)
	home_layer.show()
	hud_layer.hide()
	close_dialog()
	var veil=ColorRect.new()
	veil.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	veil.mouse_filter=Control.MOUSE_FILTER_IGNORE
	var shader=Shader.new()
	shader.code="shader_type canvas_item; void fragment(){float a=mix(.96,.06,smoothstep(.15,1.,UV.x));float v=.35*pow(abs(UV.y-.5)*2.,2.);COLOR=vec4(.035,.075,.083,min(.98,a+v));}"
	var material=ShaderMaterial.new()
	material.shader=shader
	veil.material=material
	home_layer.add_child(veil)
	_brand(home_layer,67,42)
	text(home_layer,"OYNA",727,52,12,ACCENT)
	button(home_layer,"SAHA REHBERİ",Rect2(825,39,160,42),"guide")
	button(home_layer,"AYARLAR",Rect2(1000,39,115,42),"settings")
	status_label=text(home_layer,"WINDOWS / YEREL OYUN MOTORU",1260,52,9,Color("c1ceb6"))
	panel(home_layer,Rect2(68,107,1464,1),Color("8c9e7d33"),Color.TRANSPARENT)
	text(home_layer,"—   ÖZGÜRLÜK BİR TAKIM OYUNU.",68,200,11,ACCENT)
	text(home_layer,"LOCK",60,223,168,Color("e8e9de"),true)
	text(home_layer,"DOWN",60,355,168,ACCENT,true)
	text(home_layer,"BLACKWATER    —    PRISON PLAYGROUND",70,555,12,Color("bcc8b7"))
	text(home_layer,"Kuralları koy. Sınırları zorla.\nBu avluda hikâyeyi siz yazarsınız.",68,600,18,Color("acbbb1"),false,560)
	button(home_layer,"TESİSE GİR     →",Rect2(68,681,246,60),"quick",{},true)
	button(home_layer,"ODA AÇ",Rect2(328,681,180,60),"setup")
	button(home_layer,"SUNUCUYA KATIL",Rect2(68,755,246,43),"join")
	text(home_layer,"03 TESİS     /     06 OYUN     /     16 OYUNCUYA KADAR",68,821,10,MUTED)
	var spec=GameData.maps[selected_map]
	text(home_layer,"+   TESİS GÖRÜNTÜSÜ   /   "+spec.time,1090,209,10,Color("d8dfcc"))
	text(home_layer,spec.name,1090,232,51,Color("e6e9dc"),true)
	text(home_layer,spec.subtitle,1092,298,13,Color("c6d0be"))
	text(home_layer,"TESİS SEÇİMİ",879,641,10,Color("c1cbb8"))
	for i in GameData.maps.size():
		var id=GameData.maps.keys()[i]
		var map=GameData.maps[id]
		var p=panel(home_layer,Rect2(879+i*220,668,207,146),Color("172628dd"),ACCENT if id==selected_map else Color("7e967766"))
		text(p,map.number,14,9,12,Color("d8ddcc"))
		text(p,map.name,14,32,30,ACCENT if id==selected_map else Color("d4dec9"),true)
		text(p,map.tag,14,78,9,MUTED)
		var b=button(p,"SEÇİLİ" if id==selected_map else "TESİSİ GÖR →",Rect2(12,103,182,32),"select_map",{"map":id})
		b.add_theme_font_size_override("font_size",10)
	panel(home_layer,Rect2(68,860,1464,1),Color("8c9e7d33"),Color.TRANSPARENT)
	text(home_layer,"ARKADAŞLARINLA. KENDİ KURALLARINLA.",68,875,9,MUTED)
	text(home_layer,"PC SÜRÜMÜ  •  DAHİLİ YEREL AĞ ODALARI  •  KURULUM GEREKTİRMEZ",1000,875,9,MUTED)

func show_hud():
	home_layer.hide()
	_clear(hud_layer)
	hud_layer.show()
	var gradient=ColorRect.new()
	gradient.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	gradient.mouse_filter=Control.MOUSE_FILTER_IGNORE
	var shade_shader=Shader.new()
	shade_shader.code="shader_type canvas_item; void fragment(){float a=.65*smoothstep(.68,1.,UV.y)+.28*(1.-smoothstep(0.,.2,UV.y));COLOR=vec4(.025,.06,.065,a);}"
	var shade_material=ShaderMaterial.new()
	shade_material.shader=shade_shader
	gradient.material=shade_material
	hud_layer.add_child(gradient)
	_brand(hud_layer,32,31,true)
	text(hud_layer,"PC / "+GameData.maps[Session.state.map].name,82,65,9,MUTED)
	var activity=panel(hud_layer,Rect2(615,22,370,115),Color("132425aa"),Color("839a7133"))
	cue_label=text(activity,"SERBEST DOLAŞIM",0,9,11,ACCENT)
	cue_label.size.x=370
	cue_label.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
	activity_label=text(activity,"AVLU 07",0,31,36,Color("e7e9d9"),true)
	activity_label.size.x=370
	activity_label.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
	timer_label=text(activity,"Hikâyeyi siz yazın.",0,83,11,MUTED)
	timer_label.size.x=370
	timer_label.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
	count_label=text(hud_layer,"1 / 16 OYUNCU",1308,35,11,Color("c9d3bd"))
	button(hud_layer,"MENÜ  /  ESC",Rect2(1430,27,140,39),"pause")
	text(hud_layer,"+",790,435,20,Color("e8ecdcaa"))
	role_label=text(hud_layer,"BAŞ GARDİYAN",32,780,10,ACCENT)
	player_label=text(hud_layer,profile_name,32,798,30,Color("e4e8d8"),true)
	stamina_bar=ProgressBar.new()
	stamina_bar.position=Vector2(33,845)
	stamina_bar.size=Vector2(220,4)
	stamina_bar.show_percentage=false
	var track_style=StyleBoxFlat.new()
	track_style.bg_color=Color("657b6055")
	var fill_style=StyleBoxFlat.new()
	fill_style.bg_color=ACCENT
	stamina_bar.add_theme_stylebox_override("background",track_style)
	stamina_bar.add_theme_stylebox_override("fill",fill_style)
	hud_layer.add_child(stamina_bar)
	text(hud_layer,"DAYANIKLILIK",32,858,8,MUTED)
	text(hud_layer,"[M] Oyunlar    [G] Komut    [T] Sohbet    [V] Bas konuş    [C] Kamera    [ESC] Menü",501,861,11,Color("bdcbb0"))
	var address="TEK OYUNCULU" if Session.offline else Session.server_address
	text(hud_layer,address,1255,851,12,ACCENT)
	interact_label=text(hud_layer,"",540,680,26,Color("e5c391"),true)
	interact_label.size.x=520
	interact_label.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
	countdown_label=text(hud_layer,"",725,270,110,ACCENT,true)
	countdown_label.size.x=150
	countdown_label.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
	chat_messages=text(hud_layer,"",33,590,13,Color("d2ddc4"),false,420)
	chat_input=field(hud_layer,"","Mesajını yaz ve Enter’a bas…",Rect2(32,720,440,44),180)
	chat_input.hide()
	chat_input.text_submitted.connect(func(value):
		action_requested.emit("chat",{"text":value})
		chat_input.hide()
		get_viewport().gui_release_focus()
		Input.mouse_mode=Input.MOUSE_MODE_CAPTURED)
	command_label=text(hud_layer,"",450,170,28,ACCENT,true)
	command_label.size.x=700
	command_label.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
	voice_label=text(hud_layer,"● YAYINDASIN",708,811,13,ACCENT)
	voice_label.hide()

func open_chat():
	close_dialog()
	Input.mouse_mode=Input.MOUSE_MODE_VISIBLE
	chat_input.show()
	chat_input.text=""
	chat_input.grab_focus()

func close_dialog():
	current_dialog=""
	_clear(modal_layer)
	get_viewport().gui_release_focus()

func dialog_shell(title: String, subtitle: String, wide: bool = false) -> Panel:
	_clear(modal_layer)
	Input.mouse_mode=Input.MOUSE_MODE_VISIBLE
	var shade=ColorRect.new()
	shade.color=Color("071518dd")
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	modal_layer.add_child(shade)
	var rect=Rect2(420,175,760,550) if not wide else Rect2(225,90,1150,720)
	var p=panel(modal_layer,rect,Color("172627"),Color("859b7755"))
	panel(p,Rect2(0,0,70,3),ACCENT,Color.TRANSPARENT)
	text(p,subtitle,34,24,10,ACCENT)
	text(p,title,32,47,48,Color("e7eadb"),true)
	button(p,"×",Rect2(rect.size.x-66,21,40,40),"close")
	return p

func open_dialog(which: String):
	current_dialog=which
	var p: Panel
	match which:
		"setup":
			p=dialog_shell("KENDİ AVLINI KUR.","YEREL AĞ ODASI / WINDOWS")
			text(p,"Oyunu açan kişi ev sahibi olur. Aynı ağdaki arkadaşların adresinle bağlanır.",34,116,14,MUTED,false,680)
			text(p,"ÇAĞRI ADIN",34,168,10,MUTED)
			player_name_input=field(p,profile_name,"Sana ne diyelim?",Rect2(34,192,325,49))
			text(p,"TESİS",391,168,10,MUTED)
			map_choice=OptionButton.new()
			map_choice.position=Vector2(391,192)
			map_choice.size=Vector2(333,49)
			for id in GameData.maps: map_choice.add_item(GameData.maps[id].name)
			map_choice.select(GameData.maps.keys().find(selected_map))
			p.add_child(map_choice)
			text(p,"OYUN BİÇİMİ",34,272,10,MUTED)
			mode_choice=OptionButton.new()
			mode_choice.position=Vector2(34,297)
			mode_choice.size=Vector2(690,49)
			mode_choice.add_item("SERBEST ALAN · Herkes oyunları bağımsız deneyebilir")
			mode_choice.add_item("JAILBREAK · Oyunları gardiyan başlatır")
			p.add_child(mode_choice)
			text(p,"Yerel ağ: 16 kişiye kadar / UDP 9277. İnternet için yönlendirme veya barındırma gerekir.",34,377,12,MUTED,false,690)
			button(p,"ODAYI AÇ     →",Rect2(34,453,690,57),"host",{},true)
		"join":
			p=dialog_shell("EKİBİNE KATIL.","DOĞRUDAN SUNUCU BAĞLANTISI")
			text(p,"Ev sahibinin ekranda gösterilen IP adresini gir. Aynı oyun sürümünü kullanın.",34,118,14,MUTED,false,680)
			text(p,"ÇAĞRI ADIN",34,177,10,MUTED)
			player_name_input=field(p,profile_name,"Sana ne diyelim?",Rect2(34,202,690,49))
			text(p,"SUNUCU ADRESİ",34,283,10,MUTED)
			address_input=field(p,"","Örn. 192.168.1.25:9277",Rect2(34,308,690,49),100)
			text(p,"Oyuna internet üzerinden bağlanmak için erişilebilir bir sunucu adresi gerekir.",34,383,12,MUTED,false,680)
			button(p,"TESİSE GİRİŞ YAP     →",Rect2(34,453,690,57),"connect",{},true)
		"welcome":
			p=dialog_shell("AVLUYA HOŞ GELDİN.","GİRİŞ ONAYLANDI / "+GameData.maps[Session.state.map].name)
			text(p,"Serbest modda terminalleri kullanabilir veya M ile oyunlara girebilirsin.\nGardiyan paneli G tuşunda. Arkadaşlarınla kendi hikâyeni kur.",34,125,15,MUTED,false,680)
			var controls=["W A S D   Hareket","FARE   Etrafa bak","SPACE   Zıpla","SHIFT   Koş","CTRL   Çömel","C   Kamerayı değiştir","M   Oyunlar","G   Gardiyan konsolu","T   Sohbet","V   Bas konuş","R   Yeniden doğ","ESC   Menü"]
			for i in controls.size(): text(p,controls[i],34+(i%2)*350,229+int(i/2)*31,13,Color("c3d1b9"))
			button(p,"HAZIRIM. KAPILARI AÇ.     →",Rect2(34,453,690,57),"resume",{},true)
		"pause":
			p=dialog_shell("BİR NEFES AL.","TESİS / "+GameData.maps[Session.state.map].name)
			var buttons=[["OYUNA DÖN","resume"],["OYUN ALANLARI","games"],["OYUNCULAR","roster"],["MİKROFON AÇ / KAPAT","microphone"],["AYARLAR","settings"],["AVLUYA DÖN","hub"]]
			for i in buttons.size(): button(p,buttons[i][0],Rect2(34+(i%2)*350,130+int(i/2)*89,333,65),buttons[i][1],{},i==0)
			text(p,"Oyun dünyasında zaman akmaya devam eder.",34,414,12,MUTED)
			button(p,"ODADAN AYRIL",Rect2(34,453,333,57),"leave")
			button(p,"MASAÜSTÜNE ÇIK",Rect2(384,453,340,57),"quit")
		"guide", "games":
			p=dialog_shell("SIRADAKİ HAMLE.","ALTI FARKLI MÜCADELE / KENDİ KURALLARIN",true)
			var index=0
			for id in GameData.games:
				var game=GameData.games[id]
				var card=panel(p,Rect2(34+(index%3)*363,125+int(index/3)*254,348,237),Color("1b2d2b"),Color(game.color).darkened(.55))
				text(card,game.number+" / "+game.label,17,12,10,Color(game.color))
				text(card,game.en,17,36,13,MUTED)
				text(card,game.name,15,60,34,Color("e3e8d7"),true)
				text(card,game.description,17,111,13,MUTED,false,312)
				text(card,str(game.duration)+" SANİYE",17,173,10,Color(game.color))
				button(card,"OYNA   →" if Session.active else "TESİSE GİR  →",Rect2(173,172,156,46),"practice" if Session.active else "quick",{"game":id},true)
				index+=1
			text(p,"SPACE Zıpla    •    SHIFT Koş    •    R Kontrol noktasına dön    •    H Arayüzü gizle    •    1 / 2 / 3 İfadeler",34,668,12,MUTED)
		"warden":
			p=dialog_shell("KONTROL SENDE.","GARDİYAN KONSOLU / TÜM ODAYA ANONS",true)
			if not Session.self_player().get("role","") in ["warden","guard"]:
				text(p,"Bu panel gardiyanlara aittir. Oda sahibi sana gardiyan rolü verebilir.",34,150,18,MUTED,false,1000)
				return
			text(p,"HIZLI KOMUTLAR",34,122,10,MUTED)
			var i=0
			for id in GameData.commands:
				var b=button(p,GameData.commands[id],Rect2(34+(i%2)*273,151+int(i/2)*65,258,52),"command",{"command":id})
				b.add_theme_font_size_override("font_size",11)
				i+=1
			var command_input=field(p,"","Kendi komutunu yaz…",Rect2(34,357,425,49),100)
			var send=button(p,"ANONS",Rect2(470,357,95,49),"no_op")
			command_input.text_submitted.connect(func(value): action_requested.emit("custom_command",{"text":value}))
			send.pressed.connect(func(): action_requested.emit("custom_command",{"text":command_input.text}))
			button(p,"KAPILARI KİLİTLE" if Session.state.cells_open else "KAPILARI AÇ",Rect2(34,429,531,52),"cells")
			text(p,"ORTAK TUR BAŞLAT",611,122,10,MUTED)
			i=0
			for id in GameData.games:
				button(p,GameData.games[id].name,Rect2(611+(i%2)*260,151+int(i/2)*65,244,52),"round",{"game":id})
				i+=1
			button(p,"TURU BİTİR / HERKESİ AVLUYA AL",Rect2(611,357,504,49),"end_round")
			button(p,"OYUNCULAR / ROL DAĞITIMI",Rect2(611,429,504,52),"roster")
			if Session.local_id==1:
				text(p,"TESİS DEĞİŞTİR",34,524,10,MUTED)
				i=0
				for id in GameData.maps:
					button(p,GameData.maps[id].name,Rect2(34+i*363,553,348,54),"switch_map",{"map":id})
					i+=1
		"roster":
			p=dialog_shell("AYNI AVLU.","OYUNCULAR / ROLLER / SES")
			var scroll=ScrollContainer.new()
			scroll.position=Vector2(34,120)
			scroll.size=Vector2(692,370)
			p.add_child(scroll)
			var list=VBoxContainer.new()
			list.custom_minimum_size.x=670
			list.add_theme_constant_override("separation",8)
			scroll.add_child(list)
			for person in Session.state.get("players",[]):
				var row=Control.new()
				row.custom_minimum_size=Vector2(670,63)
				list.add_child(row)
				text(row,person.name+(" / SEN" if person.id==Session.local_id else ""),0,0,21,Color("d9e2cf"),true)
				text(row,_role(person.role),0,33,9,ACCENT)
				text(row,str(person.score)+" PUAN",305,17,12,MUTED)
				if person.id!=Session.local_id:
					if Session.local_id==1:
						var next_role="guard" if person.role=="prisoner" else "prisoner"
						var b=button(row,"GARDİYAN" if next_role=="guard" else "MAHKÛM",Rect2(402,5,117,43),"role",{"id":person.id,"role":next_role})
						b.add_theme_font_size_override("font_size",10)
					button(row,"SES",Rect2(528,5,62,43),"mute",{"id":person.id})
					if Session.local_id==1: button(row,"ÇIKAR",Rect2(598,5,70,43),"kick",{"id":person.id})
		"settings":
			p=dialog_shell("KENDİ RİTMİN.","GÖRÜNTÜ / KONTROL / SES")
			var definitions=[["Ana ses","volume",0.0,1.0,.05,float(profile.get("volume",.65))],["Sesli sohbet","voice_volume",0.0,1.0,.05,float(profile.get("voice_volume",.8))],["Fare hassasiyeti","sensitivity",.2,3.0,.1,float(profile.get("sensitivity",1))],["Görüş alanı","fov",60.0,100.0,1.0,float(profile.get("fov",78))]]
			for i in definitions.size():
				var setting=definitions[i]
				text(p,setting[0],34,126+i*67,14,Color("cbd7c1"))
				var slider=HSlider.new()
				slider.min_value=setting[2]
				slider.max_value=setting[3]
				slider.step=setting[4]
				slider.value=setting[5]
				slider.position=Vector2(300,132+i*67)
				slider.size=Vector2(423,30)
				slider.value_changed.connect(func(value): action_requested.emit("setting",{"key":setting[1],"value":value}))
				p.add_child(slider)
			button(p,"TAM EKRAN  /  F11",Rect2(34,425,334,56),"fullscreen")
			button(p,"GÖLGELER AÇ / KAPAT",Rect2(390,425,334,56),"shadows")
			text(p,"Ayarlar bu bilgisayara kaydedilir. Bas konuş: V. Kamera: C.",34,500,12,MUTED)
		"result":
			p=dialog_shell("İŞTE BU." if latest_result.get("success",false) else "BİR DAHA.","TUR SONUCU / "+GameData.games[latest_result.game].en)
			text(p,str(latest_result.reason),34,123,18,MUTED,false,690)
			text(p,"SÜRE",34,204,10,ACCENT)
			text(p,"%.2fs"%latest_result.elapsed,32,226,67,Color("dce5d2"),true)
			text(p,"PUAN",310,204,10,ACCENT)
			text(p,"+"+str(latest_result.score),308,226,67,Color("dce5d2"),true)
			text(p,"TEKRAR",542,204,10,ACCENT)
			text(p,str(latest_result.attempts),540,226,67,Color("dce5d2"),true)
			var shared=Session.state.get("round",{})
			text(p,"Oturum puanı: "+str(Session.self_player().get("score",0)),34,350,14,MUTED)
			if shared.get("state","")=="active":
				button(p,"DİĞER OYUNCULARI İZLE",Rect2(34,420,690,54),"resume",{},true)
			else: button(p,"TEKRAR DENE",Rect2(34,420,333,54),"retry",{},true)
			button(p,"AVLUYA DÖN",Rect2(390,485 if shared.get("state","")=="active" else 420,334,54),"hub")

func _role(role: String) -> String:
	return "BAŞ GARDİYAN" if role=="warden" else "GARDİYAN" if role=="guard" else "MAHKÛM"

func toast(message: String):
	var p=panel(toast_layer,Rect2(1230,110+toasts.size()*67,335,58),Color("122225f0"),Color("b8a67966"))
	text(p,message,13,10,12,Color("d2dec5"),false,310)
	toasts.append(p)
	get_tree().create_timer(4.5).timeout.connect(func():
		toasts.erase(p)
		if is_instance_valid(p): p.queue_free())

func show_command(body: Dictionary):
	if command_label:
		command_label.text=body.by+" / GARDİYAN\n"+body.text
		command_timeout=9

func chat_message(body: Dictionary):
	if chat_messages:
		var lines=chat_messages.text.split("\n")
		if lines.size()>5: lines.remove_at(0)
		lines.append(body.name+": "+body.text)
		chat_messages.text="\n".join(lines)

func update_hud(player, terminal: String, delta: float):
	if not hud_layer.visible: return
	var person=Session.self_player()
	role_label.text=_role(person.get("role","prisoner"))
	player_label.text=person.get("name",profile_name)
	count_label.text=str(Session.state.get("players",[]).size())+" / 16 OYUNCU"
	stamina_bar.value=player.stamina*100
	voice_label.visible=Input.is_physical_key_pressed(KEY_V) and Input.mouse_mode==Input.MOUSE_MODE_CAPTURED
	var trial=person.get("trial",{})
	if not trial.is_empty():
		var game=GameData.games[trial.game]
		var elapsed=(Session.now()+Session.offset_ms-trial.started_ms)/1000.0
		var remaining=maxf(0,game.duration-elapsed)
		activity_label.text=game.name
		cue_label.text=game.label
		cue_label.modulate=Color(game.color)
		if trial.game=="redlight":
			var red=GameData.light_red(maxf(0,elapsed))
			cue_label.text="KIRMIZI — DUR" if red else "YEŞİL — İLERLE"
			cue_label.modulate=Color("ed7c69") if red else Color("bcd699")
		elif trial.game=="colors":
			var phase=GameData.color_phase(maxf(0,elapsed))
			var target=GameData.colors[phase.target]
			cue_label.text=["A","B","C","D"][phase.target]+" / "+target.name+(" · ZEMİN DÜŞÜYOR" if phase.dropping else " · %.1fs"%phase.remaining)
			cue_label.modulate=Color(target.value)
		elif trial.game=="race": cue_label.text="TUR %d/2 · KAPI %d"%[mini(2,int(trial.laps)+1),int(trial.gate)+1]
		timer_label.text="%d:%02d  /  %s"%[int(remaining)/60,int(remaining)%60,"ORTAK TUR" if Session.state.get("round",{}).get("state","")=="active" else "ANTRENMAN"]
		countdown_label.text=str(int(ceil(-elapsed))) if elapsed<0 else ""
		interact_label.text=""
	else:
		activity_label.text="İZLEYİCİ" if person.get("status","")=="out" else "AVLU 07"
		cue_label.text="SERBEST DOLAŞIM" if Session.state.get("mode","")=="sandbox" else "JAILBREAK"
		cue_label.modulate=Color.WHITE
		timer_label.text="Hikâyeyi siz yazın."
		countdown_label.text=""
		interact_label.text="[ E ]    "+GameData.games[terminal].name+"    →" if not terminal.is_empty() else ""
	command_timeout-=delta
	if command_timeout<=0: command_label.text=""
