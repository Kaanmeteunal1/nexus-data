extends Node

signal voice_status(enabled: bool)

var volume = .65
var voice_volume = .8
var mic_enabled = false
var microphone: AudioStreamPlayer
var capture: AudioEffectCapture
var voice_players: Dictionary = {}
var muted: Dictionary = {}
var sounds: Dictionary = {}
var resample_phase = 0.0
var samples = PackedInt32Array()

func _ready():
	Session.voice_received.connect(receive_voice)
	for name in ["click","step","land","jump","command","checkpoint","success","fail","glass"]:
		sounds[name]=_sound(name)

func _sound(kind: String) -> AudioStreamWAV:
	var rate=16000
	var length=.09 if kind in ["step","land","click"] else .15 if kind=="jump" else .4
	var count=int(rate*length)
	var bytes=PackedByteArray()
	bytes.resize(count*2)
	var frequency={"click":460,"jump":180,"command":390,"checkpoint":660,"success":660,"fail":140,"glass":1700}.get(kind,250)
	var filtered=0.0
	for i in count:
		var t=float(i)/rate
		var envelope=pow(1.0-float(i)/count,2)
		var sample=sin(TAU*frequency*t*(1.0+t if kind=="success" else 1.0-t*.3))*.14
		if kind in ["step","land","glass"]:
			filtered=lerpf(filtered,randf_range(-1,1),.18 if kind!="glass" else .9)
			sample=filtered*(.22 if kind=="land" else .14)
		bytes.encode_s16(i*2,int(clampf(sample*envelope,-1,1)*32767))
	var stream=AudioStreamWAV.new()
	stream.format=AudioStreamWAV.FORMAT_16_BITS
	stream.mix_rate=rate
	stream.data=bytes
	return stream

func play(kind: String):
	if not sounds.has(kind): return
	var player=AudioStreamPlayer.new()
	player.stream=sounds[kind]
	player.volume_db=linear_to_db(maxf(.0001,volume))
	add_child(player)
	player.finished.connect(player.queue_free)
	player.play()

func enable_microphone():
	if mic_enabled:
		disable_microphone()
		return
	if AudioServer.get_bus_index("VoiceCapture")<0:
		AudioServer.add_bus()
		var index=AudioServer.bus_count-1
		AudioServer.set_bus_name(index,"VoiceCapture")
		capture=AudioEffectCapture.new()
		capture.buffer_length=.5
		AudioServer.add_bus_effect(index,capture)
		AudioServer.set_bus_mute(index,true)
	else: capture=AudioServer.get_bus_effect(AudioServer.get_bus_index("VoiceCapture"),0)
	microphone=AudioStreamPlayer.new()
	microphone.stream=AudioStreamMicrophone.new()
	microphone.bus="VoiceCapture"
	add_child(microphone)
	microphone.play()
	mic_enabled=true
	voice_status.emit(true)

func disable_microphone():
	if microphone:
		microphone.stop()
		microphone.queue_free()
		microphone=null
	mic_enabled=false
	samples.clear()
	voice_status.emit(false)

func reset_voice_peers():
	for player in voice_players.values():
		player.stop()
		player.queue_free()
	voice_players.clear()
	muted.clear()

func receive_voice(id: int, bytes: PackedByteArray, radio: bool):
	if muted.get(id,false) or voice_volume<=0: return
	if not voice_players.has(id):
		var player=AudioStreamPlayer.new()
		var generator=AudioStreamGenerator.new()
		generator.mix_rate=16000
		generator.buffer_length=.45
		player.stream=generator
		add_child(player)
		player.play()
		voice_players[id]=player
	var player=voice_players[id]
	var gain=voice_volume*volume
	if not radio:
		var own=Session.self_player().get("pos",Vector3.ZERO)
		for p in Session.state.get("players",[]):
			if p.id==id: gain*=maxf(0,1-own.distance_to(p.pos)/40.0)
	player.volume_db=linear_to_db(maxf(.0001,gain))
	var playback=player.get_stream_playback()
	var count=int(bytes.size()/2)
	if playback.get_frames_available()<count: return
	var frames=PackedVector2Array()
	frames.resize(count)
	for i in count:
		var value=float(bytes.decode_s16(i*2))/32768.0
		frames[i]=Vector2(value,value)
	playback.push_buffer(frames)

func _process(_delta):
	if not mic_enabled or not capture: return
	var available=capture.get_frames_available()
	if available<1: return
	var buffer=capture.get_buffer(available)
	if not Input.is_physical_key_pressed(KEY_V) or Input.mouse_mode!=Input.MOUSE_MODE_CAPTURED:
		samples.clear()
		return
	var step=AudioServer.get_mix_rate()/16000.0
	while resample_phase<buffer.size():
		var frame=buffer[int(resample_phase)]
		samples.append(int(clampf((frame.x+frame.y)*.5,-1,1)*32767))
		resample_phase+=step
	resample_phase-=buffer.size()
	if samples.size()>=640:
		var bytes=PackedByteArray()
		bytes.resize(1280)
		for i in 640: bytes.encode_s16(i*2,samples[i])
		samples=samples.slice(640)
		if samples.size()>3200: samples=samples.slice(samples.size()-3200)
		Session.send_voice(bytes)
