extends Node

signal state_changed(state: Dictionary)
signal event_received(kind: String, body: Dictionary)
signal status_changed(status: String, detail: String)
signal voice_received(id: int, bytes: PackedByteArray, radio: bool)

const Rules = preload("res://scripts/rules.gd")
const PORT = 9277
var rules
var state: Dictionary = {}
var local_id = 1
var offline = true
var active = false
var connected = false
var nickname = "Ziyaretçi"
var server_address = ""
var offset_ms = 0.0
var tick_accum = 0.0
var connect_deadline = 0
var last_voice: Dictionary = {}
var packet_rates: Dictionary = {}

func _ready():
	multiplayer.peer_disconnected.connect(_peer_left)
	multiplayer.connected_to_server.connect(_connected)
	multiplayer.connection_failed.connect(_connection_failed)
	multiplayer.server_disconnected.connect(_server_lost)

func now() -> float:
	return Time.get_unix_time_from_system()*1000.0

func host_game(display_name: String, map_name: String, mode_name: String, solo: bool = false, port: int = PORT) -> Error:
	leave()
	nickname=display_name
	offline=solo
	if not solo:
		var peer=ENetMultiplayerPeer.new()
		var result=peer.create_server(port,15,3)
		if result!=OK: return result
		multiplayer.multiplayer_peer=peer
	else: multiplayer.multiplayer_peer=OfflineMultiplayerPeer.new()
	local_id=1
	rules=Rules.new()
	rules.map_id=map_name if GameData.maps.has(map_name) else "blackwater"
	rules.mode=mode_name
	rules.now_ms=now()
	rules.add_player(1,GameData.clean_name(display_name))
	active=true
	connected=true
	var addresses: Array[String]=[]
	for address in IP.get_local_addresses():
		if address.begins_with("192.168.") or address.begins_with("10.") or address.begins_with("172."): addresses.append(address)
	server_address=(addresses[0] if not addresses.is_empty() else "127.0.0.1")+":"+str(port)
	_publish()
	status_changed.emit("joined","TEK OYUNCULU" if solo else server_address)
	return OK

func join_game(display_name: String, address: String) -> Error:
	leave()
	nickname=GameData.clean_name(display_name)
	var host_name=address.strip_edges()
	var port=PORT
	if ":" in host_name:
		var parts=host_name.split(":")
		if parts.size()!=2 or not parts[1].is_valid_int(): return ERR_INVALID_PARAMETER
		host_name=parts[0]
		port=int(parts[1])
	if host_name.is_empty() or port<1024 or port>65535: return ERR_INVALID_PARAMETER
	var peer=ENetMultiplayerPeer.new()
	var result=peer.create_client(host_name,port,3)
	if result!=OK: return result
	multiplayer.multiplayer_peer=peer
	offline=false
	active=true
	connected=false
	server_address=address
	connect_deadline=Time.get_ticks_msec()+10000
	status_changed.emit("connecting",address)
	return OK

func leave():
	active=false
	connected=false
	if multiplayer.multiplayer_peer: multiplayer.multiplayer_peer.close()
	multiplayer.multiplayer_peer=OfflineMultiplayerPeer.new()
	rules=null
	state={}
	packet_rates.clear()
	last_voice.clear()

func _connected():
	local_id=multiplayer.get_unique_id()
	connected=true
	_register.rpc_id(1,nickname)

func _connection_failed():
	leave()
	status_changed.emit("failed","Sunucuya bağlanılamadı. Adresi, yerel ağı ve güvenlik duvarını kontrol et.")

func _server_lost():
	leave()
	status_changed.emit("lost","Oda sahibi bağlantıyı kapattı.")

func _peer_left(id: int):
	if rules:
		rules.remove_player(id)
		_publish()

func _allow(id: int, limit: int = 90) -> bool:
	var clock=int(Time.get_ticks_msec()/1000)
	var meter=packet_rates.get(id,{"second":clock,"count":0})
	if meter.second!=clock: meter={"second":clock,"count":0}
	meter.count+=1
	packet_rates[id]=meter
	return meter.count<=limit

@rpc("any_peer","call_remote","reliable")
func _register(display_name: String):
	if not rules: return
	var id=multiplayer.get_remote_sender_id()
	if rules.players.size()>=16:
		multiplayer.multiplayer_peer.disconnect_peer(id)
		return
	rules.add_player(id,GameData.clean_name(display_name))
	_publish()

@rpc("authority","call_remote","unreliable_ordered",0)
func _receive_state(packet: PackedByteArray):
	var bytes=packet.decompress_dynamic(262144,FileAccess.COMPRESSION_DEFLATE)
	if bytes.is_empty(): return
	var snapshot=bytes_to_var(bytes)
	if not snapshot is Dictionary: return
	var first=state.is_empty()
	state=snapshot
	offset_ms=state.time-now()
	state_changed.emit(state)
	if first: status_changed.emit("joined",server_address)

@rpc("authority","call_remote","reliable")
func _deliver(kind: String, body: Dictionary):
	if kind=="kick":
		leave()
		status_changed.emit("lost","Oda sahibi seni odadan çıkardı.")
		return
	event_received.emit(kind,body)

func send_action(kind: String, body: Dictionary = {}):
	if not active: return
	if rules:
		rules.action(1,kind,body)
		_publish()
	else: _request.rpc_id(1,kind,body)

@rpc("any_peer","call_remote","reliable")
func _request(kind: String, body: Dictionary):
	var id=multiplayer.get_remote_sender_id()
	if rules and _allow(id):
		rules.action(id,kind,body)
		_publish()

func send_movement(position: Vector3, yaw: float, crouch: bool):
	if not active or not connected: return
	if rules: rules.apply_movement(1,position,yaw,crouch)
	else: _move.rpc_id(1,position,yaw,crouch)

@rpc("any_peer","call_remote","unreliable_ordered",1)
func _move(position: Vector3, yaw: float, crouch: bool):
	var id=multiplayer.get_remote_sender_id()
	if rules and _allow(id): rules.apply_movement(id,position,yaw,crouch)

func send_voice(bytes: PackedByteArray):
	if offline or not active: return
	if rules: _relay_voice(1,bytes)
	else: _voice_request.rpc_id(1,bytes)

@rpc("any_peer","call_remote","unreliable",2)
func _voice_request(bytes: PackedByteArray):
	if rules: _relay_voice(multiplayer.get_remote_sender_id(),bytes)

func _relay_voice(id: int, bytes: PackedByteArray):
	if bytes.size()>1280 or bytes.size()<2 or not rules.players.has(id): return
	var time=Time.get_ticks_msec()
	if time-int(last_voice.get(id,0))<35: return
	last_voice[id]=time
	var radio=rules.is_warden(id)
	if id!=1: voice_received.emit(id,bytes,radio)
	_voice_packet.rpc(id,bytes,radio)

@rpc("authority","call_remote","unreliable",2)
func _voice_packet(id: int, bytes: PackedByteArray, radio: bool):
	if id!=local_id: voice_received.emit(id,bytes,radio)

func _publish():
	if not rules: return
	state=rules.snapshot()
	state_changed.emit(state)
	if not offline and multiplayer.has_multiplayer_peer(): _receive_state.rpc(var_to_bytes(state).compress(FileAccess.COMPRESSION_DEFLATE))
	var pending=rules.events.duplicate()
	rules.events.clear()
	for event in pending:
		var target=int(event.target)
		if target==0 or target==1: event_received.emit(event.type,event.body)
		if not offline:
			if target==0: _deliver.rpc(event.type,event.body)
			elif target!=1 and multiplayer.get_peers().has(target):
				_deliver.rpc_id(target,event.type,event.body)
				if event.type=="kick": multiplayer.multiplayer_peer.disconnect_peer(target)

func _process(delta: float):
	if not active: return
	if not connected and Time.get_ticks_msec()>connect_deadline:
		_connection_failed()
		return
	tick_accum+=delta
	if rules and tick_accum>=.1:
		tick_accum=0
		rules.tick(now())
		_publish()

func self_player() -> Dictionary:
	for player in state.get("players",[]):
		if player.id==local_id: return player
	return {}
