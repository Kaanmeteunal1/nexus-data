extends CharacterBody3D

signal interaction
signal footstep(kind: String)

var camera: Camera3D
var head: Node3D
var shape: CollisionShape3D
var yaw = 0.0
var pitch = 0.0
var stamina = 1.0
var crouched = false
var enabled = false
var third_person = false
var sensitivity = .0015
var base_fov = 78.0
var jump_buffer = 0.0
var coyote = 0.0
var send_accum = 0.0
var step_accum = 0.0
var age = 0.0
var body_model: Node3D
var model_role = ""

func _ready():
	shape=CollisionShape3D.new()
	var capsule=CapsuleShape3D.new()
	capsule.radius=.29
	capsule.height=1.72
	shape.shape=capsule
	shape.position.y=.86
	add_child(shape)
	head=Node3D.new()
	head.position.y=1.72
	add_child(head)
	camera=Camera3D.new()
	camera.fov=base_fov
	camera.near=.06
	camera.far=650
	head.add_child(camera)
	floor_snap_length=.28
	floor_max_angle=deg_to_rad(50)
	set_role("warden")

func set_role(role: String):
	if model_role==role: return
	model_role=role
	if body_model: body_model.queue_free()
	body_model=load("res://assets/character-"+role+".glb").instantiate()
	add_child(body_model)
	body_model.rotation.y=PI
	body_model.visible=third_person

func _unhandled_input(event):
	if not enabled or Input.mouse_mode!=Input.MOUSE_MODE_CAPTURED: return
	if event is InputEventMouseMotion:
		yaw-=event.relative.x*sensitivity
		pitch=clampf(pitch-event.relative.y*sensitivity,-1.42,1.42)
	if event is InputEventKey and event.pressed and not event.echo:
		match event.physical_keycode:
			KEY_SPACE: jump_buffer=.14
			KEY_C:
				third_person=not third_person
				body_model.visible=third_person

func teleport(eye: Vector3, angle: float = 0):
	global_position=eye-Vector3.UP*1.72
	velocity=Vector3.ZERO
	yaw=angle
	pitch=0
	jump_buffer=0
	coyote=0

func _physics_process(delta):
	if not enabled: return
	age+=delta
	var input_ok=Input.mouse_mode==Input.MOUSE_MODE_CAPTURED
	var trial=Session.self_player().get("trial",{})
	if not trial.is_empty() and Session.now()+Session.offset_ms<trial.started_ms: input_ok=false
	var forward=(float(Input.is_physical_key_pressed(KEY_W))-float(Input.is_physical_key_pressed(KEY_S))) if input_ok else 0.0
	var sideways=(float(Input.is_physical_key_pressed(KEY_D))-float(Input.is_physical_key_pressed(KEY_A))) if input_ok else 0.0
	crouched=input_ok and Input.is_physical_key_pressed(KEY_CTRL)
	shape.shape.height=1.24 if crouched else 1.72
	shape.position.y=shape.shape.height/2.0
	var running=input_ok and Input.is_physical_key_pressed(KEY_SHIFT) and forward>0 and not crouched and stamina>.02
	var moving=absf(forward)+absf(sideways)>.01
	stamina=clampf(stamina+delta*(-.16 if running and moving else .22),0,1)
	var speed=2.5 if crouched else 10.0 if running else 6.4
	var direction=Vector3(sideways,0,-forward).normalized().rotated(Vector3.UP,yaw)
	var weight=1-exp(-delta*(15 if is_on_floor() else 5))
	velocity.x=lerpf(velocity.x,direction.x*speed,weight)
	velocity.z=lerpf(velocity.z,direction.z*speed,weight)
	jump_buffer=maxf(0,jump_buffer-delta)
	coyote=.1 if is_on_floor() else maxf(0,coyote-delta)
	if jump_buffer>0 and coyote>0 and input_ok:
		velocity.y=8.6
		jump_buffer=0
		coyote=0
		footstep.emit("jump")
	if not is_on_floor(): velocity.y-=22*delta
	if is_on_floor() and direction.length()>.1:
		var motion=Vector3(velocity.x,0,velocity.z)*delta
		if test_move(global_transform,motion):
			var raised=global_transform
			raised.origin.y+=.3
			if not test_move(raised,motion): global_position.y+=.25
	var grounded=is_on_floor()
	move_and_slide()
	if not grounded and is_on_floor(): footstep.emit("land")
	if is_on_floor() and moving:
		step_accum+=delta*(2 if running else 1.5)
		if step_accum>.55:
			step_accum=0
			footstep.emit("step")
	if global_position.y < -16:
		Session.send_action("respawn")
		velocity=Vector3.ZERO
		global_position.y=-10
	send_accum+=delta
	if send_accum>=.05:
		send_accum=0
		Session.send_movement(global_position+Vector3.UP*1.72,yaw,crouched)
	head.rotation=Vector3(pitch,yaw,0)
	head.position.y=lerpf(head.position.y,1.27 if crouched else 1.72,1-exp(-delta*12))
	camera.fov=lerpf(camera.fov,base_fov+(4 if running else 0),1-exp(-delta*6))
	camera.position=Vector3(0,.65,4.2) if third_person else Vector3.ZERO
	if third_person:
		var from=head.global_position
		var to=head.to_global(camera.position)
		var ray=PhysicsRayQueryParameters3D.create(from,to)
		ray.exclude=[get_rid()]
		var hit=get_world_3d().direct_space_state.intersect_ray(ray)
		if not hit.is_empty(): camera.global_position=hit.position+(from-to).normalized()*.18
	body_model.rotation.y=yaw+PI
	animate_model(body_model,delta,moving,crouched,Session.self_player().get("emote","") if Session.self_player().get("emote_until",0)>Session.now()+Session.offset_ms else "",age)

static func animate_model(model: Node3D, delta: float, moving: bool, crouch: bool, emote: String, time: float):
	var phase=time*(10 if moving else 2)
	var body=model.find_child("Body",true,false)
	if body:
		body.position.y=lerpf(body.position.y,-.42 if crouch else absf(sin(phase))*.025 if moving else sin(phase)*.008,1-exp(-delta*14))
		body.rotation.z=sin(time*4)*.12 if emote=="dance" else 0.0
	for side in ["L","R"]:
		var sign_side=-1 if side=="L" else 1
		var leg=model.find_child("Leg_"+side,true,false)
		var knee=model.find_child("Knee_"+side,true,false)
		var arm=model.find_child("Arm_"+side,true,false)
		var elbow=model.find_child("Elbow_"+side,true,false)
		var stride=sin(phase+sign_side*PI/2)*.65 if moving else 0.0
		if leg: leg.rotation.x=lerpf(leg.rotation.x,stride+(-.7 if crouch else 0.0),1-exp(-delta*14))
		if knee: knee.rotation.x=lerpf(knee.rotation.x,maxf(0,-stride)*.8+(1.3 if crouch else 0.0),1-exp(-delta*14))
		if arm:
			var angle=-stride*.8
			var roll=-sign_side*.06
			if emote=="wave" and side=="R":
				angle=-2.7
				roll=sin(time*8)*.25-.4
			elif emote=="salute" and side=="R":
				angle=-1.9
				roll=-.35
			elif emote=="dance":
				angle=sin(time*5+sign_side)*.8
				roll=sign_side*(.7+sin(time*4)*.2)
			arm.rotation.x=lerpf(arm.rotation.x,angle,1-exp(-delta*15))
			arm.rotation.z=lerpf(arm.rotation.z,roll,1-exp(-delta*15))
		if elbow: elbow.rotation.x=-1.5 if emote=="salute" else -.15
