extends RefCounted

var players: Dictionary = {}
var map_id = "blackwater"
var mode = "sandbox"
var cells_open = true
var round_state: Dictionary = {}
var command: Dictionary = {}
var broken: Array = []
var events: Array = []
var now_ms = 0.0
var data: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://assets/catalog.json"))
var rng = RandomNumberGenerator.new()

func _init():
	rng.randomize()

func emit_event(kind: String, body: Dictionary = {}, target: int = 0):
	events.append({"type":kind,"body":body,"target":target})

func vector(a) -> Vector3:
	return Vector3(a[0],a[1],a[2])

func add_player(id: int, display_name: String):
	if players.has(id) or players.size() >= 16:
		return
	var nickname = display_name.strip_edges().left(22).replace("<", "").replace(">", "").replace("\n", " ")
	players[id] = {"id":id,"name":nickname if not nickname.is_empty() else "Ziyaretçi","role":"warden" if id == 1 else "prisoner","pos":Vector3(0,1.72,17),"yaw":0.0,"score":0,"status":"idle","crouch":false,"moving":false,"trial":{},"last_move":now_ms,"last_chat":-1000.0,"emote":"","emote_until":0.0}
	teleport(id,Vector3(0,1.72,17))
	emit_event("notice",{"message":players[id].name + " tesise giriş yaptı."})

func remove_player(id: int):
	if players.has(id):
		emit_event("notice",{"message":players[id].name + " tesisten ayrıldı."})
		players.erase(id)

func teleport(id: int, position: Vector3):
	if not players.has(id): return
	players[id].pos = position
	players[id].last_move = now_ms
	emit_event("teleport",{"pos":position,"yaw":0.0},id)

func snapshot() -> Dictionary:
	var roster: Array = []
	for id in players:
		var p = players[id].duplicate(true)
		p.erase("last_move")
		p.erase("last_chat")
		if not p.trial.is_empty(): p.trial.erase("safe")
		roster.append(p)
	return {"map":map_id,"mode":mode,"host":1,"players":roster,"cells_open":cells_open,"round":round_state.duplicate(true),"command":command.duplicate(),"broken":broken.duplicate(),"time":now_ms}

func apply_movement(id: int, position: Vector3, yaw: float, crouch: bool):
	if not players.has(id): return
	if not position.is_finite() or not is_finite(yaw): return
	if absf(position.x)>240 or absf(position.z)>240 or position.y>60 or position.y < -40: return
	var p = players[id]
	var dt = clampf((now_ms-p.last_move)/1000.0,0.0,1.0)
	var delta = position-p.pos
	if Vector2(delta.x,delta.z).length()>12.5*dt+.75 or absf(delta.y)>30*dt+.9:
		emit_event("teleport",{"pos":p.pos,"yaw":p.yaw},id)
		return
	if not p.trial.is_empty() and now_ms < p.trial.started_ms: return
	p.pos = position
	p.yaw = yaw
	p.crouch = crouch
	p.moving = Vector2(delta.x,delta.z).length()>.02
	p.last_move = now_ms

func is_warden(id: int) -> bool:
	return players.has(id) and players[id].role in ["warden","guard"]

func active_round() -> bool:
	return round_state.get("state","") == "active"

func action(id: int, kind: String, args: Dictionary = {}):
	if not players.has(id): return
	var p = players[id]
	match kind:
		"chat":
			if now_ms-p.last_chat < 650: return
			p.last_chat = now_ms
			var text = str(args.get("text","")).strip_edges().left(180)
			if not text.is_empty(): emit_event("chat",{"name":p.name,"role":p.role,"text":text})
		"command":
			if not is_warden(id): return
			var text = data.commands.get(str(args.get("command","")),str(args.get("text","")).left(100))
			command = {"text":text,"by":p.name,"at":now_ms}
			emit_event("command",command)
		"cells":
			if not is_warden(id): return
			cells_open = bool(args.get("open",true))
			emit_event("notice",{"message":"Hücre kapıları açıldı." if cells_open else "Hücre kapıları kilitlendi."})
		"role":
			var target = int(args.get("id",0))
			var role = str(args.get("role","prisoner"))
			if id==1 and target!=1 and players.has(target) and role in ["guard","prisoner"]:
				players[target].role = role
		"kick":
			var target = int(args.get("id",0))
			if id==1 and target!=1 and players.has(target): emit_event("kick",{},target)
		"practice":
			var game = str(args.get("game",""))
			if not data.games.has(game): return
			if active_round():
				emit_event("notice",{"message":"Devam eden turun bitmesini bekle."},id)
				return
			if mode=="jailbreak" and not is_warden(id):
				emit_event("notice",{"message":"Jailbreak modunda oyunu gardiyan başlatır."},id)
				return
			begin(id,game,now_ms+2500,random_path())
		"start_game":
			var game = str(args.get("game",""))
			if not is_warden(id) or not data.games.has(game) or active_round(): return
			broken.clear()
			round_state = {"game":game,"state":"active","started_ms":now_ms+3500,"results":[]}
			var safe = random_path()
			for pid in players: begin(pid,game,round_state.started_ms,safe)
		"respawn":
			if not p.trial.is_empty(): reset_trial(id,"Kontrol noktasına dönüldü.")
			else: teleport(id,Vector3(0,1.72,17))
		"hub":
			if not p.trial.is_empty() and active_round(): finish(id,false,"Turdan ayrıldın.")
			p.trial = {}
			p.status = "idle"
			teleport(id,Vector3(0,1.72,17))
			emit_event("hub",{},id)
		"end_round":
			if not is_warden(id): return
			round_state = {}
			broken.clear()
			for pid in players:
				players[pid].trial = {}
				players[pid].status = "idle"
				teleport(pid,Vector3(0,1.72,17))
				emit_event("hub",{},pid)
		"map":
			var next_map = str(args.get("map",""))
			if id!=1 or not data.maps.has(next_map): return
			map_id = next_map
			cells_open = true
			round_state = {}
			broken.clear()
			command = {}
			for pid in players:
				players[pid].trial = {}
				players[pid].status = "idle"
				teleport(pid,Vector3(0,1.72,17))
				emit_event("map_changed",{"map":map_id},pid)
		"emote":
			var emote = str(args.get("emote",""))
			if emote in ["wave","salute","dance"]:
				p.emote = emote
				p.emote_until = now_ms+4000

func random_path() -> Array:
	var safe: Array = []
	for i in 8: safe.append(rng.randi_range(0,1))
	return safe

func begin(id: int, game: String, started: float, safe: Array):
	players[id].trial = {"game":game,"started_ms":started,"checkpoint":0,"laps":0,"gate":0,"safe":safe.duplicate(),"broken":[],"attempts":0,"red_anchor":null}
	players[id].status = "playing"
	teleport(id,vector(data.games[game].spawn))
	emit_event("trial",{"game":game},id)

func reset_trial(id: int, reason: String):
	var p = players[id]
	if p.trial.is_empty(): return
	if active_round():
		finish(id,false,reason)
		return
	p.trial.attempts += 1
	p.trial.red_anchor = null
	if p.trial.game=="parkour" and p.trial.checkpoint>0:
		var cp = data.platforms[map_id][4]
		teleport(id,Vector3(-110+cp.x,cp.y+1.72,cp.z))
	else:
		teleport(id,vector(data.games[p.trial.game].spawn))
		if p.trial.game in ["colors","sweeper"]: p.trial.started_ms = now_ms+2000
	emit_event("notice",{"message":reason},id)

func finish(id: int, success: bool, reason: String):
	var p = players[id]
	if p.trial.is_empty(): return
	var result = {"id":id,"name":p.name,"game":p.trial.game,"success":success,"elapsed":maxf(0,(now_ms-p.trial.started_ms)/1000.0),"attempts":p.trial.attempts,"reason":reason,"score":100 if success else 0}
	p.trial = {}
	p.status = "finished" if success else "out"
	if success: p.score+=100
	if active_round(): round_state.results.append(result)
	emit_event("result",result,id)
	emit_event("notice",{"message":p.name + (" tamamladı." if success else " elendi.")})

func tick(time_ms: float):
	now_ms = time_ms
	for id in players.keys():
		var p = players[id]
		if p.trial.is_empty(): continue
		var t = p.trial
		var elapsed = (now_ms-t.started_ms)/1000.0
		if elapsed<0: continue
		var g = data.games[t.game]
		if elapsed>g.duration:
			var survives = t.game in ["colors","sweeper"]
			finish(id,survives,"Sürenin sonuna kadar ayakta kaldın." if survives else "Süre doldu.")
			continue
		if p.pos.y < -5:
			reset_trial(id,"Düştün. Yeniden dene.")
			continue
		var x = p.pos.x-float(g.origin[0])
		var z = p.pos.z-float(g.origin[1])
		var feet = p.pos.y-1.72
		match t.game:
			"parkour":
				var cp = data.platforms[map_id][4]
				if t.checkpoint==0 and absf(x-cp.x)<cp.w/2 and absf(z-cp.z)<cp.d/2 and absf(feet-cp.y)<.3:
					t.checkpoint=1
					emit_event("checkpoint",{"message":"Kontrol noktası kaydedildi."},id)
				if t.checkpoint>0 and absf(x)<6 and absf(z+25)<2 and feet>4.5: finish(id,true,"Firar rotasını tamamladın.")
			"redlight":
				var cycle = fmod(elapsed,8.5)
				if cycle>5.45:
					if t.red_anchor==null: t.red_anchor = p.pos
					elif Vector2(p.pos.x-t.red_anchor.x,p.pos.z-t.red_anchor.z).length()>.24:
						reset_trial(id,"Kırmızı ışıkta hareket ettin.")
						continue
				else: t.red_anchor=null
				if z < -26: finish(id,true,"Son komutu geçtin.")
			"glass":
				for row in 8:
					var rz = 16-row*5.1
					var side = 0 if x<0 else 1
					var rx = -2.3 if side==0 else 2.3
					if absf(z-rz)<2.1 and absf(x-rx)<1.85 and feet<.35 and feet>-.5 and side!=t.safe[row]:
						var key = str(row)+":"+str(side)
						if not t.broken.has(key): t.broken.append(key)
						if active_round() and not broken.has(key): broken.append(key)
						emit_event("glass_break",{},id)
						reset_trial(id,"Cam kırıldı. Güvenli yolu hatırla.")
						break
				if not p.trial.is_empty() and z < -25.5 and feet>-.2: finish(id,true,"Köprünün öteki tarafındasın.")
			"colors":
				var target = (int(floor(elapsed/6))*3+1)%4
				var col = int(floor((x+12.5)/5))
				var row = int(floor((z+12.5)/5))
				var color = (col*3+row*2+int(floor(row/2.0)))%4
				if fmod(elapsed,6.0)>=4.3 and (col<0 or col>4 or row<0 or row>4 or color!=target) and feet<.4: reset_trial(id,"Yanlış renk. Zemin düştü.")
			"sweeper":
				var angle = elapsed*.95+elapsed*elapsed*.009
				var cross = absf(x*cos(angle)-z*sin(angle))
				var along = absf(x*sin(angle)+z*cos(angle))
				if cross<.6 and along<11.5 and Vector2(x,z).length()>1.3 and feet<.9: reset_trial(id,"Dönen kola yakalandın.")
			"race":
				var gate = data.race_gates[t.gate]
				if Vector2(x-gate[0],z-gate[1]).length()<5:
					t.gate=(int(t.gate)+1)%4
					if t.gate==0: t.laps+=1
					emit_event("checkpoint",{"message":"%d/2 tur · sıradaki kapıya ilerle"%t.laps},id)
					if t.laps>=2: finish(id,true,"İki turu tamamladın.")
	if active_round():
		var still_playing = false
		for p in players.values():
			if not p.trial.is_empty(): still_playing=true
		if not still_playing:
			round_state.state="finished"
			emit_event("round_ended",{"results":round_state.results})
