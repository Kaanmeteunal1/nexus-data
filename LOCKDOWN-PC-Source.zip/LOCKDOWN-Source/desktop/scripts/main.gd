extends Node3D

const Facility = preload("res://scripts/facility.gd")
const Player = preload("res://scripts/player.gd")
const Interface = preload("res://scripts/interface.gd")
const Audio = preload("res://scripts/audio.gd")
var facility
var player
var ui
var sound
var menu_camera: Camera3D
var game_started = false
var current_map = "blackwater"
var remote_models: Dictionary = {}
var time = 0.0
var profile: Dictionary = {"name":"Ziyaretçi","volume":.65,"voice_volume":.8,"sensitivity":1.0,"fov":78.0,"completed":0,"best":{}}
var capture_path = ""
var capture_timer = 0.0
var capture_frames = 0
var capture_done = false
var demo_game = ""
var latest_terminal = ""
var debug_test = false

func _ready():
	_load_profile()
	facility=Facility.new()
	add_child(facility)
	player=Player.new()
	add_child(player)
	player.footstep.connect(func(kind): sound.play(kind))
	menu_camera=Camera3D.new()
	menu_camera.fov=52
	menu_camera.far=650
	add_child(menu_camera)
	menu_camera.current=true
	sound=Audio.new()
	add_child(sound)
	ui=Interface.new()
	ui.profile_name=profile.name
	ui.profile=profile
	add_child(ui)
	ui.action_requested.connect(_ui_action)
	Session.state_changed.connect(_state_changed)
	Session.event_received.connect(_event_received)
	Session.status_changed.connect(_status_changed)
	_apply_settings()
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--capture="): capture_path=arg.trim_prefix("--capture=")
		if arg.begins_with("--demo="): demo_game=arg.trim_prefix("--demo=")
		if arg=="--test-physics": debug_test=true
	if not demo_game.is_empty() or debug_test:
		Session.host_game(profile.name,"blackwater","sandbox",true)
		_resume()
		if GameData.games.has(demo_game): Session.send_action("practice",{"game":demo_game})
		Input.mouse_mode=Input.MOUSE_MODE_VISIBLE
	if debug_test: _physics_check()

func _load_profile():
	var config=ConfigFile.new()
	if config.load("user://preferences.cfg")==OK:
		for key in profile: profile[key]=config.get_value("profile",key,profile[key])

func _save_profile():
	var config=ConfigFile.new()
	for key in profile: config.set_value("profile",key,profile[key])
	config.save("user://preferences.cfg")

func _apply_settings():
	player.sensitivity=float(profile.sensitivity)*.0015
	player.base_fov=float(profile.fov)
	sound.volume=float(profile.volume)
	sound.voice_volume=float(profile.voice_volume)
	ui.profile=profile

func _resume():
	ui.close_dialog()
	if game_started:
		get_viewport().gui_release_focus()
		Input.mouse_mode=Input.MOUSE_MODE_CAPTURED

func _ui_action(action: String, args: Dictionary):
	sound.play("click")
	match action:
		"quick":
			Session.host_game(profile.name,ui.selected_map,"sandbox",true)
		"select_map":
			ui.selected_map=args.map
			current_map=args.map
			facility.load_facility(current_map)
			ui.show_home()
		"host":
			profile.name=GameData.clean_name(ui.player_name_input.text)
			_save_profile()
			var map_name=GameData.maps.keys()[ui.map_choice.selected]
			var mode="sandbox" if ui.mode_choice.selected==0 else "jailbreak"
			var error=Session.host_game(profile.name,map_name,mode,false)
			if error!=OK: ui.toast("Oda açılamadı. UDP 9277 portu başka bir uygulamada kullanılıyor olabilir.")
		"connect":
			profile.name=GameData.clean_name(ui.player_name_input.text)
			_save_profile()
			var error=Session.join_game(profile.name,ui.address_input.text)
			if error!=OK: ui.toast("Geçerli bir sunucu adresi gir. Örnek: 192.168.1.25:9277")
		"setup","join","guide","games","pause","warden","settings","roster": ui.open_dialog(action)
		"close","resume":
			if game_started: _resume()
			else: ui.close_dialog()
		"practice":
			var kind="start_game" if Session.state.mode=="jailbreak" else "practice"
			Session.send_action(kind,{"game":args.game})
			_resume()
		"round":
			Session.send_action("start_game",{"game":args.game})
			_resume()
		"retry":
			var shared=not Session.state.get("round",{}).is_empty()
			Session.send_action("start_game" if shared else "practice",{"game":ui.latest_result.game})
			_resume()
		"command":
			Session.send_action("command",args)
			_resume()
		"custom_command":
			Session.send_action("command",args)
			_resume()
		"cells":
			Session.send_action("cells",{"open":not Session.state.cells_open})
			_resume()
		"hub":
			Session.send_action("hub")
			_resume()
		"end_round":
			Session.send_action("end_round")
			_resume()
		"switch_map":
			Session.send_action("map",args)
			_resume()
		"role","kick":
			Session.send_action(action,args)
			ui.open_dialog("roster")
		"mute":
			sound.muted[args.id]=not sound.muted.get(args.id,false)
			ui.toast("Oyuncunun sesi kapatıldı." if sound.muted[args.id] else "Oyuncunun sesi açıldı.")
		"chat":
			Session.send_action("chat",args)
		"microphone":
			sound.enable_microphone()
			ui.toast("Mikrofon açık. Konuşmak için V tuşunu basılı tut." if sound.mic_enabled else "Mikrofon kapatıldı.")
		"setting":
			profile[args.key]=args.value
			_apply_settings()
			_save_profile()
		"fullscreen": _fullscreen()
		"shadows":
			facility.sun.shadow_enabled=not facility.sun.shadow_enabled
			ui.toast("Gölgeler açık." if facility.sun.shadow_enabled else "Gölgeler kapalı.")
		"leave": _leave_game()
		"quit": get_tree().quit()

func _fullscreen():
	DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED if DisplayServer.window_get_mode()==DisplayServer.WINDOW_MODE_FULLSCREEN else DisplayServer.WINDOW_MODE_FULLSCREEN)

func _leave_game():
	Session.leave()
	sound.disable_microphone()
	sound.reset_voice_peers()
	player.enabled=false
	player.camera.current=false
	menu_camera.current=true
	game_started=false
	Input.mouse_mode=Input.MOUSE_MODE_VISIBLE
	for item in remote_models.values(): item.model.queue_free()
	remote_models.clear()
	ui.show_home()

func _state_changed(state: Dictionary):
	if state.map!=current_map:
		current_map=state.map
		facility.load_facility(current_map)
	var self_player=Session.self_player()
	if self_player.is_empty(): return
	if not game_started:
		game_started=true
		player.enabled=true
		player.camera.current=true
		player.teleport(self_player.pos)
		ui.profile_name=self_player.name
		ui.show_hud()
	player.set_role(self_player.role)
	var seen: Array=[]
	for p in state.players:
		if p.id==Session.local_id: continue
		seen.append(p.id)
		if remote_models.has(p.id) and remote_models[p.id].role!=p.role:
			remote_models[p.id].model.queue_free()
			remote_models.erase(p.id)
		if not remote_models.has(p.id):
			var avatar=load("res://assets/character-"+p.role+".glb").instantiate()
			add_child(avatar)
			avatar.position=p.pos-Vector3.UP*1.72
			var label=Label3D.new()
			label.text=p.name
			label.position.y=2.1
			label.pixel_size=.004
			label.font_size=36
			label.font=ui.body_font
			label.billboard=BaseMaterial3D.BILLBOARD_ENABLED
			label.no_depth_test=false
			avatar.add_child(label)
			remote_models[p.id]={"model":avatar,"role":p.role,"player":p}
		remote_models[p.id].player=p
	for id in remote_models.keys():
		if not seen.has(id):
			remote_models[id].model.queue_free()
			remote_models.erase(id)

func _status_changed(status: String, detail: String):
	match status:
		"joined":
			if demo_game.is_empty() and not debug_test: ui.open_dialog("welcome")
		"connecting": ui.toast("Bağlanılıyor: "+detail)
		"lost","failed":
			_leave_game()
			ui.toast(detail)

func _event_received(kind: String, body: Dictionary):
	match kind:
		"teleport": player.teleport(body.pos,float(body.get("yaw",0)))
		"notice": ui.toast(body.message)
		"chat": ui.chat_message(body)
		"command":
			ui.show_command(body)
			sound.play("command")
		"checkpoint":
			ui.toast(body.message)
			sound.play("checkpoint")
		"glass_break": sound.play("glass")
		"result":
			ui.latest_result=body
			if body.success:
				profile.completed+=1
				if body.elapsed<float(profile.best.get(body.game,INF)): profile.best[body.game]=body.elapsed
				_save_profile()
			ui.open_dialog("result")
			sound.play("success" if body.success else "fail")
		"hub","map_changed":
			if ui.current_dialog=="result": ui.open_dialog("pause")
		"trial":
			ui.toast(GameData.games[body.game].rule)
			sound.play("command")

func _unhandled_input(event):
	if event is InputEventKey and event.pressed and not event.echo:
		if event.physical_keycode==KEY_F11:
			_fullscreen()
			return
		if not game_started: return
		if ui.chat_input and ui.chat_input.has_focus():
			if event.physical_keycode==KEY_ESCAPE:
				ui.chat_input.hide()
				_resume()
			return
		match event.physical_keycode:
			KEY_ESCAPE:
				if ui.current_dialog.is_empty(): ui.open_dialog("pause")
				else: _resume()
			KEY_M: ui.open_dialog("games")
			KEY_G: ui.open_dialog("warden")
			KEY_TAB: ui.open_dialog("roster")
			KEY_T,KEY_ENTER: ui.open_chat()
			KEY_E:
				if not latest_terminal.is_empty():
					Session.send_action("start_game" if Session.state.mode=="jailbreak" else "practice",{"game":latest_terminal})
			KEY_R: Session.send_action("respawn")
			KEY_V:
				if not sound.mic_enabled:
					sound.enable_microphone()
					ui.toast("Bas konuş etkin. V tuşunu basılı tut.")
			KEY_H:
				ui.hidden_hud=not ui.hidden_hud
				ui.hud_layer.visible=not ui.hidden_hud
			KEY_1: Session.send_action("emote",{"emote":"wave"})
			KEY_2: Session.send_action("emote",{"emote":"salute"})
			KEY_3: Session.send_action("emote",{"emote":"dance"})

func _process(delta: float):
	time+=delta
	if not facility or not player or not ui: return
	if not game_started:
		menu_camera.position=Vector3(48+sin(time*.018)*5,29+sin(time*.01),56+cos(time*.018)*2)
		menu_camera.look_at(Vector3(-2,4,-10))
	else:
		latest_terminal=facility.nearest_terminal(player.global_position+Vector3.UP*1.72)
		ui.update_hud(player,latest_terminal,delta)
	facility.update_view(delta,player.global_position,not game_started)
	for item in remote_models.values():
		var p=item.player
		item.model.position=item.model.position.lerp(p.pos-Vector3.UP*1.72,1-exp(-delta*14))
		item.model.rotation.y=lerp_angle(item.model.rotation.y,p.yaw+PI,1-exp(-delta*12))
		Player.animate_model(item.model,delta,p.moving,p.crouch,p.emote if p.emote_until>Session.now()+Session.offset_ms else "",time)
	if not capture_path.is_empty() and not capture_done:
		capture_timer+=delta
		capture_frames+=1
		if capture_timer>1.5 or capture_frames>=30:
			capture_done=true
			_capture.call_deferred()

func _capture():
	await RenderingServer.frame_post_draw
	var image=get_viewport().get_texture().get_image()
	var result=image.save_png(capture_path)
	print("CAPTURE ",capture_path," ",result)
	get_tree().quit(0 if result==OK else 1)

func _physics_check():
	await get_tree().create_timer(1.0).timeout
	if absf(player.global_position.y)>.2:
		push_error("Player did not settle on yard ground")
		get_tree().quit(2)
		return
	player.velocity.y=8.6
	await get_tree().create_timer(.25).timeout
	if player.global_position.y<.5:
		push_error("Native jump did not rise")
		get_tree().quit(3)
		return
	await get_tree().create_timer(1.0).timeout
	if absf(player.global_position.y)>.2:
		push_error("Native landing failed")
		get_tree().quit(4)
		return
	print("PASS native CharacterBody3D spawn, jump and landing")
	get_tree().quit()
