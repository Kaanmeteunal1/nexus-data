# LOCKDOWN — Blackwater / PC Edition

Bu klasör Godot 4.6.3 ile çalışan yerel masaüstü oyunudur. Chromium/Electron kabuğu kullanılmaz. Web sürümü depoda ayrıca korunur.

## Oyuncu için

Windows dağıtım arşivini aç ve `LOCKDOWN.exe` dosyasını çalıştır. Oyun verileri çalıştırılabilir dosyaya gömülüdür; Godot, Node, tarayıcı veya ayrı bir sunucu programı kurman gerekmez. Ayarlar normal kullanıcı veri klasöründe saklanır. Windows 10/11 x64 hedeflenmiştir. Vulkan destekli bir ekran kartı ve güncel sürücüler önerilir; desteklenmeyen Vulkan sürücüsünde motor OpenGL uyumluluk yoluna geçebilir.

- **TESİSE GİR:** tek oyunculu serbest antrenman.
- **ODA AÇ:** oyunun içinden yerel ağ sunucusu açar. 16 oyuncuya kadar oda kapasitesi.
- **SUNUCUYA KATIL:** ev sahibinin ekranda gösterilen `IP:9277` adresini gir.
- **Serbest Alan:** oyuncular mini oyunları bağımsız deneyebilir; gardiyan ortak tur başlatabilir.
- **Jailbreak:** oyun turlarını gardiyan yönetir. Komutlar anons ve sohbet yoluyla verilir.

Aynı yerel ağdaki bağlantılar için ek sunucu yazılımı gerekmez. Windows güvenlik duvarı ev sahibinden ağ erişimi izni isteyebilir. Farklı evlerden internet üzerinden oynamak için ev sahibinin UDP 9277 portunun erişilebilir olması veya bir barındırma/relay hizmeti gerekir. Genel internet barındırması, otomatik NAT geçişi ve Steam/Steam Relay entegrasyonu bu pakete eklenmemiştir. Ev sahibi oyundan çıkarsa oda kapanır; masaüstü sürümünde sunucu devri yoktur.

## Kontroller

| Tuş | Eylem |
| --- | --- |
| WASD + fare | Hareket ve bakış |
| Space / Shift / Ctrl | Zıpla / koş / çömel |
| E | Yakındaki oyun terminali |
| M / G / Tab | Oyun seçimi / gardiyan paneli / oyuncular |
| T veya Enter | Yazılı sohbet |
| V basılı | Bas konuş; ilk kullanımda mikrofon yakalama açılır |
| C | Birinci / üçüncü şahıs kamera |
| R | Antrenmanda kontrol noktasına dön; ortak turda turu bırak |
| 1 / 2 / 3 | El salla / selam / dans |
| H / Escape / F11 | Arayüz / menü / tam ekran |

Sesli iletişim isteğe bağlıdır. Gardiyan telsizi tüm odada duyulur; mahkûmların sesi 40 metrelik mesafeye göre azalır. Ses kaydedilmez. Mikrofonu menüden kapatabilirsin. Windows gizlilik ayarları mikrofon erişimine izin vermelidir.

## İçerik ve kapsam

Blackwater, Ironworks ve Northstar tesisleri; Firar Rotası, Son Komut, Cam Köprü, Renk Kapanı, Son Ayakta ve Avlu Yarışı oyunlarını içerir. Tesisler aynı hücre ve oyun altyapısını paylaşır; çevre, ışık ve atmosferleri farklıdır. Masaüstü sürümünde gerçek karakter fiziği, çömelme kapsülü, basamak geçişi, kamera engel kontrolü ve istemci konum interpolasyonu kullanılır.

Mevcut özgün modeller, mimari ve dokular GLB varlıklarına dönüştürülmüştür. Bu varlıklar bir 3D editörde veya Godot'ta geliştirilebilir. Native sürümde Forward+ ışık yolu, SSAO/SSIL, normal haritaları, gölgeler, yansımalı su ve sis bulunur; OpenGL uyumluluk yolunda desteklenmeyen efektler kapalıdır.

Bu sürümün AA ticari oyun kalitesine ulaştığı veya geniş donanım yelpazesinde üretim kalite güvencesinden geçtiği iddia edilmez. Karakter ve çevre sanatı, içerik çeşitliliği, uzun süreli oyun testleri, genel internet dağıtımı ve son kullanıcı Windows doğrulaması için ek çalışma gerekir. Proje bu sınırlamalar saklanarak “bitmiş AA ürün” olarak sunulmaz.

## Doğrulama

- 14 yerel kural kontrolü: yetkiler, hareket sınırı, tüm mini oyunların kazanma/elenme davranışları, bağımsız cam panelleri ve map geçişi.
- İki ayrı yerel Godot işlemi: UDP/ENet bağlantısı, oyuncu listesi, hareket, yetkiler, gardiyan anonsu, ortak tur, harita geçişleri ve sentetik ses paketi.
- X11 üzerinde 12 gerçek arayüz kontrolü: düğme hit testing, fare yakalama, fiziksel tuş olayları, hareket/zıplama, parkur, komutlar ve üç tesis.
- Yerel karakter fiziği: zemine yerleşme, zıplama ve iniş.
- Forward+ / Vulkan ile gerçek görüntü yakalama; yazılımsal ekran kartı kullanılmıştır. Kare hızları kullanıcı donanımını temsil etmez.
- Dışa aktarılan Linux üretim dosyasının gömülü oyun verileriyle başlatılması ve fizik kontrolü.

Windows PE dosyası Linux üzerinde çapraz dışa aktarılır. Gerçek Windows üzerinde çalıştırma, mikrofon donanımı ve iki ayrı fiziksel bilgisayar arasında internet testi bu ortamda yapılmamıştır. Yerel ses aktarım testi sentetik PCM paketlerini doğrular; gerçek mikrofon yakalama donanım doğrulaması değildir.

## Geliştirici için

Godot 4.6.3 ve aynı sürümün resmî export template dosyaları gerekir. Kaynak GLB varlıkları pakete dahildir; projeyi Godot'ta açmak için Node gerekmez. Yalnızca GLB varlıklarını web kaynağından yeniden üretmek istersen depo kökünde `npm ci` ve `npm run desktop:assets` kullan.

```sh
godot --headless --path desktop --editor --quit
godot --headless --path desktop res://tests/rules.tscn
godot --headless --max-fps 60 --path desktop res://tests/network.tscn
godot --headless --max-fps 60 --path desktop -- --test-physics
godot --headless --path desktop --export-release "Windows Desktop" ../release/windows/LOCKDOWN.exe
```

X11 ve sistem kitaplıkları hazırsa `DISPLAY=:97 npm run desktop:test` tüm yerel kontrolleri çalıştırır. X11 olmadan arayüz girdi kontrolleri atlanır; kural, ağ ve fizik kontrolleri çalışır. Bu çalışma ortamında araçlar ve önbellekler `/workspace/.tools` ve `/workspace/.cache` altındadır; XDG yolları başlangıç talimatlarında saklanmıştır.

Orijinal Node/WebSocket sunucusuyla native istemci aynı protokolü konuşmaz. Masaüstü sürümü kendi ENet odalarını kullanır. Ağlar arası hesap, eşleştirme, relay ve kalıcı sunucu altyapısı yoktur. Başlangıç kapasitesi 16'dır; yerel test iki ayrı native işlemi doğrular ve 16 gerçek kullanıcılı internet yük testi yerine geçmez.
