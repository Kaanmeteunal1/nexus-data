import express from 'express';
import { createServer } from 'node:http';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { WebSocketServer } from 'ws';
import { GameService } from './game-service.js';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const app=express(), server=createServer(app), game=new GameService();
app.disable('x-powered-by');
app.get('/api/health',(_req,res)=>res.json({status:'ok',version:'1.0.0',rooms:game.rooms.size,players:game.players.size}));
if(process.env.NODE_ENV==='production') {
  app.use(express.static(path.join(root,'dist'),{maxAge:'1h'}));
  app.get('/{*path}',(_req,res)=>res.sendFile(path.join(root,'dist/index.html')));
} else {
  const {createServer:createVite}=await import('vite');
  const vite=await createVite({root,server:{middlewareMode:true,hmr:{server}},appType:'spa'});
  app.use(vite.middlewares);
}
const wss=new WebSocketServer({noServer:true,maxPayload:12*1024,perMessageDeflate:false});
server.on('upgrade',(req,socket,head)=>{
  if(req.url!=='/socket')return;
  // A room code is the invitation. Reject cross-origin browser connections.
  const origin=req.headers.origin;
  if(origin){try{if(new URL(origin).host!==req.headers.host){socket.destroy();return;}}catch{socket.destroy();return;}}
  wss.handleUpgrade(req,socket,head,ws=>wss.emit('connection',ws,req));
});
wss.on('connection',ws=>{
  let player=game.connect(ws),count=0,windowStart=Date.now();ws.alive=true;
  ws.on('pong',()=>{ws.alive=true;});
  ws.on('message',raw=>{
    const now=Date.now();if(now-windowStart>1000){count=0;windowStart=now;}
    if(++count>120){ws.close(1008,'Rate limit');return;}
    try{const message=JSON.parse(raw.toString());if(message&&typeof message.type==='string')player=game.handle(player,message);}catch{game.error(player,'Geçersiz mesaj.');}
  });
  ws.on('close',()=>game.disconnect(player));ws.on('error',()=>{});
});
const tick=setInterval(()=>game.tick(),100);
const heartbeat=setInterval(()=>{for(const ws of wss.clients){if(!ws.alive){ws.terminate();continue;}ws.alive=false;ws.ping();}},15000);
const port=Number(process.env.PORT)||3000;
server.listen(port,'0.0.0.0',()=>console.log(`LOCKDOWN listening on port ${port} (${process.env.NODE_ENV||'development'})`));
function shutdown(){clearInterval(tick);clearInterval(heartbeat);for(const ws of wss.clients)ws.close(1001,'Server shutting down');server.close(()=>process.exit(0));setTimeout(()=>process.exit(0),3000).unref();}
process.on('SIGTERM',shutdown);process.on('SIGINT',shutdown);
