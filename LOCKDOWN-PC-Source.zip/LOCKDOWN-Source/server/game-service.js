import { GAMES, MAPS, HUB_SPAWN, MAX_PLAYERS, COMMANDS, PLAYER_HEIGHT, parkourPlatforms, glassRows, colorPhase, lightPhase, tileColor, sweeperAngle, RACE_GATES, cleanName, validPosition } from '../shared/game.js';

const randomUUID=()=>globalThis.crypto.randomUUID();
const roomCode=()=>Array.from(globalThis.crypto.getRandomValues(new Uint8Array(3)),n=>n.toString(16).padStart(2,'0')).join('').toUpperCase();
const has=(object,key)=>typeof key==='string'&&Object.hasOwn(object,key);
export class GameService {
  constructor({ now = () => Date.now(), random = Math.random } = {}) {
    this.now = now; this.random = random; this.rooms = new Map(); this.players = new Map();
  }
  send(p, type, data = {}) { if (p?.ws?.readyState === 1 && !(p.ws.bufferedAmount>1024*1024)) p.ws.send(JSON.stringify({ type, ...data })); }
  broadcast(room, type, data = {}, except) { for (const p of room.players.values()) if (p.id !== except) this.send(p,type,data); }
  error(p,message) { this.send(p,'error',{message}); }
  connect(ws) {
    const p = { id: randomUUID().slice(0,8), token: randomUUID(), ws, room:null, name:'Mahkûm', role:'prisoner', pos:[...HUB_SPAWN], yaw:0, score:0, trial:null, status:'idle', lastMove:this.now(), lastChat:0, disconnectedAt:null, voice:false };
    this.players.set(p.id,p); this.send(p,'hello',{id:p.id}); return p;
  }
  publicPlayer(p) { return {id:p.id,name:p.name,role:p.role,pos:p.pos,yaw:p.yaw,score:p.score,status:p.status,crouch:!!p.crouch,moving:!!p.moving,connected:p.disconnectedAt===null,emote:p.emote,emoteUntil:p.emoteUntil,trial:p.trial?{game:p.trial.game,startedAt:p.trial.startedAt,checkpoint:p.trial.checkpoint,laps:p.trial.laps,gate:p.trial.gate,broken:p.trial.broken}:null}; }
  snapshot(room) {
    return { code:room.code, host:room.host, map:room.map, mode:room.mode, maxPlayers:room.maxPlayers, cellsOpen:room.cellsOpen, command:room.command, round:room.round, broken:room.broken, players:[...room.players.values()].map(p=>this.publicPlayer(p)), serverTime:this.now() };
  }
  teleport(p,pos,yaw=0) { p.pos=[...pos]; p.yaw=yaw; p.lastMove=this.now(); p.previousPos=[...pos]; this.send(p,'teleport',{pos:p.pos,yaw}); }
  enter(p,room) { this.leave(p); p.room=room.code; p.score=0;room.players.set(p.id,p); p.role=room.host===p.id?'warden':'prisoner'; p.status='idle'; p.trial=null; this.teleport(p,HUB_SPAWN); this.send(p,'joined',{id:p.id,token:p.token,room:this.snapshot(room)}); this.broadcast(room,'notice',{message:`${p.name} tesise giriş yaptı.`}); }
  leave(p) {
    const room=this.rooms.get(p.room); if (!room) return;
    room.players.delete(p.id); p.room=null; p.trial=null;
    if (!room.players.size) {this.rooms.delete(room.code);return;}
    if(room.host===p.id) {const next=[...room.players.values()].find(x=>x.disconnectedAt===null)||room.players.values().next().value;room.host=next.id;next.role='warden';this.broadcast(room,'notice',{message:`Yeni oda yöneticisi: ${next.name}`});}
    this.broadcast(room,'notice',{message:`${p.name} tesisten ayrıldı.`});
  }
  disconnect(p) { if(!this.players.has(p.id))return;p.ws=null;p.disconnectedAt=this.now();p.moving=false; }
  handle(p,msg) {
    const room=this.rooms.get(p.room);
    if(msg.type==='ping') {this.send(p,'pong',{sent:msg.sent,serverTime:this.now()});return p;}
    if(msg.type==='resume') {
      const old=[...this.players.values()].find(x=>x.token===msg.token&&x.room&&x.disconnectedAt!==null);
      if(!old) {this.error(p,'Oturum sona erdi. Odaya tekrar katılabilirsin.');return p;}
      old.ws=p.ws;old.disconnectedAt=null;old.lastMove=this.now();this.players.delete(p.id);this.send(old,'joined',{id:old.id,token:old.token,room:this.snapshot(this.rooms.get(old.room))});this.send(old,'teleport',{pos:old.pos,yaw:old.yaw});return old;
    }
    if(msg.type==='create') {
      if(this.rooms.size>=128) {this.error(p,'Sunucu dolu. Lütfen tekrar dene.');return p;}
      p.name=cleanName(msg.name);let code;do{code=roomCode();}while(this.rooms.has(code));
      const r={code,host:p.id,map:has(MAPS,msg.map)?msg.map:'blackwater',mode:['sandbox','jailbreak'].includes(msg.mode)?msg.mode:'sandbox',maxPlayers:Math.max(2,Math.min(MAX_PLAYERS,Number(msg.maxPlayers)||12)),players:new Map(),cellsOpen:true,command:null,round:null,broken:[],createdAt:this.now()};
      this.rooms.set(code,r);this.enter(p,r);return p;
    }
    if(msg.type==='join') {
      const r=this.rooms.get(String(msg.code||'').toUpperCase().trim());
      if(!r) {this.error(p,'Bu kodla bir oda bulunamadı. Kodu kontrol et.');return p;}
      if(p.room===r.code){this.send(p,'joined',{id:p.id,token:p.token,room:this.snapshot(r)});return p;}
      if(r.players.size>=r.maxPlayers) {this.error(p,'Bu oda dolu.');return p;}
      p.name=cleanName(msg.name);this.enter(p,r);return p;
    }
    if(msg.type==='leave') {this.leave(p);this.send(p,'left');return p;}
    if(!room)return p;
    const isHost=room.host===p.id, isWarden=p.role==='warden'||p.role==='guard';
    if(msg.type==='move' && validPosition(msg.pos) && Number.isFinite(msg.yaw)) {
      const dt=Math.min(1,Math.max(0,(this.now()-p.lastMove)/1000));
      const horizontal=Math.hypot(msg.pos[0]-p.pos[0],msg.pos[2]-p.pos[2]);
      const vertical=Math.abs(msg.pos[1]-p.pos[1]);
      if(horizontal>12.5*dt+0.65||vertical>30*dt+0.8) {this.send(p,'teleport',{pos:p.pos,yaw:p.yaw});return p;}
      if(p.trial&&this.now()<p.trial.startedAt) return p;
      p.previousPos=[...p.pos];p.pos=msg.pos;p.yaw=msg.yaw;p.crouch=!!msg.crouch;p.moving=horizontal>0.015;p.lastMove=this.now();
    } else if(msg.type==='chat') {
      if(this.now()-p.lastChat<650)return p; p.lastChat=this.now();
      const text=String(msg.text||'').replace(/[\u0000-\u001f]/g,'').trim().slice(0,180);if(text)this.broadcast(room,'chat',{id:p.id,name:p.name,role:p.role,text});
    } else if(msg.type==='command' && isWarden) {
      const text=has(COMMANDS,msg.command)?COMMANDS[msg.command]:String(msg.text||'').trim().slice(0,100);if(text){room.command={text,by:p.name,at:this.now()};this.broadcast(room,'command',room.command);}
    } else if(msg.type==='cells' && isWarden) {room.cellsOpen=!!msg.open;this.broadcast(room,'notice',{message:room.cellsOpen?'Hücre kapıları açıldı.':'Hücre kapıları kilitlendi.'});}
    else if(msg.type==='role' && isHost) {const target=room.players.get(msg.id);if(target&&target.id!==room.host&&['guard','prisoner'].includes(msg.role)){target.role=msg.role;this.broadcast(room,'notice',{message:`${target.name}: ${msg.role==='guard'?'gardiyan':'mahkûm'}`});}}
    else if(msg.type==='kick' && isHost && msg.id!==p.id) {const target=room.players.get(msg.id);if(target){this.send(target,'kicked');this.leave(target);}}
    else if(msg.type==='startGame' && isWarden && has(GAMES,msg.game)) {
      if(room.round?.state==='active')return p;
      room.broken=[];const startedAt=this.now()+3500;
      room.round={game:msg.game,state:'active',startedAt,results:[]};
      const safe=glassRows().map(()=>this.random()<0.5?0:1);
      for(const q of room.players.values())if(q.disconnectedAt===null)this.begin(q,msg.game,startedAt,safe);
      this.broadcast(room,'notice',{message:`${GAMES[msg.game].name} — tur başlıyor.`});
    } else if(msg.type==='practice' && has(GAMES,msg.game)) {
      if(room.round?.state==='active'){this.error(p,'Devam eden turun bitmesini bekle.');return p;}
      if(room.mode==='jailbreak'&&!isWarden){this.error(p,'Jailbreak modunda oyunu gardiyan başlatır.');return p;}
      this.begin(p,msg.game,this.now()+2500,glassRows().map(()=>this.random()<0.5?0:1));
    } else if(msg.type==='hub') {
      if(p.trial&&room.round?.state==='active')this.finish(p,false,'Turdan ayrıldın.');p.trial=null;p.status='idle';this.teleport(p,HUB_SPAWN);this.send(p,'hub');
    } else if(msg.type==='respawn') {
      if(p.trial){if(room.round?.state==='active')this.finish(p,false,'Turu bıraktın.');else this.resetTrial(p,'Kontrol noktasına döndün.');}
      else this.teleport(p,HUB_SPAWN);
    } else if(msg.type==='endRound'&&isWarden) {
      for(const q of room.players.values()){q.trial=null;q.status='idle';this.teleport(q,HUB_SPAWN);this.send(q,'hub');}room.round=null;room.broken=[];
    } else if(msg.type==='setMap'&&isHost&&has(MAPS,msg.map)) {
      room.map=msg.map;room.round=null;room.broken=[];room.command=null;room.cellsOpen=true;
      for(const q of room.players.values()){q.trial=null;q.status='idle';this.teleport(q,HUB_SPAWN);this.send(q,'mapChanged',{map:msg.map});}
    } else if(msg.type==='emote'&&['wave','salute','dance'].includes(msg.emote)) {p.emote=msg.emote;p.emoteUntil=this.now()+4000;}
    else if(msg.type==='voice'&&typeof msg.audio==='string'&&msg.audio.length<=6000) {
      if(this.now()-(p.lastVoice||0)<50)return p;p.lastVoice=this.now();
      this.broadcast(room,'voice',{id:p.id,audio:msg.audio,radio:isWarden},p.id);
    }
    return p;
  }
  begin(p,game,startedAt,safe) {p.trial={game,startedAt,checkpoint:0,laps:0,gate:0,safe,broken:[],attempts:0,redAnchor:null};p.status='playing';this.teleport(p,GAMES[game].spawn);this.send(p,'trial',{game,startedAt});}
  resetTrial(p,reason) {
    const room=this.rooms.get(p.room);if(!p.trial||!room)return;
    if(room.round?.state==='active'){this.finish(p,false,reason);return;}
    p.trial.attempts++;p.trial.redAnchor=null;
    if(p.trial.game==='parkour'&&p.trial.checkpoint){const q=parkourPlatforms(room.map)[4];this.teleport(p,[-110+q.x,q.y+PLAYER_HEIGHT,q.z]);}
    else {this.teleport(p,GAMES[p.trial.game].spawn);if(['colors','sweeper'].includes(p.trial.game))p.trial.startedAt=this.now()+2000;}
    this.send(p,'notice',{message:reason});
  }
  finish(p,success,reason) {
    if(!p.trial)return;const t=p.trial;const elapsed=Math.max(0,(this.now()-t.startedAt)/1000);const room=this.rooms.get(p.room);
    p.trial=null;p.status=success?'finished':'out';if(success)p.score+=100;
    const result={id:p.id,name:p.name,game:t.game,success,elapsed:Math.round(elapsed*100)/100,attempts:t.attempts,reason,score:success?100:0};
    if(room?.round?.state==='active')room.round.results.push(result);
    this.send(p,'result',result);if(room)this.broadcast(room,'notice',{message:`${p.name} ${success?'tamamladı':'elendi'} · ${GAMES[t.game].name}`});
  }
  tick() {
    const now=this.now();
    for(const p of this.players.values()) {
      if(p.disconnectedAt!==null&&now-p.disconnectedAt>30000){this.leave(p);this.players.delete(p.id);continue;}
      if(!p.trial||p.disconnectedAt!==null)continue;
      const t=p.trial, elapsed=(now-t.startedAt)/1000;if(elapsed<0)continue;
      const g=GAMES[t.game],room=this.rooms.get(p.room);if(!room)continue;
      if(elapsed>g.duration){this.finish(p,['colors','sweeper'].includes(t.game),['colors','sweeper'].includes(t.game)?'Sürenin sonuna kadar ayakta kaldın.':'Süre doldu.');continue;}
      if(p.pos[1]<-5){this.resetTrial(p,'Düştün. Yeniden dene.');continue;}
      const x=p.pos[0]-g.origin[0],z=p.pos[2]-g.origin[1],feet=p.pos[1]-PLAYER_HEIGHT;
      if(t.game==='parkour') {
        const platforms=parkourPlatforms(room.map),cp=platforms[4],end=platforms.at(-1);
        if(!t.checkpoint&&Math.abs(x-cp.x)<cp.w/2&&Math.abs(z-cp.z)<cp.d/2&&Math.abs(feet-cp.y)<0.25){t.checkpoint=1;this.send(p,'checkpoint',{message:'Kontrol noktası kaydedildi.'});}
        if(t.checkpoint&&Math.abs(x-end.x)<end.w/2&&Math.abs(z-end.z)<2&&feet>=end.y-.2)this.finish(p,true,'Firar rotasını tamamladın.');
      } else if(t.game==='redlight') {
        const phase=lightPhase(elapsed);
        if(phase.red&&!phase.grace){if(!t.redAnchor)t.redAnchor=[...p.pos];else if(Math.hypot(p.pos[0]-t.redAnchor[0],p.pos[2]-t.redAnchor[2])>0.24){this.resetTrial(p,'Kırmızı ışıkta hareket ettin.');continue;}}else t.redAnchor=null;
        if(z<-26)this.finish(p,true,'Son komutu geçtin.');
      } else if(t.game==='glass') {
        for(const [i,row] of glassRows().entries())if(Math.abs(z-row.z)<row.d/2&&feet<0.35&&feet>-.5) {
          const side=x<0?0:1;
          if(Math.abs(x-row.x[side])<row.w/2&&side!==t.safe[i]){const key=`${i}:${side}`;if(!t.broken.includes(key))t.broken.push(key);if(room.round?.state==='active'&&!room.broken.includes(key))room.broken.push(key);this.send(p,'glassBreak',{row:i,side});this.resetTrial(p,'Cam kırıldı. Güvenli yolu hatırla.');break;}
        }
        if(p.trial&&z<-25.5&&feet>-.2)this.finish(p,true,'Köprünün öteki tarafındasın.');
      } else if(t.game==='colors') {
        const phase=colorPhase(elapsed),col=Math.floor((x+12.5)/5),row=Math.floor((z+12.5)/5);
        if(phase.dropping&&((col<0||col>4||row<0||row>4)||tileColor(col,row)!==phase.target)&&feet<0.4)this.resetTrial(p,'Yanlış renk. Zemin düştü.');
      } else if(t.game==='sweeper') {
        const angle=sweeperAngle(elapsed),cross=Math.abs(x*Math.cos(angle)-z*Math.sin(angle)),along=Math.abs(x*Math.sin(angle)+z*Math.cos(angle));
        if(cross<0.6&&along<11.5&&Math.hypot(x,z)>1.3&&feet<0.9)this.resetTrial(p,'Dönen kola yakalandın.');
      } else if(t.game==='race') {
        const gate=RACE_GATES[t.gate];if(Math.hypot(x-gate[0],z-gate[1])<5){t.gate=(t.gate+1)%4;if(t.gate===0)t.laps++;this.send(p,'checkpoint',{message:`${t.laps?`${t.laps}/2 tur`:'Kontrol noktası'} · sıradaki kapıya ilerle`});if(t.laps>=2)this.finish(p,true,'İki turu tamamladın.');}
      }
    }
    for(const room of this.rooms.values()) {
      if(room.round?.state==='active'&&![...room.players.values()].some(p=>p.trial&&p.disconnectedAt===null)){room.round.state='finished';this.broadcast(room,'roundEnded',{results:room.round.results});}
      this.broadcast(room,'state',{room:this.snapshot(room)});
    }
  }
}
