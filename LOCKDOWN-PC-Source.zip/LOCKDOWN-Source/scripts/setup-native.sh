#!/usr/bin/env bash
set -euo pipefail
cd /workspace/nexus-data
export XDG_CONFIG_HOME=/workspace/.cache/godot-config
export XDG_CACHE_HOME=/workspace/.cache
export XDG_DATA_HOME=/workspace/.cache/godot-data
mkdir -p /workspace/.tools/godot "$XDG_CONFIG_HOME" "$XDG_DATA_HOME"
task_godot_release=https://github.com/godotengine/godot-builds/releases/download/4.6.3-stable
task_godot_cache=/workspace/.tools/godot
if [ ! -s "$task_godot_cache/SHA512-SUMS.txt" ]; then
  curl -L --fail --retry 2 "$task_godot_release/SHA512-SUMS.txt" -o "$task_godot_cache/SHA512-SUMS.txt"
fi
if [ ! -s "$task_godot_cache/templates.tpz" ]; then
  curl -L --fail --retry 2 "$task_godot_release/Godot_v4.6.3-stable_export_templates.tpz" -o "$task_godot_cache/templates.tpz"
fi
python3 - <<'PY'
from pathlib import Path
import hashlib, zipfile
cache=Path('/workspace/.tools/godot')
manifest={line.split()[-1].lstrip('*'):line.split()[0] for line in (cache/'SHA512-SUMS.txt').read_text().splitlines() if len(line.split())==2}
with (cache/'templates.tpz').open('rb') as f:
    actual=hashlib.file_digest(f,'sha512').hexdigest()
assert actual==manifest['Godot_v4.6.3-stable_export_templates.tpz'], 'Godot archive integrity verification failed'
names=['windows_release_x86_64.exe','windows_debug_x86_64.exe','linux_release.x86_64','version.txt']
with zipfile.ZipFile(cache/'templates.tpz') as archive:
    for name in names:
        contents=archive.read('templates/'+name)
        for target in [cache/'templates'/name,Path('/workspace/.cache/godot-data/godot/export_templates/4.6.3.stable')/name]:
            target.parent.mkdir(parents=True,exist_ok=True)
            if not target.exists() or hashlib.sha256(target.read_bytes()).digest()!=hashlib.sha256(contents).digest():
                temporary=target.with_name(target.name+'.verified-tmp')
                temporary.write_bytes(contents)
                temporary.replace(target)
print('PASS Godot 4.6.3 official archive and export templates')
PY
task_godot_system=$(command -v godot || true)
task_godot_version=""
if [ -n "$task_godot_system" ]; then
  task_godot_version=$("$task_godot_system" --version 2>/dev/null)
fi
if [[ "$task_godot_version" == 4.6.3.* ]]; then
  export GODOT_BIN="$task_godot_system"
else
  if [ ! -s "$task_godot_cache/Godot_v4.6.3-stable_linux.x86_64.zip" ]; then
    curl -L --fail --retry 2 "$task_godot_release/Godot_v4.6.3-stable_linux.x86_64.zip" -o "$task_godot_cache/Godot_v4.6.3-stable_linux.x86_64.zip"
  fi
  python3 - <<'PY'
from pathlib import Path
import hashlib, zipfile
cache=Path('/workspace/.tools/godot')
name='Godot_v4.6.3-stable_linux.x86_64.zip'
expected=next(line.split()[0] for line in (cache/'SHA512-SUMS.txt').read_text().splitlines() if line.endswith(name))
assert hashlib.file_digest((cache/name).open('rb'),'sha512').hexdigest()==expected
with zipfile.ZipFile(cache/name) as z: z.extract('Godot_v4.6.3-stable_linux.x86_64',cache)
(cache/'Godot_v4.6.3-stable_linux.x86_64').chmod(0o755)
PY
  export GODOT_BIN="$task_godot_cache/Godot_v4.6.3-stable_linux.x86_64"
fi
"$GODOT_BIN" --headless --path desktop --editor --quit
"$GODOT_BIN" --headless --max-fps 60 --path desktop res://tests/rules.tscn
