"""Package the already built, tested game without credentials or dependency caches."""
from pathlib import Path
import zipfile
import hashlib

root = Path(__file__).resolve().parent.parent
release = root / 'release'
release.mkdir(exist_ok=True)
play = '''LOCKDOWN — BLACKWATER

TEK OYUNCULU / KURULUMSUZ
LOCKDOWN.html dosyasını güncel bir masaüstü tarayıcıda aç.
Ek dosya indirme veya program kurulumu gerekmez.
WASD: hareket · Fare: bakış · Space: zıpla · Shift: koş
M: oyunlar · G: gardiyan paneli · Escape: menü

ÇOK OYUNCULU
Çok oyunculu sürümün sunucu ve istemci kaynakları kaynak/ klasöründedir.
İnternette erişilebilir bir sunucuya henüz yayımlanmamıştır.
Tek HTML dosyası internet üzerinden başka oyunculara bağlanmaz.

İÇERİK
3 tesis atmosferi · 6 mini oyun · serbest alan ve Jailbreak modları
Sunucu sürümünde özel odalar, komutlar, roller, yazılı ve sesli sohbet.

TEST NOTU
12 oyun kuralı testi, iki gerçek Chromium istemcisi ve 16 WebSocket
istemcisiyle kontrol edildi. Test raporları test-raporlari/ klasöründedir.
Yönetilen test tarayıcısı file:// adreslerini engellediği için HTML
dosyasının birebir içeriği, ek ağ istekleri engellenerek test edildi.
Doğrudan dosya açma ve farklı kullanıcı donanımları bu ortamda test edilmedi.

Tüm kontroller, kaynak yapısı ve kapsam için kaynak/README.md dosyasına bak.
'''
(release / 'OYNA.txt').write_text(play, encoding='utf-8')
archive = release / 'LOCKDOWN-Blackwater.zip'
folders = ['src', 'server', 'shared', 'public', 'dist', 'tests', 'scripts', 'licenses']
files = ['package.json', 'package-lock.json', 'index.html', '.gitignore', '.dockerignore', 'Dockerfile', 'AGENTS.md', 'README.md', 'LICENSE', 'THIRD_PARTY_NOTICES.md']
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=8) as z:
    z.write(release / 'LOCKDOWN.html', 'LOCKDOWN/LOCKDOWN.html')
    z.write(release / 'OYNA.txt', 'LOCKDOWN/OYNA.txt')
    for name in ['LICENSE', 'THIRD_PARTY_NOTICES.md']:
        z.write(root / name, 'LOCKDOWN/' + name)
    for p in (root / 'licenses').iterdir():
        z.write(p, 'LOCKDOWN/licenses/' + p.name)
    for name in files:
        z.write(root / name, 'LOCKDOWN/kaynak/' + name)
    for folder in folders:
        for p in sorted((root / folder).rglob('*')):
            if p.is_file():
                z.write(p, 'LOCKDOWN/kaynak/' + str(p.relative_to(root)))
    for name in ['browser-results.json', 'network-results.json', 'unit-results.xml']:
        p = root / 'artifacts' / name
        if not p.exists():
            raise RuntimeError(f'Missing verification artifact: {name}')
        z.write(p, 'LOCKDOWN/test-raporlari/' + name)
    preview = root / 'artifacts/home-final.png'
    if preview.exists():
        z.write(preview, 'LOCKDOWN/ONIZLEME.png')
for p in [release / 'LOCKDOWN.html', archive]:
    digest = hashlib.sha256(p.read_bytes()).hexdigest()
    print(f'{p.name}: {p.stat().st_size:,} bytes · SHA256 {digest}')
