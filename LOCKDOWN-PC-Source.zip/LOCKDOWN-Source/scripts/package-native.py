from pathlib import Path
import hashlib
import json
import struct
import zipfile

root=Path(__file__).resolve().parent.parent
release=root/'release'
reports=['native-rules.json','native-network.json','native-network-client.json','native-interface.json']
for name in reports:
    data=json.loads((root/'artifacts'/name).read_text())
    if data.get('failures'):
        raise RuntimeError(f'Failed checks in {name}')
exe=release/'windows/LOCKDOWN.exe'
binary=exe.read_bytes()
assert binary[:2]==b'MZ'
pe=struct.unpack_from('<I',binary,0x3c)[0]
assert binary[pe:pe+4]==b'PE\0\0'
assert struct.unpack_from('<H',binary,pe+4)[0]==0x8664
assert binary[-4:]==b'GDPC'
pack_size=struct.unpack_from('<Q',binary,len(binary)-12)[0]
assert 1000000<pack_size<len(binary)
pack=binary[len(binary)-12-pack_size:len(binary)-12]
assert pack[:4]==b'GDPC'
readme='''LOCKDOWN — BLACKWATER / PC EDITION

OYNA
ZIP içeriğini bir klasöre çıkar ve LOCKDOWN.exe dosyasını aç.
Godot, Node, tarayıcı veya ayrı bir sunucu programı kurman gerekmez.
Oyun verileri EXE dosyasına gömülüdür.
Windows 10/11 x64 ve güncel ekran kartı sürücüsü hedeflenmiştir.

TEK OYUNCULU: TESİSE GİR düğmesiyle serbest alana gir.
ARKADAŞLARLA: Bir oyuncu ODA AÇ seçer. Diğerleri SUNUCUYA KATIL
alanına ev sahibinin ekranda gösterilen IP:9277 adresini girer.
Aynı yerel ağ için ek sunucu yazılımı gerekmez. Farklı ağlardan
internet bağlantısı, erişilebilir UDP 9277 portu veya barındırma/relay
hizmeti gerektirir. Genel internet sunucusu bu pakete dahil değildir.
Ev sahibi oyundan çıkarsa oda kapanır.

WASD + fare: hareket/bakış · Space: zıpla · Shift: koş · Ctrl: çömel
E: terminal · M: oyunlar · G: gardiyan paneli · Tab: oyuncular
T: sohbet · V: bas konuş · C: kamera · R: yeniden doğ
1/2/3: ifadeler · H: arayüz · Escape: menü · F11: tam ekran

KAPSAM
3 tesis atmosferi, 6 mini oyun, serbest ve Jailbreak modları,
gardiyan/mahkûm rolleri, hücre kapıları, ortak turlar, sohbet ve bas-konuş.

DOĞRULAMA
14 kural, 12 gerçek arayüz/girdi kontrolü, iki ayrı native süreç arasında
ENet bağlantısı, hareket, roller, komutlar, turlar, harita geçişi ve
sentetik ses paketi kontrol edildi. Aynı proje paketinin Linux üretim
dosyası başlatılıp fizik ve Forward+ görüntüsü doğrulandı.

Bu Windows EXE, Linux'ta çapraz dışa aktarılmıştır. Gerçek Windows
çalıştırma, farklı kullanıcı donanımları, gerçek mikrofon ve internet
bağlantısı bu ortamda test edilmemiştir. EXE dijital olarak imzalanmamıştır.
AA ticari oyun seviyesine ulaştığı veya üretim kalite güvencesini
tamamladığı iddia edilmez. Ayrıntılar PC-SURUMU.md dosyasındadır.
'''
(release/'windows/OYNA.txt').write_text(readme,encoding='utf-8')
verification={
    'version':'1.1.0','engine':'Godot 4.6.3','target':'Windows x86-64',
    'executable_sha256':hashlib.sha256(binary).hexdigest(),
    'embedded_pack_sha256':hashlib.sha256(pack).hexdigest(),
    'embedded_pack_bytes':pack_size,
    'windows_runtime_tested':False,'digitally_signed':False,
    'linux_equivalent_smoke_test':'native CharacterBody3D spawn, jump, landing; Forward+ screenshot',
    'reports':reports,
}
(release/'windows/VERIFICATION.json').write_text(json.dumps(verification,indent=2),encoding='utf-8')
windows=release/'LOCKDOWN-PC-Windows.zip'
with zipfile.ZipFile(windows,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
    for name in ['LOCKDOWN.exe','OYNA.txt','VERIFICATION.json']:
        z.write(release/'windows'/name,'LOCKDOWN/'+name)
    z.write(root/'desktop/README.md','LOCKDOWN/PC-SURUMU.md')
    z.write(root/'LICENSE','LOCKDOWN/LICENSE')
    z.write(root/'THIRD_PARTY_NOTICES.md','LOCKDOWN/THIRD_PARTY_NOTICES.md')
    for p in (root/'licenses').iterdir():
        if p.is_file(): z.write(p,'LOCKDOWN/licenses/'+p.name)
    for name in reports:
        z.write(root/'artifacts'/name,'LOCKDOWN/test-raporlari/'+name)
    for name in ['native-forward.png','native-release-parkour.png']:
        p=root/'artifacts'/name
        if p.exists(): z.write(p,'LOCKDOWN/goruntuler/'+name)

source=release/'LOCKDOWN-PC-Source.zip'
with zipfile.ZipFile(source,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
    for directory in ['desktop','src','server','shared','public','scripts','tests','licenses']:
        for p in sorted((root/directory).rglob('*')):
            relative=p.relative_to(root)
            if not p.is_file() or '.godot' in relative.parts or '__pycache__' in relative.parts: continue
            z.write(p,'LOCKDOWN-Source/'+str(relative))
    for name in ['package.json','package-lock.json','README.md','AGENTS.md','LICENSE','THIRD_PARTY_NOTICES.md','Dockerfile','index.html','.gitignore','.dockerignore']:
        z.write(root/name,'LOCKDOWN-Source/'+name)
for p in [windows,source]:
    with zipfile.ZipFile(p) as z: assert z.testzip() is None
    print(p.name, f'{p.stat().st_size/1024/1024:.2f} MiB', 'SHA256',hashlib.sha256(p.read_bytes()).hexdigest())
