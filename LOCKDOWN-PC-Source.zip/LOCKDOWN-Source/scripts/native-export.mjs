import fs from 'node:fs/promises';
import path from 'node:path';
import {spawn} from 'node:child_process';

const godot=process.env.GODOT_BIN||'godot';
const template=path.resolve(process.env.WINDOWS_TEMPLATE||'/workspace/.tools/godot/templates/windows_release_x86_64.exe');
const branded=path.resolve('/workspace/.tools/godot/lockdown-windows-template.exe');
const env={...process.env,XDG_CONFIG_HOME:process.env.XDG_CONFIG_HOME||'/workspace/.cache/godot-config',XDG_CACHE_HOME:process.env.XDG_CACHE_HOME||'/workspace/.cache',XDG_DATA_HOME:process.env.XDG_DATA_HOME||'/workspace/.cache/godot-data'};
async function run(command,args){await new Promise((resolve,reject)=>{const child=spawn(command,args,{env,stdio:'inherit'});child.on('error',reject);child.on('exit',code=>code===0?resolve():reject(new Error(`Command exited with ${code}`)));});}
await run(process.execPath,['scripts/brand-native.mjs',template,branded]);
const profile='desktop/export_presets.cfg',original=await fs.readFile(profile,'utf8');
await fs.mkdir('release/windows',{recursive:true});await fs.mkdir('release/linux',{recursive:true});
try{
  await fs.writeFile(profile,original.replace('custom_template/release=""',()=>`custom_template/release=${JSON.stringify(branded)}`));
  await run(godot,['--headless','--path','desktop','--export-release','Windows Desktop','../release/windows/LOCKDOWN.exe']);
}finally{await fs.writeFile(profile,original);}
await run(godot,['--headless','--path','desktop','--export-release','Linux Desktop','../release/linux/LOCKDOWN.x86_64']);
