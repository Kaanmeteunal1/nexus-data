import fs from 'node:fs/promises';
import path from 'node:path';
import * as THREE from 'three';
import { createCanvas, GlobalFonts, ImageData, Canvas, loadImage } from '@napi-rs/canvas';
import { GLTFExporter } from 'three/addons/exporters/GLTFExporter.js';
import { World } from '../src/world.js';
import { createCharacter } from '../src/character.js';
import { MAPS,GAMES,COLOR_PALETTE,COMMANDS,RACE_GATES,parkourPlatforms } from '../shared/game.js';

const root=path.resolve('desktop/assets');
await fs.mkdir(root,{recursive:true});
GlobalFonts.registerFromPath(path.join(root,'display.ttf'),'Barlow Condensed');
GlobalFonts.registerFromPath(path.join(root,'body.ttf'),'DM Sans');
globalThis.ImageData=ImageData;
globalThis.HTMLCanvasElement=Canvas;
function canvas(){const c=createCanvas(256,256);Object.defineProperty(c,'data',{value:undefined});c.toBlob=(cb,type)=>cb(new Blob([c.toBuffer(type||'image/png')],{type:type||'image/png'}));return c;}
globalThis.document={createElement:canvas,createElementNS:canvas};
globalThis.FileReader=class {
  async readAsArrayBuffer(blob){this.result=await blob.arrayBuffer();this.onloadend?.();}
  async readAsDataURL(blob){this.result=`data:${blob.type};base64,${Buffer.from(await blob.arrayBuffer()).toString('base64')}`;this.onloadend?.();}
};
async function exportGlb(object,name,animations=[]){
  const bytes=await new GLTFExporter().parseAsync(object,{binary:true,onlyVisible:false,animations,maxTextureSize:1024});
  const view=new DataView(bytes),jsonSize=view.getUint32(12,true),json=JSON.parse(new TextDecoder().decode(new Uint8Array(bytes,20,jsonSize)));
  for(const img of json.images||[]){const span=json.bufferViews[img.bufferView],image=await loadImage(Buffer.from(bytes,28+jsonSize+(span.byteOffset||0),span.byteLength));const probe=createCanvas(1,1);probe.getContext('2d').drawImage(image,0,0,1,1);if(probe.getContext('2d').getImageData(0,0,1,1).data[3]===0)throw new Error(`Empty exported texture in ${name}`);}
  await fs.writeFile(path.join(root,name),Buffer.from(bytes));console.log(name,Math.round(bytes.byteLength/1024)+' KiB');
}
await fs.writeFile(path.join(root,'catalog.json'),JSON.stringify({maps:MAPS,games:GAMES,colors:COLOR_PALETTE,commands:COMMANDS,race_gates:RACE_GATES,platforms:Object.fromEntries(Object.keys(MAPS).map(id=>[id,parkourPlatforms(id)]))},null,2));
for(const map of Object.keys(MAPS)){
  const scene=new THREE.Scene(),world=new World(scene,map);world.group.name='Facility';
  for(const key of ['concrete','ground','dark','steel','yellow','white','black','glow','cyan','rust','crateMat','red','grass'])if(world[key])world[key].name=key;
  world.gates.forEach((g,i)=>g.mesh.name=`Gate_${i}`);
  world.tiles.forEach((tile,i)=>{tile.mesh.name=`ColorTile_${i}`;tile.label.name=`ColorLabel_${i}`;});
  world.glass.forEach((glass,i)=>glass.mesh.name=`Glass_${i}`);
  world.sweeper.name='SweeperArm';
  world.signalLights.forEach((light,i)=>light.name=`Signal_${i}`);
  world.arenas.forEach(arena=>arena.group.name=`Arena_${arena.id}`);
  const remove=[];
  world.group.traverse(obj=>{if(obj.isPoints||obj.material?.isShaderMaterial)remove.push(obj);});
  remove.forEach(obj=>obj.parent.remove(obj));
  await exportGlb(world.group,`facility-${map}.glb`);
  await fs.writeFile(path.join(root,`collision-${map}.json`),JSON.stringify({walls:world.colliders.map(c=>({x:c.x,z:c.z,w:c.w,d:c.d,minY:c.minY,maxY:c.maxY,enabled:c.enabled})),floors:world.surfaces,terminals:world.terminals.map(t=>({game:t.game,pos:t.pos.toArray()})),lamps:world.lamps.map(p=>p.toArray())}));
  world.dispose();
}
for(const role of ['prisoner','guard','warden']){
  const character=createCharacter(role);character.name='Character';const {arms,legs,body}=character.userData;
  body.name='Body';arms.forEach(({arm,elbow,side})=>{arm.name=`Arm_${side===1?'R':'L'}`;elbow.name=`Elbow_${side===1?'R':'L'}`;});legs.forEach(({leg,knee,side})=>{leg.name=`Leg_${side===1?'R':'L'}`;knee.name=`Knee_${side===1?'R':'L'}`;});
  character.userData={};
  await exportGlb(character,`character-${role}.glb`);
}
