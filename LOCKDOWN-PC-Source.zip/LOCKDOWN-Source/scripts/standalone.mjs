import fs from 'node:fs/promises';
import path from 'node:path';

const dist=path.resolve('dist');
let html=await fs.readFile(path.join(dist,'index.html'),'utf8');
const script=html.match(/<script[^>]*src="([^"]+)"[^>]*><\/script>/);
const style=html.match(/<link[^>]*rel="stylesheet"[^>]*href="([^"]+)"[^>]*>/);
if(!script||!style)throw new Error('Expected a single JavaScript and CSS build.');
const js=await fs.readFile(path.join(dist,script[1].replace(/^\//,'')),'utf8');
let css=await fs.readFile(path.join(dist,style[1].replace(/^\//,'')),'utf8');
const fonts=[...css.matchAll(/url\(([^)]+)\)/g)];
for(const match of fonts){const url=match[1].replace(/['"]/g,'');if(url.startsWith('data:'))continue;const file=path.join(dist,url.replace(/^\//,''));const buffer=await fs.readFile(file);const mime=url.endsWith('woff2')?'font/woff2':'font/woff';css=css.replace(match[0],`url(data:${mime};base64,${buffer.toString('base64')})`);}
// Function replacements preserve literal $& / $` / $' sequences in the bundle.
html=html.replace(script[0],()=>`<script type="module">${js.replace(/<\/script/gi,'<\\/script')}</script>`).replace(style[0],()=>`<style>${css}</style>`);
const favicon=await fs.readFile('public/favicon.svg');
html=html.replace('href="/favicon.svg"',`href="data:image/svg+xml;base64,${favicon.toString('base64')}"`);
await fs.mkdir('release',{recursive:true});
await fs.writeFile('release/LOCKDOWN.html',html);
console.log(`Standalone offline game: release/LOCKDOWN.html (${Math.round(Buffer.byteLength(html)/1024)} KiB)`);
