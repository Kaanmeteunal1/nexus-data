import {spawn} from 'node:child_process';
import fs from 'node:fs/promises';
const godot=process.env.GODOT_BIN||'godot';
const env={...process.env,XDG_CONFIG_HOME:process.env.XDG_CONFIG_HOME||'/workspace/.cache/godot-config',XDG_CACHE_HOME:process.env.XDG_CACHE_HOME||'/workspace/.cache',XDG_DATA_HOME:process.env.XDG_DATA_HOME||'/workspace/.cache/godot-test-data'};
async function run(args){await new Promise((resolve,reject)=>{const p=spawn(godot,args,{env,stdio:'inherit'});p.on('error',reject);p.on('exit',code=>code===0?resolve():reject(new Error(`Godot exited with ${code}`)));});}
await fs.mkdir('artifacts',{recursive:true});
await run(['--headless','--path','desktop','--editor','--quit']);
await run(['--headless','--max-fps','60','--path','desktop','res://tests/rules.tscn','--',`--report=${process.cwd()}/artifacts/native-rules.json`]);
await run(['--headless','--max-fps','60','--path','desktop','res://tests/network.tscn','--',`--report=${process.cwd()}/artifacts/native-network.json`]);
await run(['--headless','--max-fps','60','--path','desktop','--','--test-physics']);
if(process.env.DISPLAY){await run(['--path','desktop','--audio-driver','Dummy','--rendering-method','gl_compatibility','--max-fps','60','res://tests/interface.tscn','--',`--report=${process.cwd()}/artifacts/native-interface.json`]);}
else console.log('UI input checks require an X11 display; core rules, network and physics checks completed.');
