import fs from 'node:fs/promises';
import {createHash} from 'node:crypto';
import * as PE from 'pe-library';
import * as ResEdit from 'resedit';
import {createCanvas,loadImage} from '@napi-rs/canvas';

const sourceFile=process.argv[2]||'/workspace/.tools/godot/templates/windows_release_x86_64.exe';
const targetFile=process.argv[3]||'/workspace/.tools/godot/lockdown-windows-template.exe';
const input=await fs.readFile(sourceFile);
if(input.subarray(-4).toString()==='GDPC')throw new Error('Brand the official export template before adding a game pack.');
const hash=data=>createHash('sha256').update(data).digest('hex');
const source=await loadImage(await fs.readFile('desktop/icon.svg'));
const sizes=[256,128,64,48,32,16],images=[];
for(const size of sizes){const c=createCanvas(size,size);c.getContext('2d').drawImage(source,0,0,size,size);images.push(c.toBuffer('image/png'));}
const header=Buffer.alloc(6+sizes.length*16);header.writeUInt16LE(1,2);header.writeUInt16LE(sizes.length,4);let offset=header.length;
for(let i=0;i<sizes.length;i++){const start=6+i*16;header[start]=sizes[i]===256?0:sizes[i];header[start+1]=header[start];header.writeUInt16LE(1,start+4);header.writeUInt16LE(32,start+6);header.writeUInt32LE(images[i].length,start+8);header.writeUInt32LE(offset,start+12);offset+=images[i].length;}
const iconBytes=Buffer.concat([header,...images]);await fs.writeFile('desktop/icon.ico',iconBytes);
const exe=PE.NtExecutable.from(input),res=PE.NtExecutableResource.from(exe);
const codeSection=exe.getAllSections().find(s=>s.info.name==='.text');
const originalCode=hash(Buffer.from(codeSection.data));
const icon=ResEdit.Data.IconFile.from(iconBytes);
ResEdit.Resource.IconGroupEntry.replaceIconsForResource(res.entries,1,1033,icon.icons.map(item=>item.data));
const version=ResEdit.Resource.VersionInfo.createEmpty();
version.setFileVersion(1,1,0,0,1033);version.setProductVersion(1,1,0,0,1033);
version.setStringValues({lang:1033,codepage:1200},{CompanyName:'LOCKDOWN contributors',FileDescription:'LOCKDOWN — Blackwater PC Edition',ProductName:'LOCKDOWN — Blackwater',FileVersion:'1.1.0',ProductVersion:'1.1.0',OriginalFilename:'LOCKDOWN.exe'});
version.outputToResourceEntries(res.entries);res.outputResource(exe);
const output=Buffer.from(exe.generate());
const outputExe=PE.NtExecutable.from(output);
if(hash(Buffer.from(outputExe.getAllSections().find(s=>s.info.name==='.text').data))!==originalCode)throw new Error('Resource editing changed engine code');
const check=PE.NtExecutableResource.from(PE.NtExecutable.from(output));
if(!ResEdit.Resource.VersionInfo.fromEntries(check.entries).some(v=>v.getStringValues({lang:1033,codepage:1200}).ProductName==='LOCKDOWN — Blackwater'))throw new Error('Version metadata verification failed');
await fs.writeFile(targetFile,output);console.log('PASS Windows icon, product version and unchanged engine code; template:',targetFile);
